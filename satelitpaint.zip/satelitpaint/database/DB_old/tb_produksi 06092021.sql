-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2021 at 05:57 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_satelitpaint`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_produksi`
--

CREATE TABLE `tb_produksi` (
  `id_produksi` int(11) NOT NULL,
  `id_resep` int(11) NOT NULL,
  `qttproduksi` int(11) NOT NULL,
  `id_barangjadi` int(11) NOT NULL,
  `hasilproduksi` enum('barang setengah jadi','barang jadi') NOT NULL,
  `biayabahan` int(11) NOT NULL,
  `biayaproduksi` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tgl_update` date NOT NULL,
  `kodeproduksi` char(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_produksi`
--

INSERT INTO `tb_produksi` (`id_produksi`, `id_resep`, `qttproduksi`, `id_barangjadi`, `hasilproduksi`, `biayabahan`, `biayaproduksi`, `id_user`, `tgl_update`, `kodeproduksi`) VALUES
(1, 0, 90, 6, 'barang jadi', 300, 320000, 1, '2021-08-26', ''),
(2, 0, 10, 3, 'barang jadi', 2000, 500000, 1, '2021-08-26', ''),
(3, 0, 0, 5, 'barang setengah jadi', 0, 0, 1, '2021-09-03', 'BP/0001/03092021'),
(4, 0, 0, 6, 'barang setengah jadi', 0, 0, 1, '2021-09-05', 'BP/0002/05092021'),
(5, 0, 0, 6, 'barang setengah jadi', 0, 0, 1, '2021-09-06', 'BP/0003/06092021'),
(6, 0, 0, 4, 'barang setengah jadi', 0, 0, 1, '2021-09-06', 'BP/0004/06092021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_produksi`
--
ALTER TABLE `tb_produksi`
  ADD PRIMARY KEY (`id_produksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_produksi`
--
ALTER TABLE `tb_produksi`
  MODIFY `id_produksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
