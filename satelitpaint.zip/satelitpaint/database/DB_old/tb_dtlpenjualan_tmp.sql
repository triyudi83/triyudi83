-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 03 Sep 2021 pada 06.10
-- Versi server: 5.7.24
-- Versi PHP: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_satelitpaint`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_dtlpenjualantmp`
--

CREATE TABLE `tb_dtlpenjualantmp` (
  `id_dtlpenjualan` int(11) NOT NULL,
  `id_penjualan` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `qtt` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `id_user` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_dtlpenjualantmp`
--

INSERT INTO `tb_dtlpenjualantmp` (`id_dtlpenjualan`, `id_penjualan`, `id_barang`, `qtt`, `harga`, `diskon`, `subtotal`, `id_user`) VALUES
(31, 1, 42, 90, 10000, 0, 900000, '1'),
(32, 2, 24, 53, 50000, 10000, 2640000, '1'),
(33, 2, 31, 100, 55000, 9000, 5491000, '1');

--
-- Trigger `tb_dtlpenjualantmp`
--
DELIMITER $$
CREATE TRIGGER `delete_stok` AFTER UPDATE ON `tb_dtlpenjualantmp` FOR EACH ROW BEGIN
UPDATE tb_barang set stok = stok-NEW.qtt
WHERE id_barang = new.id_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `mutasi_pembelian` AFTER UPDATE ON `tb_dtlpenjualantmp` FOR EACH ROW BEGIN
INSERT INTO tb_mutasi
VALUES (
    null,
    NEW.id_barang,
    NEW.qtt,
    CONCAT('jual'),
    CONCAT('Penjualan Barang'),
    new.id_user,
    NOW()
);
    END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_dtlpenjualantmp`
--
ALTER TABLE `tb_dtlpenjualantmp`
  ADD PRIMARY KEY (`id_dtlpenjualan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_dtlpenjualantmp`
--
ALTER TABLE `tb_dtlpenjualantmp`
  MODIFY `id_dtlpenjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
