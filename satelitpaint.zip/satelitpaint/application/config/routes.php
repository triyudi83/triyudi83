<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'C_Login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


$route['login'] = 'C_Login';
$route['Welcome'] = 'Welcome';

$route['setting'] = 'C_Setting';
$route['akses-admin'] = 'C_Setting/view/administrator';
$route['akses-kasir'] = 'C_Setting/view/kasir';

$route['user'] = 'C_User';
$route['user-add'] = 'C_User/add';
$route['user-edit/(:any)'] = 'C_User/edit/$1';

$route['customer'] = 'C_Customer';
$route['customer-add'] = 'C_Customer/add';
$route['customer-edit/(:any)'] = 'C_Customer/edit/$1';
$route['customer-view/(:any)'] = 'C_Customer/view/$1';

$route['barang'] = 'C_Barang';
$route['barang-add'] = 'C_Barang/add';
$route['barang-edit/(:any)'] = 'C_Barang/edit/$1';
$route['barang-view/(:any)'] = 'C_Barang/view/$1';
$route['konversi-add/(:any)'] = 'C_Barang/addkonversi/$1';
$route['konversi-edit/(:any)/(:any)'] = 'C_Barang/editkonversi/$1/$2';
$route['stok'] = 'C_Barang/stok';
$route['stokbsj'] = 'C_Barang/stokbsj';
$route['stokbk'] = 'C_Barang/stokbk';

$route['suplier'] = 'Suplier';
$route['suplier-add'] = 'Suplier/tambah';
$route['suplier-edit/(:any)'] = 'Suplier/edit/$1';
$route['suplier-view/(:any)'] = 'Suplier/view/$1';

$route['satuan'] = 'Satuan';
$route['satuan-add'] = 'Satuan/tambah';
$route['satuan-edit/(:any)'] = 'Satuan/edit/$1';
$route['satuan-view/(:any)'] = 'Satuan/view/$1';

$route['sales'] = 'Sales';
$route['sales-add'] = 'Sales/tambah';
$route['sales-edit/(:any)'] = 'Sales/edit/$1';
$route['sales-view/(:any)'] = 'Sales/view/$1';


$route['produksi'] = 'C_Produksi';
$route['produksi-cekresep'] = 'C_Produksi/cekresep';
$route['produksi-add/(:any)'] = 'C_Produksi/add/$1';
$route['produksi-tambah/(:any)'] = 'C_Produksi/tambah/$1';
$route['produksi-view/(:any)'] = 'C_Produksi/view/$1';
$route['produksi-cetak/(:any)'] = 'C_Produksi/cetak/$1';


$route['mutasi'] = 'C_Barang/stokbarang';
$route['mutasi-detail/(:any)'] = 'C_Barang/mutasi/$1';

$route['formulasi'] = 'C_Resep';
$route['formulasi-add'] = 'C_Resep/tambah';
$route['formulasi-edit/(:any)'] = 'C_Resep/edit/$1';
$route['formulasi-view/(:any)'] = 'C_Resep/view/$1';
$route['delete/(:any)'] = 'C_Resep/delete/$1';
$route['komposisi-add/(:any)'] = 'C_Resep/komposisi/$1';
$route['komposisi-edit/(:any)/(:any)'] = 'C_Resep/komposisi_edit/$1/$2';
$route['komposisi-delete/(:any)/(:any)'] = 'C_Resep/komposisi_delete/$1/$2';

$route['pembelian'] = 'C_Pembelian';
$route['pembelian-add'] = 'C_Pembelian/tambah';
$route['pembelian-edit/(:any)'] = 'C_Pembelian/edit/$1';
$route['pembelian-view/(:any)'] = 'C_Pembelian/view/$1';
$route['pembelian-delete/(:any)'] = 'C_Pembelian/delete/$1';

$route['penjualan'] = 'C_Penjualan';
$route['penjualan-add'] = 'C_Penjualan/tambah';
$route['penjualan-edit/(:any)'] = 'C_Penjualan/edit/$1';
$route['penjualan-view/(:any)'] = 'C_Penjualan/view/$1';
$route['penjualan-delete/(:any)'] = 'C_Penjualan/delete/$1';
$route['nota/(:any)'] = 'C_Penjualan/nota/$1';
$route['surat/(:any)'] = 'C_Penjualan/suratjalan/$1';

$route['kaskeluar'] = 'C_Kas';
$route['kaskeluar-add'] = 'C_Kas/tambah';
// $route['kaskeluar-edit/(:any)'] = 'C_Kas/edit/$1';
// $route['kaskeluar-view/(:any)'] = 'C_Kas/view/$1';
// $route['kaskeluar-delete/(:any)'] = 'C_Kas/delete/$1';

$route['hutang'] = 'C_Hutang';
$route['hutang-bayar/(:any)'] = 'C_Hutang/bayar/$1';

$route['piutang'] = 'C_Piutang';
$route['piutang-bayar/(:any)'] = 'C_Piutang/bayar/$1';

$route['lappenjualan'] = 'C_Laporan/laporan_penjualan';
$route['lappembelian'] = 'C_Laporan/laporan_pembelian';

$route['komisi'] = 'C_Komisi';
$route['komisi-add'] = 'C_Komisi/tambah';