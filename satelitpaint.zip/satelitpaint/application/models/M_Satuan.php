<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Satuan extends CI_Model{
    
    public function index(){
        $this->db->select('tb_satuan.*, tb_user.nama');
        $this->db->from('tb_satuan');
        $this->db->join('tb_user', 'tb_user.id_user = tb_satuan.id_user');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function save(){
        $data = [
            "satuan" => $this->input->post('satuan',true),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->insert('tb_satuan',$data);
    }
    public function update(){
        $data = [
            "satuan" => $this->input->post('satuan',true),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_satuan',$this->input->post('id_satuan'));
        $this->db->update('tb_satuan', $data);
    }
    public function delete($id){
        $this->db->where('id_satuan', $id);
        $this->db->delete('tb_satuan');
    }

    public function getSatuanById($id){
        return $this->db->get_where('tb_satuan',['id_satuan' => $id])->row_array();
    }
}
?>