<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_Produksi extends CI_Model {
    function getall(){
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_produksi.id_barangjadi');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $query = $this->db->get('tb_produksi');
        return $query->result();
    }

    function cekproduksibln(){
        $vbulan = date("m"); 
        $where = array(
            'month(tgl_update)' => $vbulan
        );
        return $this->db->get_where('tb_produksi',$where)->result();
    }


    function cekkodeproduksi(){
        $this->db->select_max('id_produksi');
        $idbarang = $this->db->get('tb_produksi');
        return $idbarang->row();
    }
    
    function tambahdata(){
        $user = array(
            'id_produksi' => $this->input->post('id_produksi'),
            'kodeproduksi' => $this->input->post('kodeproduksi'),
            'id_barangjadi' => $this->input->post('barangjadi'),
            // 'hasilproduksi' => $this->input->post('jenisbarang'),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $this->db->insert('tb_produksi', $user);
    }

    function editbarang(){
        $user = array(
            'id_barangjadi' => $this->input->post('id_baranghasil'),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
            
        );

        $where = array(
            'id_produksi' =>  $this->input->post('id_produksi'),
        );
        
        $this->db->where($where);
        $this->db->update('tb_produksi',$user);
    }

    function update(){
        $user = array(
            'qttproduksi' => $this->input->post('qtt'),
            'id_barangjadi' => $this->input->post('id_baranghasil'),
            'hasilproduksi' => "barang jadi",
            'biayabahan' => preg_replace('/([^0-9]+)/','',$this->input->post('biayabahanbaku')),
            'biayaproduksi' => preg_replace('/([^0-9]+)/','',$this->input->post('biayalainlain')),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
            
        );

        $where = array(
            'id_produksi' =>  $this->input->post('id_produksi'),
        );
        
        $this->db->where($where);
        $this->db->update('tb_produksi',$user);
    }


    function simpanbarangbaku($user){
       
        
        $this->db->insert('tb_dtlproduksi', $user);
    }

    function simpanbiaya(){
        $user = array(
            'id_produksi' => $this->input->post('id_produksi'),
            'ket' => $this->input->post('ketbiaya'),
            'nominal' => preg_replace('/([^0-9]+)/','',$this->input->post('biayaprod'))
        );
        
        $this->db->insert('tb_biayaproduksi', $user);
    }

    function bahan($id){
        $this->db->select('tb_produksi.*, tb_dtlproduksi.*, tb_resep.kodeformulasi, tb_resep.id_resep, tb_barang.*');
        $this->db->join('tb_produksi', 'tb_produksi.id_produksi = tb_dtlproduksi.id_produksi');
        $this->db->join('tb_resep', 'tb_resep.id_resep = tb_dtlproduksi.id_resep');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_dtlproduksi.id_bahanbaku');
        $this->db->where('tb_dtlproduksi.id_produksi', $id);
        $query = $this->db->get('tb_dtlproduksi');
        return $query->result();
    }

    function biaya($id){
        // $this->db->join('tb_produksi', 'tb_produksi.id_produksi = tb_biayaproduksi.id_produksi');
        $this->db->where('id_produksi', $id);
        return $this->db->get('tb_biayaproduksi')->result();
    }

    function getspek($id){
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_produksi.id_barangjadi');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where('id_produksi', $id);
        return $this->db->get('tb_produksi')->result();
    }


    // function getkonversi($id){
    //     $this->db->select('tb_konversi.*, tb_produksi.*, a.satuan awal, b.satuan akhir');
    //     $this->db->join('tb_produksi', 'tb_konversi.id_barang = tb_produksi.id_barang');
    //     $this->db->join('tb_satuan a', 'a.id_satuan = tb_konversi.satuanawal');
    //     $this->db->join('tb_satuan b', 'b.id_satuan = tb_konversi.satuanakhir');
    //     $this->db->where('tb_konversi.id_barang', $id);
    //     $query = $this->db->get('tb_konversi');
    //     return $query->result();
    // }

    //  function getdetailkonversi($id){
    //     $this->db->select('tb_konversi.*, tb_produksi.*, a.satuan awal, b.satuan akhir');
    //     $this->db->join('tb_produksi', 'tb_konversi.id_barang = tb_produksi.id_barang');
    //     $this->db->join('tb_satuan a', 'a.id_satuan = tb_konversi.satuanawal');
    //     $this->db->join('tb_satuan b', 'b.id_satuan = tb_konversi.satuanakhir');
    //     $this->db->where('tb_konversi.id_konversi', $id);
    //     $query = $this->db->get('tb_konversi');
    //     return $query->result();
    // }

    

    

    // function tambahkonversi(){
    //     $user = array(
    //         'id_barang' => $this->input->post('id'),
    //         'qttawal' => $this->input->post('qttawal'),
    //         'satuanawal' => $this->input->post('satuanawal'),
    //         'qttakhir' => $this->input->post('qttakhir'),
    //         'satuanakhir' => $this->input->post('satuanakhir'),
    //         'tgl_update' => date('Y-m-d'), 
    //         'id_user' => $this->session->userdata('id_user')
    //     );
        
    //     $this->db->insert('tb_konversi', $user);
    // }

    //  function updatekonversi(){
    //     $user = array(
    //         'qttawal' => $this->input->post('qttawal'),
    //         'satuanawal' => $this->input->post('satuanawal'),
    //         'qttakhir' => $this->input->post('qttakhir'),
    //         'satuanakhir' => $this->input->post('satuanakhir'),
    //         'tgl_update' => date('Y-m-d'), 
    //         'id_user' => $this->session->userdata('id_user')
    //     );
        
    //     $where = array(
    //         'id_konversi' =>  $this->input->post('idkonversi'),
    //     );
        
    //     $this->db->where($where);
    //     $this->db->update('tb_konversi',$user);
    // }
   
}