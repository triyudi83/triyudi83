<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_Barang extends CI_Model {
    function getall(){
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $query = $this->db->get('tb_barang');
        return $query->result();
    }

    function stok(){
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where('jenisbarang', 'jual');
        $query = $this->db->get('tb_barang');
        return $query->result();
    }

    function barangbkbsj(){
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where_not_in('jenisbarang', 'jual');
        $query = $this->db->get('tb_barang');
        return $query->result();
    }

    function stokbsj(){
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where('jenisbarang', 'bsj');
        $query = $this->db->get('tb_barang');
        return $query->result();
    }

    function stokbk(){
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where('jenisbarang', 'baku');
        $query = $this->db->get('tb_barang');
        return $query->result();
    }

    function getspek($id){
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where('id_barang', $id);
        $query = $this->db->get('tb_barang');
        return $query->result();
    }

    function getkonversi($id){
        $this->db->select('tb_konversi.*, tb_barang.*, a.satuan awal, b.satuan akhir');
        $this->db->join('tb_barang', 'tb_konversi.id_barang = tb_barang.id_barang');
        $this->db->join('tb_satuan a', 'a.id_satuan = tb_konversi.satuanawal');
        $this->db->join('tb_satuan b', 'b.id_satuan = tb_konversi.satuanakhir');
        $this->db->where('tb_konversi.id_barang', $id);
        $query = $this->db->get('tb_konversi');
        return $query->result();
    }

     function getdetailkonversi($id){
        $this->db->select('tb_konversi.*, tb_barang.*, a.satuan awal, b.satuan akhir');
        $this->db->join('tb_barang', 'tb_konversi.id_barang = tb_barang.id_barang');
        $this->db->join('tb_satuan a', 'a.id_satuan = tb_konversi.satuanawal');
        $this->db->join('tb_satuan b', 'b.id_satuan = tb_konversi.satuanakhir');
        $this->db->where('tb_konversi.id_konversi', $id);
        $query = $this->db->get('tb_konversi');
        return $query->result();
    }

    function edit(){
        $user = array(
            'kodebarang' => $this->input->post('kodeBarang'),
            'barang' => $this->input->post('namabarang'),
            'id_satuan' => $this->input->post('satuan'),
            'jenisbarang' => $this->input->post('jenisbarang'),
            'harga_beli' => preg_replace('/([^0-9]+)/','',$this->input->post('beli')),
            'stok' => '0',
            'harga_jual' => preg_replace('/([^0-9]+)/','',$this->input->post('jual')),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
            
        );

        $where = array(
            'id_barang' =>  $this->input->post('id'),
        );
        
        $this->db->where($where);
        $this->db->update('tb_barang',$user);
    }

    function tambahdata(){
        $user = array(
            'kodebarang' => $this->input->post('kodebarang'),
            'barang' => $this->input->post('namabarang'),
            'id_satuan' => $this->input->post('satuan'),
            'jenisbarang' => $this->input->post('jenisbarang'),
            'harga_beli' => preg_replace('/([^0-9]+)/','',$this->input->post('beli')),
            'stok' => '0',
            'harga_jual' => preg_replace('/([^0-9]+)/','',$this->input->post('jual')),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $this->db->insert('tb_barang', $user);
    }

    function tambahkonversi(){
        $user = array(
            'id_barang' => $this->input->post('id'),
            'qttawal' => $this->input->post('qttawal'),
            'satuanawal' => $this->input->post('satuanawal'),
            'qttakhir' => $this->input->post('qttakhir'),
            'satuanakhir' => $this->input->post('satuanakhir'),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $this->db->insert('tb_konversi', $user);
    }

     function updatekonversi(){
        $user = array(
            'qttawal' => $this->input->post('qttawal'),
            'satuanawal' => $this->input->post('satuanawal'),
            'qttakhir' => $this->input->post('qttakhir'),
            'satuanakhir' => $this->input->post('satuanakhir'),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $where = array(
            'id_konversi' =>  $this->input->post('idkonversi'),
        );
        
        $this->db->where($where);
        $this->db->update('tb_konversi',$user);
    }

    function cek(){

        $where = array(
            'barang' => $this->input->post('namabarang'),
            'id_satuan' => $this->input->post('satuan'),
        );
        $query = $this->db->get_where('tb_barang', $where);
        return $query->result();
    }

    function getmutasi($id){
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_mutasi.id_barang');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where('tb_mutasi.id_barang', $id);
        $query = $this->db->get('tb_mutasi');
        return $query->result();
    }

    function gettotalbarang(){
        $this->db->select_sum('stok');
        $this->db->where('jenisbarang', 'jual');
        return $this->db->get('tb_barang')->result();
    }

    function gettotalbk(){
        $this->db->select_sum('stok');
        $this->db->where('jenisbarang', 'baku');
        return $this->db->get('tb_barang')->result();
    }

    function updatebarangsj($stoksjakhir){
        $user = array(
            'stoksj' => $stoksjakhir,
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
            
        );

        $where = array(
            'id_barang' =>  $this->input->post('id_baranghasil'),
        );
        
        $this->db->where($where);
        $this->db->update('tb_barang',$user);
    }

    function updatebarang($stokakhir, $idbarang, $hpp){
        $user = array(
            'stok' => $stokakhir,
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user'),
            'hpp' => $hpp
        );

        $where = array(
            'id_barang' =>  $idbarang,
        );
        
        $this->db->where($where);
        $this->db->update('tb_barang',$user);
    }

    function updatebarangbaku($stokakhir, $idbarang){
        $user = array(
            'stok' => $stokakhir,
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user'),
        );

        $where = array(
            'id_barang' =>  $idbarang,
        );
        
        $this->db->where($where);
        $this->db->update('tb_barang',$user);
    }

    function tambahmutasiproduksi(){
        $user = array(
            'id_barang' => $this->input->post('id_baranghasil'),
            'qtt' => $this->input->post('qtt'),
            'jenismutasi' => 'produksi',
            'ket' => 'hasil produksi barang jadi',
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $this->db->insert('tb_mutasi', $user);
    }

    function tambahmutasibahanbakuprod($idbarang, $qtt){
        $user = array(
            'id_barang' => $idbarang,
            'qtt' => $qtt,
            'jenismutasi' => 'produksi',
            'ket' => 'Pemakaian bahan produksi '.$this->input->post('kodeproduksi'),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $this->db->insert('tb_mutasi', $user);
    }
}