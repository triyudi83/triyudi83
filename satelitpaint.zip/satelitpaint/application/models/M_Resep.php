<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Resep extends CI_Model{
    

    function cekresepbln(){
        $vbulan = date("m"); 
        $where = array(
            'month(tgl_update)' => $vbulan
        );
        return $this->db->get_where('tb_resep',$where)->result();
    }

    public function index(){
        //return $this->db->get('tb_sales')->result_array();
        $this->db->select('*');
        $this->db->from('tb_resep');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_resep.id_barangjadi');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_resep.id_satuan');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function save(){
        $data = [
            "id_barangjadi" => $this->input->post('id_barang',true),
            "id_user" => $this->session->userdata('id_user'),
            "qtt" => $this->input->post('qtt_barangjadi',true),
            "kodeformulasi" => $this->input->post('kode',true),
            "id_satuan" => $this->input->post('id_satuan',true),
            "tgl_update" => date('Y-m-d'),
        ];
        $this->db->insert('tb_resep',$data);
    }
    public function update(){
        $data = [
            "id_barangjadi" => $this->input->post('id_barang',true),
            "id_user" => $this->session->userdata('id_user'),
            "qtt" => $this->input->post('qtt_barangjadi',true),
            "id_satuan" => $this->input->post('id_satuan',true),
            "tgl_update" => date('Y-m-d'),
        ];
        $this->db->where('id_resep',$this->input->post('id_resep'));
        $this->db->update('tb_resep', $data);
    }

    public function getResepById($id){
        $this->db->select('*');
        $this->db->from('tb_resep');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_resep.id_satuan');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_resep.id_barangjadi');
        $this->db->where(['id_resep' => $id]);
        $query = $this->db->get();
        return $query->row();
    }
    public function getDetailResep($id){
        $this->db->select('*');
        $this->db->from('id_dtlresep');
        $this->db->join('tb_barang', 'tb_barang.id_barang = id_dtlresep.id_bahanbaku');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = id_dtlresep.id_satuan');
        $this->db->where(['id_resep' => $id]);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getbarangresep($id){
        $this->db->select('*');
        $this->db->from('id_dtlresep');
        $this->db->join('tb_resep', 'tb_resep.id_resep = id_dtlresep.id_resep');
        $this->db->join('tb_barang', 'tb_barang.id_barang = id_dtlresep.id_bahanbaku');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = id_dtlresep.id_satuan');
        $this->db->where(['tb_resep.id_barangjadi' => $id]);
        $query = $this->db->get();
        return $query->result();
    }
    
    public function getAllDetail($id_dtlresep){
        $this->db->select('*');
        $this->db->from('id_dtlresep');
        $this->db->join('tb_barang', 'tb_barang.id_barang = id_dtlresep.id_bahanbaku');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = id_dtlresep.id_satuan');
        $this->db->where(['id_dtlresep' => $id_dtlresep]);
        $query = $this->db->get();
        return $query->row();
    }
    public function delete($id){
        $this->db->where('id_resep', $id);
        $this->db->delete('tb_resep');
    }

    public function komposisi_delete($id_dtlresep){
        $this->db->where('id_dtlresep', $id_dtlresep);
        $this->db->delete('id_dtlresep');
    }
    public function getBarang(){
        $this->db->select('*');
        $this->db->from('tb_barang');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where(['jenisbarang'=>'jual']);
        $query = $this->db->get();
        return $query->result_array();
    }
    function getIdBarang($id){
        $this->db->select('*');
        $this->db->from('tb_barang');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where(['id_barang'=>$id]);
        $query = $this->db->get();
        return $query->result_array();
    }

    function getdtlresep($id){
        $this->db->select('*');
        $this->db->from('id_dtlresep');
        $this->db->join('tb_barang', 'tb_barang.id_barang = id_dtlresep.id_bahanbaku');
        $this->db->where(['id_resep'=>$id]);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getBrgBaku(){
        $this->db->select('*');
        $this->db->from('tb_barang');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where(['jenisbarang'=>'baku']);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function save_komposisi(){
        $data = [
            "id_resep" => $this->input->post('id_resep',true),
            "id_bahanbaku" => $this->input->post('id_barangbaku',true),
            "qtt" => $this->input->post('qtt_barangbaku',true),
            "id_satuan" => $this->input->post('id_satuan_baku',true),
        ];
        $this->db->insert('id_dtlresep',$data);
    }

    public function edit_komposisi(){
        $data = [
            "id_resep" => $this->input->post('id_resep',true),
            "id_bahanbaku" => $this->input->post('id_barangbaku',true),
            "qtt" => $this->input->post('qtt_barangbaku',true),
            "id_satuan" => $this->input->post('id_satuan_baku',true),
        ];
        $this->db->where('id_dtlresep',$this->input->post('id_dtlresep'));
        $this->db->update('id_dtlresep', $data);
    }
    function get_all_resep() { //ambil data barang dari table barang yang akan di generate ke datatable
        $id = $this->input->post('id');
        $this->serverside->select('*');
        $this->serverside->from('id_dtlresep');
        $this->serverside->join('tb_barang', 'tb_barang.id_barang = id_dtlresep.id_bahanbaku');
        $this->serverside->where(['id_resep'=>$id]);
        $this->serverside->add_column('input_qtt', '<input type="number" name="qttprod" id="qttprod">','qtt');
        return $this->serverside->generate();
  }
}
?>