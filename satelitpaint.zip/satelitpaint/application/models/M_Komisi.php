<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Komisi extends CI_Model{

    public function index(){
        $this->db->from('tb_komisi');
        $this->db->join('tb_sales', 'tb_sales.id_sales = tb_komisi.id_sales');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function search($id_sales, $dateawal, $dateakhir){
        $this->db->from('tb_penjualan');
        $this->db->join('tb_customer', 'tb_customer.id_customer = tb_penjualan.id_customer');
        $this->db->where('tb_penjualan.id_sales', $id_sales);
        $this->db->where('tb_penjualan.tgl_update >=', $dateawal);
        $this->db->where('tb_penjualan.tgl_update <=', $dateakhir);
        $query = $this->db->get();
        return $query->result();
    }

    function tambahdata($tglawal, $tglakhir){
        $user = array(
            'tgl_periodeawal' => date('Y-m-d', strtotime($tglawal)),
            'tgl_periodeakhir' => date('Y-m-d', strtotime($tglakhir)),
            'id_sales' => $this->input->post('komisisales'),
            'tgl_komisi' => date('Y-m-d', strtotime($this->input->post('tgl_transaksi'))),
            'totalnota' => preg_replace('/([^0-9]+)/','',$this->input->post('totalnota')),
            'komisi' => preg_replace('/([^0-9]+)/','',$this->input->post('komisi')),
            'tgl_update' => date('Y-m-d'), 
            'id_user' => $this->session->userdata('id_user')
        );
        
        $this->db->insert('tb_komisi', $user);
    }

}