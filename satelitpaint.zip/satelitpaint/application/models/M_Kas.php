<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Kas extends CI_Model{
    public $table = 'tb_kas';
    public $id = 'id_kas';

    function __construct()
    {
        parent::__construct();
    }
    
    public function index(){
        $this->db->select('*');
        return $this->db->get($this->table)->result();
    }
    public function grafik(){
        $bulan = date('m'); 
        $this->db->where('month(tgl_update)',$bulan);
        $query = $this->db->get('tb_kaskeluar');
        return $query->result();
    }

    function simpan($data){
        $this->db->insert($this->table, $data);
    }
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }
    function update($id, $data)
    {
        $this->db->where('id_kas', $id);
        $this->db->update($this->table, $data);
    }
     // get data by id
     function get_by_id($id)
     {
         $this->db->where($this->id, $id);
         return $this->db->get($this->table)->row();
     }
     
     function sum($tgl_pertama,$tgl_terakhir){
        $this->db->select_sum('nominal');
        $this->db->from('tb_kas');
        $this->db->where('tglkas BETWEEN "'.$tgl_pertama. '" and "'.$tgl_terakhir.'"');
        $query = $this->db->get();
        return $query->row();
      }

}