<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Piutang extends CI_Model{
    
    function sum(){
	    $this->db->select_sum('total');
	    $this->db->from('tb_penjualan');
	    $this->db->where('status', 'Belum Lunas');
	    $query = $this->db->get();
	    return $query->row();
	}

	public function index(){
        $this->db->order_by('tgl_jatuhtempo', 'ASC');
        $this->db->select('tb_penjualan.*, tb_customer.namacustomer');
        $this->db->from('tb_penjualan');
        $this->db->join('tb_customer', 'tb_customer.id_customer = tb_penjualan.id_customer');
	    $this->db->where('status', 'Belum Lunas');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function updatebayar($id_penjualan){
        $data = [
            "status" => 'Lunas',
            "tgl_pelunasan" => date('Y-m-d'),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_penjualan',$id_penjualan);
        $this->db->update('tb_penjualan', $data);
    }

    public function updatelimit($id_customer, $limitskrg){
        $data = [
            "sisalimit" => $limitskrg,
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_customer',$id_customer);
        $this->db->update('tb_customer', $data);
    }

    function detail($id){
	    $this->db->from('tb_penjualan');
        $this->db->join('tb_customer', 'tb_customer.id_customer = tb_penjualan.id_customer');
	    $this->db->where('id_penjualan', $id);
	    $query = $this->db->get();
	    return $query->result_array();
	}

}