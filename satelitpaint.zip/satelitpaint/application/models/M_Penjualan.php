<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Penjualan extends CI_Model{
    
    public function grafik(){
        $bulan = date('m'); 
        $this->db->where('month(tgl_update)',$bulan);
        $query = $this->db->get('tb_penjualan');
        return $query->result();
    }

    public function grafikhutang(){
        $bulan = date('m'); 
        $this->db->where('month(tgl_update)',$bulan);
        $this->db->where('status','Belum Lunas');
        $query = $this->db->get('tb_penjualan');
        return $query->result();
    }

    public function index(){
        $this->db->select('tb_penjualan.*, tb_customer.namacustomer, tb_sales.namasales');
        $this->db->from('tb_penjualan');
        $this->db->join('tb_customer', 'tb_customer.id_customer = tb_penjualan.id_customer');
        $this->db->join('tb_sales', 'tb_sales.id_sales = tb_penjualan.id_sales');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function save_awal($data){
        $this->db->insert('tb_penjualan',$data);
    }

    public function edit_awal($id_penjualan,$data){
       
        $this->db->where('id_penjualan',$id_penjualan);
        $this->db->update('tb_penjualan', $data);
    }

    public function update(){
        $data = [
            "satuan" => $this->input->post('satuan',true),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_satuan',$this->input->post('id_satuan'));
        $this->db->update('tb_satuan', $data);
    }

    public function pembelian_update($id_pembelian,$data){
        $this->db->where('id_pembelian',$id_pembelian);
        $this->db->update('tb_penjualan', $data);
    }

    public function detailPembelian($data){
        $this->db->insert('tb_dtlpenjualan',$data);
    }

    public function detailPembelianUpdate($data,$id){
        $this->db->where('id_dtlpenjualan',$id);
        $this->db->update('tb_dtlpenjualan', $data);
    }
    public function delete($id){
        $this->db->where('id_pembelian', $id);
        $this->db->delete(array('tb_penjualan','tb_dtlpenjualan'));
    }

    public function getSatuanById($id){
        return $this->db->get_where('tb_satuan',['id_satuan' => $id])->row_array();
    }

    public function cart($id_penjualan){
        $this->db->select('tb_dtlpenjualan.*,tb_satuan.satuan,tb_barang.*');
        $this->db->from('tb_dtlpenjualan');
        $this->db->join('tb_penjualan', 'tb_penjualan.id_penjualan = tb_dtlpenjualan.id_penjualan');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_dtlpenjualan.id_barang');
        $this->db->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        $this->db->where(['tb_dtlpenjualan.id_penjualan' => $id_penjualan]);
        $query = $this->db->get();
        return $query->result_array();
    }

    function allposts_count($id)
    {   
        $this->db->select('*');
        $this->db->from('tb_dtlpenjualan');
        $this->db->join('tb_penjualan', 'tb_penjualan.id_penjualan = tb_dtlpenjualan.id_penjualan');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_dtlpenjualan.id_barang');
        $this->db->where(['tb_dtlpenjualan.id_dtlpenjualan' => $id]);
        $query = $this->db->get();
        return $query->result_array();  
    }

    public function delete_dtlpenjualan($id){
        $this->db->where('id_dtlpenjualan', $id);
        $this->db->delete('tb_dtlpenjualan');
    }
    public function get_all_customer()
    {
        $this->serverside->select('*');
        $this->serverside->from('tb_customer');
        $this->serverside->join('tb_provinsi', 'tb_provinsi.id_provinsi = tb_customer.id_prov');
        $this->serverside->join('tb_kota as kota', 'kota.id_kota = tb_customer.id_kota');
        $this->serverside->join('tb_kecamatan', 'tb_kecamatan.id_kecamatan = tb_customer.id_kecamatan');
        $this->serverside->join('tb_sales', 'tb_sales.id_sales = tb_customer.id_sales');
        return $this->serverside->generate();
    }
    function get_detailpenjualan($id_penjualan) { //ambil data barang dari table barang yang akan di generate ke datatable
        $this->serverside->select('*');
        $this->serverside->from('tb_dtlpenjualan');
        $this->serverside->join('tb_penjualan', 'tb_penjualan.id_penjualan = tb_dtlpenjualan.id_penjualan');
        $this->serverside->join('tb_barang', 'tb_barang.id_barang = tb_dtlpenjualan.id_barang');
        $this->serverside->where(['tb_dtlpenjualan.id_penjualan' => $id_penjualan]);
        return $this->serverside->generate();
  }
    public function penjualan_update($id_penjualan,$data){
        $this->db->where('id_penjualan',$id_penjualan);
        $this->db->update('tb_penjualan', $data);
    }
    public function updateTrigger($id_penjualan){
        $this->db->where('id_penjualan',$id_penjualan);
        $this->db->update('tb_dtlpenjualan', ['id_user' => $this->session->userdata('id_user')]);
    }
    function sum($tgl_pertama,$tgl_terakhir){
        $this->db->select_sum('total');
        $this->db->from('tb_penjualan');
        $this->db->where('tgl_update BETWEEN "'.$tgl_pertama. '" and "'.$tgl_terakhir.'"');
        $query = $this->db->get();
        return $query->row();
    }
    public function viewpenjualan($id_penjualan){
        $this->db->select('tb_penjualan.*, tb_customer.namacustomer, tb_customer.alamat,tb_sales.namasales');
        $this->db->from('tb_penjualan');
        $this->db->join('tb_customer', 'tb_customer.id_customer = tb_penjualan.id_customer');
        $this->db->join('tb_sales', 'tb_sales.id_sales = tb_penjualan.id_sales');
        $this->db->where(['tb_penjualan.id_penjualan' => $id_penjualan]);
        $query = $this->db->get();
        return $query->row();
    }


}