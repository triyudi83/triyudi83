<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Hutang extends CI_Model{
    
    function totalhutang(){
        $this->db->select_sum('totalnota');
        $this->db->from('tb_pembelian');
        $this->db->where('status','Belum Lunas');
        $query = $this->db->get();
        return $query->row();
    }
    public function hutang(){
        $this->db->select('tb_pembelian.*, tb_suplier.namasuplier');
        $this->db->from('tb_pembelian');
        $this->db->join('tb_suplier', 'tb_suplier.id_suplier = tb_pembelian.id_suplier');
        $this->db->where('status','Belum Lunas');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function updatebayar($id_pembelian){
        $data = [
            "status" => 'Lunas',
            "tgl_pelunasan" => date('Y-m-d'),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_pembelian',$id_pembelian);
        $this->db->update('tb_pembelian', $data);
    }

    public function updatelimit($id_suplier, $limitskrg){
        $data = [
            "limit" => $limitskrg,
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_suplier',$id_suplier);
        $this->db->update('tb_suplier', $data);
    }

    function detail($id){
	    $this->db->from('tb_pembelian');
        $this->db->join('tb_suplier', 'tb_suplier.id_suplier = tb_pembelian.id_suplier');
	    $this->db->where('id_pembelian', $id);
	    $query = $this->db->get();
	    return $query->result_array();
	}

}