<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Suplier extends CI_Model{
    
    public function index(){
        //return $this->db->get('tb_suplier')->result_array();
        // $this->db->select('*');
        // $this->db->from('tb_satuan');
        // $this->db->join('tb_user', 'tb_user.id_user = tb_satuan.id_user');
        // $query = $this->db->get();
        // return $query->result_array();
        $this->db->select('tb_suplier.*, tb_provinsi.*, tb_kota.*, tb_kecamatan.*');
        $this->db->join('tb_provinsi', 'tb_provinsi.id_provinsi = tb_suplier.id_prov');
        $this->db->join('tb_kota', 'tb_kota.id_kota = tb_suplier.id_kota');
        $this->db->join('tb_kecamatan', 'tb_kecamatan.id_kecamatan = tb_suplier.id_kecamatan');
        $query = $this->db->get('tb_suplier');
        return $query->result_array();
    }
    public function save(){
        $data = [
            "namasuplier" => $this->input->post('namasuplier',true),
            "alamat" => $this->input->post('alamat',true),
            "id_kota" => $this->input->post('id_kota',true),
            "id_prov" => $this->input->post('id_provinsi',true),
            "id_kecamatan" => $this->input->post('id_kecamatan',true),
            "tlp" => $this->input->post('tlp',true),
            "hp" => $this->input->post('hp',true),
            "limit" => preg_replace('/([^0-9]+)/','',$this->input->post('limit')),
            "id_user" => $this->session->userdata('id_user'),
            "tgl_update" => date('Y-m-d'),
        ];
        $this->db->insert('tb_suplier',$data);
    }
    public function update(){
        $data = [
            "namasuplier" => $this->input->post('namasuplier',true),
            "alamat" => $this->input->post('alamat',true),
            "id_kota" => $this->input->post('id_kota',true),
            "id_prov" => $this->input->post('id_provinsi',true),
            "id_kecamatan" => $this->input->post('id_kecamatan',true),
            "tlp" => $this->input->post('tlp',true),
            "hp" => $this->input->post('hp',true),
            "limit" => preg_replace('/([^0-9]+)/','',$this->input->post('limit')),
            "id_user" => $this->session->userdata('id_user'),
            "tgl_update" => date('Y-m-d'),
        ];
        $this->db->where('id_suplier',$this->input->post('id_suplier'));
        $this->db->update('tb_suplier', $data);
    }

    public function getSuplierById($id){
        return $this->db->get_where('tb_suplier',['id_suplier' => $id])->row();
    }

    
    public function delete($id){
        $this->db->where('id_suplier', $id);
        $this->db->delete('tb_suplier');
    }
}
?>