<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Pembelian extends CI_Model{
    
    public function index(){
        $this->db->select('tb_pembelian.*, tb_suplier.namasuplier');
        $this->db->from('tb_pembelian');
        $this->db->join('tb_suplier', 'tb_suplier.id_suplier = tb_pembelian.id_suplier');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function save_awal($max_id){
        $data = [
            "id_pembelian" => $max_id,
            "id_suplier" => $this->input->post('id_suplier',true),
            "nota" => $this->input->post('faktur',true),
            "jenispembayaran" => $this->input->post('jenispembayaran',true),
            "tgl_jatuhtempo" => date("Y-m-d", strtotime($this->input->post('jatuhtempo'))),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->insert('tb_pembelian',$data);
    }

    public function edit_awal($id_pembelian){
        $data = [
            "id_suplier" => $this->input->post('id_suplier',true),
            "nota" => $this->input->post('faktur',true),
            "jenispembayaran" => $this->input->post('jenispembayaran',true),
            "tgl_jatuhtempo" => date("Y-m-d", strtotime($this->input->post('jatuhtempo'))),
            "tgl_update" => date('Y-m-d'),
            "id_user" => $this->session->userdata('id_user'),
        ];
        $this->db->where('id_pembelian',$id_pembelian);
        $this->db->update('tb_pembelian', $data);
    }

    public function pembelian_update($id_pembelian,$data){
        $this->db->where('id_pembelian',$id_pembelian);
        $this->db->update('tb_pembelian', $data);
    }

    public function detailPembelian($data){
        $this->db->insert('tb_dtlpembelian',$data);
    }

    public function detailPembelianUpdate($data,$id){
        $this->db->where('id_dtlpembelian',$id);
        $this->db->update('tb_dtlpembelian', $data);
    }
    public function updateTrigger($id_pembelian){
        $this->db->where('id_pembelian',$id_pembelian);
        $this->db->update('tb_dtlpembelian', ['id_user' => $this->session->userdata('id_user')]);
    }
    public function delete($id){
        $this->db->where('id_pembelian', $id);
        $this->db->delete(array('tb_pembelian','tb_dtlpembelian'));
    }

    public function getSatuanById($id){
        return $this->db->get_where('tb_satuan',['id_satuan' => $id])->row_array();
    }

    public function cart($id_pembelian){
        $this->db->select('*');
        $this->db->from('tb_dtlpembelian');
        $this->db->join('tb_pembelian', 'tb_pembelian.id_pembelian = tb_dtlpembelian.id_pembelian');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_dtlpembelian.id_barang');
        $this->db->where(['tb_dtlpembelian.id_pembelian' => $id_pembelian]);
        $query = $this->db->get();
        return $query->result_array();
    }
    function allposts_count($id)
    {   
        $this->db->select('*');
        $this->db->from('tb_dtlpembelian');
        $this->db->join('tb_pembelian', 'tb_pembelian.id_pembelian = tb_dtlpembelian.id_pembelian');
        $this->db->join('tb_barang', 'tb_barang.id_barang = tb_dtlpembelian.id_barang');
        $this->db->where(['tb_dtlpembelian.id_dtlpembelian' => $id]);
        $query = $this->db->get();
        return $query->result_array();  

    }
    public function delete_dtlpembelian($id){
        $this->db->where('id_dtlpembelian', $id);
        $this->db->delete('tb_dtlpembelian');
    }

    function get_all_suplier() { //ambil data barang dari table barang yang akan di generate ke datatable
        $this->serverside->select('*');
        $this->serverside->from('tb_suplier');
        $this->serverside->join('tb_provinsi', 'tb_provinsi.id_provinsi = tb_suplier.id_prov');
        $this->serverside->join('tb_kota as kota', 'kota.id_kota = tb_suplier.id_kota');
        $this->serverside->join('tb_kecamatan', 'tb_kecamatan.id_kecamatan = tb_suplier.id_kecamatan');
        return $this->serverside->generate();
  }
    function get_all_barang() { //ambil data barang dari table barang yang akan di generate ke datatable
        $this->serverside->select('*');
        $this->serverside->from('tb_barang');
        $this->serverside->join('tb_satuan', 'tb_satuan.id_satuan = tb_barang.id_satuan');
        return $this->serverside->generate();
  }
    function get_detailpembelian($id_pembelian) { //ambil data barang dari table barang yang akan di generate ke datatable
        $this->serverside->select('*');
        $this->serverside->from('tb_dtlpembelian');
        $this->serverside->join('tb_pembelian', 'tb_pembelian.id_pembelian = tb_dtlpembelian.id_pembelian');
        $this->serverside->join('tb_barang', 'tb_barang.id_barang = tb_dtlpembelian.id_barang');
        $this->serverside->where(['tb_dtlpembelian.id_pembelian' => $id_pembelian]);
        return $this->serverside->generate();
  }
  function sum($tgl_pertama,$tgl_terakhir){
    $this->db->select_sum('totalnota');
    $this->db->from('tb_pembelian');
    $this->db->where('tgl_update BETWEEN "'.$tgl_pertama. '" and "'.$tgl_terakhir.'"');
    $query = $this->db->get();
    return $query->row();
  }
  public function viewpembelian($id_pembelian){
    $this->db->select('tb_pembelian.*, tb_suplier.namasuplier, tb_suplier.alamat');
    $this->db->from('tb_pembelian');
    $this->db->join('tb_suplier', 'tb_suplier.id_suplier = tb_pembelian.id_suplier');
    $this->db->where(['tb_pembelian.id_pembelian' => $id_pembelian]);
    $query = $this->db->get();
    return $query->row();
}
}
?>