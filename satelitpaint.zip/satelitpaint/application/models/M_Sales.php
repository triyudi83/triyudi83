<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Sales extends CI_Model{
    
    public function index(){
        //return $this->db->get('tb_sales')->result_array();
        $this->db->select('*');
        $this->db->from('tb_sales');
        $this->db->join('tb_provinsi', 'tb_provinsi.id_provinsi = tb_sales.id_prov');
        $this->db->join('tb_kota', 'tb_kota.id_kota = tb_sales.id_kota');
        $this->db->join('tb_kecamatan', 'tb_kecamatan.id_kecamatan = tb_sales.id_kecamatan');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function save(){
        $data = [
            "namasales" => $this->input->post('namasales',true),
            "alamat" => $this->input->post('alamat',true),
            "id_kota" => $this->input->post('id_kota',true),
            "id_prov" => $this->input->post('id_provinsi',true),
            "id_kecamatan" => $this->input->post('id_kecamatan',true),
            "tlf" => $this->input->post('tlf',true),
            "areakerja" => $this->input->post('areakerja',true),
            "id_user" => $this->session->userdata('id_user'),
            "tgl_update" => date('Y-m-d'),
        ];
        $this->db->insert('tb_sales',$data);
    }
    public function update(){
        $data = [
            "namasales" => $this->input->post('namasales',true),
            "alamat" => $this->input->post('alamat',true),
            "id_kota" => $this->input->post('id_kota',true),
            "id_prov" => $this->input->post('id_provinsi',true),
            "id_kecamatan" => $this->input->post('id_kecamatan',true),
            "tlf" => $this->input->post('tlf',true),
            "areakerja" => $this->input->post('areakerja',true),
            "id_user" => $this->session->userdata('id_user'),
            "tgl_update" => date('Y-m-d'),
        ];
        $this->db->where('id_sales',$this->input->post('id_sales'));
        $this->db->update('tb_sales', $data);
    }

    public function getSalesById($id){
        return $this->db->get_where('tb_sales',['id_sales' => $id])->row();
    }

    
    public function delete($id){
        $this->db->where('id_sales', $id);
        $this->db->delete('tb_sales');
    }
}
?>