<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Penjualan extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->library('Datatables', 'datatables');
        $this->load->library('Serverside', 'serverside');
        $this->load->model('M_Setting');
        $this->load->model('M_Customer');
        $this->load->model('M_Barang');
        $this->load->model('M_Penjualan');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

	public function index()
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '15';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '15'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '15'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '15'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        
        $data['database'] = $this->M_Penjualan->index();
        $hari_ini = date("Y-m-d");
        $tgl_pertama = date('Y-m-01', strtotime($hari_ini));
        $tgl_terakhir = date('Y-m-t', strtotime($hari_ini));
        $data['sum'] = $this->M_Penjualan->sum($tgl_pertama,$tgl_terakhir);

		$this->load->view('template/sidebar.php', $data);
		$this->load->view('penjualan/penjualan_index',$data);
		$this->load->view('template/footer.php');
	}
    public function tambah()
	{
        $query = $this->db->query("SELECT MAX(id_penjualan) as max_id FROM tb_penjualan"); 
        $row = $query->row_array();
        $data['cek_id'] = $row['max_id']+1;
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['max_id'] = '0';
        $data['activeMenu'] = '15';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['database'] = $this->M_Customer->getall();
        $data['barang'] = $this->M_Barang->getall();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('penjualan/v_addpenjualan');
		$this->load->view('template/footer.php');
	}

	function getIdcustomer(){
        $this->db->select('*');
        $this->db->from('tb_customer');
        $this->db->where('id_customer', $this->input->post('id'));
        $query = $this->db->get()->row();
        echo json_encode($query);
    }
    public function simpan(){
        $stok = $this->db->get_where('tb_barang',['id_barang' => $this->input->post('id_barang')])->row_array();
        $cek_stok = $stok['stok'];
        $this->form_validation->set_rules('qtt', 'Qtt', 'required|numeric|is_natural_no_zero|less_than_equal_to['.$cek_stok.']', 
            array('required'=> '%s wajib diisi.',
                    'less_than_equal_to'=> 'Stok kurang dari sama dengan '.$cek_stok.'',    
                    'numeric'=> '%s harus berisi angka.',
                    'is_natural_no_zero' => '%s tidak boleh kurang dari sama dengan 0.'    
        ));
        $this->form_validation->set_error_delimiters('', '');
        if ($this->form_validation->run() == FALSE){
                    $result['error'] = array(
                        'qtt'=>form_error('qtt'),
                    );
                    echo json_encode($result);
        }else{
            $query = $this->db->query("SELECT MAX(id_penjualan) as max_id FROM tb_penjualan"); 
            $row = $query->row_array();
            $max_id = $row['max_id']+1;
            $kodenota = $this->input->post('faktur');
            $id_customer=$this->input->post('id_customer');
            $id_penjualan=$this->input->post('id_penjualan');
            $jenispembayarancustomer=$this->input->post('jenispembayarancustomer');
            $limit_hutang=$this->input->post('limit_hutang');
            $jatuhtempo=date("Y-m-d", strtotime($this->input->post('jatuhtempo')));
            $id_sales=$this->input->post('id_sales');
            $id_barang=$this->input->post('id_barang');
            $qtt=$this->input->post('qtt');
            $harga=preg_replace('/([^0-9]+)/','',$this->input->post('harga'));
            $diskon=preg_replace('/([^0-9]+)/','',$this->input->post('diskon'));
            $subtotal = ($harga*$qtt)-$diskon;
                if($id_penjualan=='0'){
                    $data= array(
                        'id_penjualan' => $max_id,
                        'id_customer' => $id_customer,
                        'kodenota' => $kodenota,
                        'jenispembayaran' => $jenispembayarancustomer,
                        'tgl_jatuhtempo' => $jatuhtempo,
                        'tgl_update' => date('Y-m-d'),
                        "id_user" => $this->session->userdata('id_user'),
                        "id_sales" => $id_sales
                    );
                    $this->M_Penjualan->save_awal($data);
    
                    $data= array(
                        'id_penjualan' => $max_id,
                        'id_barang' => $id_barang,
                        'qtt' => $qtt,
                        'harga' => $harga,
                        'diskon' => $diskon,
                        'subtotal' => $subtotal,
                    );
                    $this->M_Penjualan->detailPembelian($data);
                }else{
                    $data= array(
                        'id_penjualan' => $id_penjualan,
                        'id_customer' => $id_customer,
                        'jenispembayaran' => $jenispembayarancustomer,
                        'tgl_jatuhtempo' => $jatuhtempo,
                        'tgl_update' => date('Y-m-d'),
                        "id_user" => $this->session->userdata('id_user'),
                        "id_sales" => $id_sales
                    );
                    $this->M_Penjualan->edit_awal($id_penjualan,$data);
                    $data= array(
                        'id_penjualan' => $id_penjualan,
                        'id_barang' => $id_barang,
                        'qtt' => $qtt,
                        'harga' => $harga,
                        'diskon' => $diskon,
                        'subtotal' => $subtotal,
                    );
                    $this->M_Penjualan->detailPembelian($data);
                }
                echo json_encode($data);
        }
        
    }
    function batal($id){
        $this->db->where('id_penjualan', $id);
        $this->db->delete(array('tb_penjualan','tb_dtlpenjualan'));
        $data['redirect']= 'penjualan';
        echo json_encode($data);
    }
    public function customer(){
        header('Content-Type: application/json');
        echo $this->M_Penjualan->get_all_customer();
    }

    public function add_cart(){
        $id_penjualan=$this->input->post('id_penjualan');
        $id_barang=$this->input->post('id_barang');
        $qtt=$this->input->post('qtt');
        $harga=preg_replace('/([^0-9]+)/','',$this->input->post('harga'));
        $diskon=preg_replace('/([^0-9]+)/','',$this->input->post('diskon'));
        $subtotal = ($harga*$qtt)-$diskon;
        $data= array(
            'id_penjualan' => $id_penjualan,
            'id_barang' => $id_barang,
            'qtt' => $qtt,
            'harga' => $harga,
            'diskon' => $diskon,
            'subtotal' => $subtotal,
        );
        $this->M_Penjualan->detailPembelian($data);
        echo json_encode($data);
    }

    public function update_detail(){
        $id=$this->input->post('id');
        $data=$this->M_Penjualan->allposts_count($id);
        echo json_encode($data);
            
    }
    public function delete_dtlpenjualan(){
        $id = $this->input->post('id');
        $this->M_Penjualan->delete_dtlpenjualan($id);
        echo json_encode('data berhasil dihapus');
    }
    public function cart_update(){
        $id=$this->input->post('id_dtlpenjualan');
        $id_penjualan=$this->input->post('id_penjualan');
        $id_barang=$this->input->post('id_barang');
        $qtt=$this->input->post('qtt');
        $harga=preg_replace('/([^0-9]+)/','',$this->input->post('harga'));
        $diskon=preg_replace('/([^0-9]+)/','',$this->input->post('diskon'));
        $subtotal = ($harga*$qtt)-$diskon;
        $data= array(
            'id_penjualan' => $id_penjualan,
            'id_barang' => $id_barang,
            'qtt' => $qtt,
            'harga' => $harga,
            'diskon' => $diskon,
            'subtotal' => $subtotal,
        );
        $this->M_Penjualan->detailPembelianUpdate($data,$id);
        echo json_encode($data);
    }
    public function json(){
        $id_penjualan=$this->input->post('id_penjualan');    
        header('Content-Type: application/json');
        echo $this->M_Penjualan->get_detailpenjualan($id_penjualan);
    }

    public function view($id_penjualan)
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '15';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '15'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '15'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '15'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        
        $data['database'] = $this->M_Penjualan->cart($id_penjualan);   
        $data['penjualan'] = $this->M_Penjualan->viewpenjualan($id_penjualan);   
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('penjualan/penjualan_view',$data);
		$this->load->view('template/footer.php');
	}
    public function update_all()
    {
        $id_penjualan=$this->input->post('id_penjualan');
        $subtotalbawah=$this->input->post('subtotalbawah');
        $diskon1=$this->input->post('diskon1');
        $total=$this->input->post('total');

        $cek = $this->db->get_where('tb_penjualan',['id_penjualan' => $id_penjualan])->row_array();
        $cek_jenis = $cek['jenispembayaran'];
        $id_customer = $cek['id_customer'];
        $cek1 = $this->db->get_where('tb_customer',['id_customer' => $id_customer])->row_array();
        $cek_limit = $cek1['sisalimit'];
        $limit = $cek_limit-$total;

        if($cek_jenis=='Kredit'){
            $this->form_validation->set_rules('total', 'Total', 'numeric|less_than_equal_to['.$cek_limit.']', 
                array('required'=> '%s wajib diisi.',
                        'less_than_equal_to'=> '%s melebihi limit hutang '.$cek_limit,    
                        'numeric'=> '%s harus berisi angka.',
                 ));
            $this->form_validation->set_rules('diskon1', 'Diskon', 'numeric|less_than_equal_to['.$subtotalbawah.']', 
            array('required'=> '%s wajib diisi.',
                    'less_than_equal_to'=> '%s melebihi total',    
                    'numeric'=> '%s harus berisi angka.',
             ));
            $this->form_validation->set_error_delimiters('', '');
            if ($this->form_validation->run() == FALSE){
                $result['error'] = array(
                    'total'=>form_error('total'),
                    'diskon1'=>form_error('diskon1')
                );
            }else{
                $this->db->where('id_customer',$id_customer);
                $this->db->update('tb_customer', ['sisalimit'=>$limit]);
                $this->db->where('id_penjualan',$id_penjualan);
                $this->db->update('tb_penjualan', ['status'=>'Belum Lunas']);
                $data= array(
                    'subtotalnota' => $subtotalbawah,
                    'diskonnota' => $diskon1,
                    'total' => $total,
                );
                
                $this->M_Penjualan->penjualan_update($id_penjualan,$data);
                $this->M_Penjualan->updateTrigger($id_penjualan);
                $result['success']= 'penjualan-view/'.$id_penjualan;
            }
        }else{
            $this->form_validation->set_rules('diskon1', 'Diskon', 'numeric|less_than_equal_to['.$subtotalbawah.']', 
            array('required'=> '%s wajib diisi.',
                    'less_than_equal_to'=> '%s melebihi total',    
                    'numeric'=> '%s harus berisi angka.',
             ));
            $this->form_validation->set_error_delimiters('', '');
            if ($this->form_validation->run() == FALSE){
                $result['error'] = array(
                    'diskon1'=>form_error('diskon1')
                );
            }else{
                $data= array(
                    'subtotalnota' => $subtotalbawah,
                    'diskonnota' => $diskon1,
                    'total' => $total,
                );
                $this->M_Penjualan->penjualan_update($id_penjualan,$data);
                $this->M_Penjualan->updateTrigger($id_penjualan);
                $result['success']= 'penjualan-view/'.$id_penjualan;
            }
        }
        echo json_encode($result);

    }
    function nota($id_penjualan){
        $data['database'] = $this->M_Penjualan->cart($id_penjualan);   
        $data['penjualan'] = $this->M_Penjualan->viewpenjualan($id_penjualan);   
        $this->load->library('pdf');
        $this->pdf->setPaper(array(0,0,396.8503937,680.31496063), 'landscape');
        $this->pdf->filename = "nota penjualan.pdf";
        $this->pdf->load_view('penjualan/cetak_nota',$data);
    }
    function suratjalan($id_penjualan){
        $data['database'] = $this->M_Penjualan->cart($id_penjualan);   
        $data['penjualan'] = $this->M_Penjualan->viewpenjualan($id_penjualan);   
        $this->load->library('pdf');
        $this->pdf->setPaper(array(0,0,396.8503937,680.31496063), 'landscape');
        $this->pdf->filename = "surat jalan.pdf";
        $this->pdf->load_view('penjualan/cetak_surat',$data);
    }

}