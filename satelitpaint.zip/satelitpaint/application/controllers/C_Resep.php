<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Resep extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->model('M_Setting');
        $this->load->model('M_Resep');
        $this->load->library('Serverside', 'serverside');
        // $this->load->model('M_Berita');
        // $this->load->model('M_User');
        // $this->load->model('M_Donasi');
        // $this->load->model('M_Level');
        if(!$this->session->userdata('id_user')){
             redirect('C_Login');
        }
    }

    public function index(){
        $this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '0';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '8'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '8'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '8'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;

		$data['database'] = $this->M_Resep->index();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('resep/index',$data);
		$this->load->view('template/footer.php');
    }
    public function tambah(){
        
        $modul = 'BB/no/tglblnthn';
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date('dmY');
        $modul = str_replace("tglblnthn", $tgl, $modul);
        $data = $this->M_Resep->cekresepbln();
        $no = count($data) + 1;
        if ($no<10){
            $no = '000'.$no;
        } elseif ($no<100) {
            $no = '00'.$no;
        } elseif ($no<1000) {
            $no = '0'.$no;
        } else {
            $no = $no;
        }
        $kode2 = str_replace("no", $no, $modul);

        $this->form_validation->set_rules('id_barang','Id Barang','required');
        $this->form_validation->set_rules('qtt_barangjadi','Qtt','required');
        $this->form_validation->set_rules('id_satuan','Satuan','required');

		if ($this->form_validation->run() == FALSE)
		{
            $this->load->view('template/header.php');
            $id = $this->session->userdata('tipeuser');
            $data['activeMenu'] = '0';
            $data['master'] = $this->M_Setting->getmenumaster($id);
            $data['setting'] = $this->M_Setting->getmenusetting($id);
            $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
            $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
            $data['stok'] = $this->M_Setting->getmenustok($id);
            $data['acc'] = $this->M_Setting->getmenuacc($id);
            $data['laporan'] = $this->M_Setting->getmenulaporan($id);
            $data['barang'] = $this->M_Resep->getBarang();
            $data['kode'] = $kode2;
            $this->load->view('template/sidebar.php', $data);
            $this->load->view('resep/tambah',$data);
            $this->load->view('template/footer.php');
		}
		else
		{
			$this->M_Resep->save();
			$this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Tambahkan.
            </div>      
			');
            $query = $this->db->query("SELECT MAX(id_resep) as max_id FROM tb_resep"); 
            $row = $query->row_array();
            $max_id = $row['max_id'];
			redirect('formulasi-view/'.$max_id);
		}
    }
    public function delete($id){
		$this->M_Resep->delete($id);
        $this->session->set_flashdata('flash','
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fa fa-check"></i> Success!</h5>
        Data berhasil di Hapus.
      </div>      
				');
		redirect('formulasi');
	}
    public function edit($id){
        $data['database'] = $this->M_Resep->getResepById($id);
        if(empty($data['database'])){
            redirect('formulasi');
        }
        else{
        $this->form_validation->set_rules('id_barang','Id Barang','required');
        $this->form_validation->set_rules('qtt_barangjadi','Qtt','required');
        $this->form_validation->set_rules('id_satuan','Satuan','required');
		if ($this->form_validation->run() == FALSE)
		{
            $this->load->view('template/header.php');
            $id = $this->session->userdata('tipeuser');
            $data['activeMenu'] = '0';
            $data['master'] = $this->M_Setting->getmenumaster($id);
            $data['setting'] = $this->M_Setting->getmenusetting($id);
            $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
            $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
            $data['stok'] = $this->M_Setting->getmenustok($id);
            $data['acc'] = $this->M_Setting->getmenuacc($id);
            $data['laporan'] = $this->M_Setting->getmenulaporan($id);
            $data['barang'] = $this->M_Resep->getBarang();

            $this->load->view('template/sidebar.php', $data);
            $this->load->view('resep/edit',$data);
            $this->load->view('template/footer.php');
		}
		else
		{
			$this->M_Resep->update();
			$this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Edit.
          </div>      
				');
			redirect('formulasi');
		}
    }
    }
    public function view($id){
            $data['database'] = $this->M_Resep->getResepById($id);
            if(empty($data['database'])){
                redirect('formulasi');
            }
            else{
            $data['resep'] = $this->M_Resep->getDetailResep($id);
            $this->load->view('template/header.php');
            $id = $this->session->userdata('tipeuser');
            $data['activeMenu'] = '0';
            $data['master'] = $this->M_Setting->getmenumaster($id);
            $data['setting'] = $this->M_Setting->getmenusetting($id);
            $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
            $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
            $data['stok'] = $this->M_Setting->getmenustok($id);
            $data['acc'] = $this->M_Setting->getmenuacc($id);
            $data['laporan'] = $this->M_Setting->getmenulaporan($id);
            $data['barang'] = $this->M_Resep->getBarang();
            $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '8'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '8'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '8'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;

            $this->load->view('template/sidebar.php', $data);
            $this->load->view('resep/view_resep',$data);
            $this->load->view('template/footer.php');
    }
    }
    public function getIdBarang(){
        $id = $this->input->post('id');
        $id_barang = $this->M_Resep->getIdBarang($id);
        echo json_encode($id_barang);
    }

    public function getidresep(){
        $id = $this->input->post('id');
        $id_resep = $this->M_Resep->getdtlresep($id);
        echo json_encode($id_resep);
    }
    
    public function komposisi($id){
        $data['database'] = $this->M_Resep->getResepById($id);
        $this->form_validation->set_rules('id_barangbaku','Id Barang','required');
        $this->form_validation->set_rules('qtt_barangbaku','Qtt','required');
        $this->form_validation->set_rules('id_satuan_baku','Satuan','required');
		if ($this->form_validation->run() == FALSE)
		{
        $this->load->view('template/header.php');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '0';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['barang'] = $this->M_Resep->getBarang();
        $data['baku'] = $this->M_Resep->getBrgBaku();
        $this->load->view('template/sidebar.php', $data);
        $this->load->view('resep/resep_komposisi',$data);
        $this->load->view('template/footer.php');
        }
        else{
			$this->M_Resep->save_komposisi();
			$this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Tambahkan.
          </div>      
				');
			redirect('formulasi-view/'.$id);
        }
    }
    public function komposisi_edit($id, $id_dtlresep){
        $data['detail_resep'] = $this->M_Resep->getAllDetail($id_dtlresep);
        $data['database'] = $this->M_Resep->getResepById($id);
        if(empty($data['database']) OR empty($data['detail_resep'])){
            redirect('formulasi');
        }
        else{
        $this->form_validation->set_rules('id_barangbaku','Id Barang','required');
        $this->form_validation->set_rules('qtt_barangbaku','Qtt','required');
        $this->form_validation->set_rules('id_satuan_baku','Satuan','required');
		if ($this->form_validation->run() == FALSE)
		{
        $this->load->view('template/header.php');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '0';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['barang'] = $this->M_Resep->getBarang();
        $data['baku'] = $this->M_Resep->getBrgBaku();
        $this->load->view('template/sidebar.php', $data);
        $this->load->view('resep/edit_komposisi',$data);
        $this->load->view('template/footer.php');
        }
        else{
			$this->M_Resep->edit_komposisi();
			$this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Edit.
          </div>      
				');
			redirect('formulasi-view/'.$id);
        }
    }
    }

    public function komposisi_delete($id,$id_dtlresep){
        $this->M_Resep->komposisi_delete($id_dtlresep);
        $this->session->set_flashdata('flash','
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fa fa-check"></i> Success!</h5>
        Data berhasil di Hapus.
      </div>      
				');
		redirect('formulasi-view/'.$id);
    }

    public function getallresep(){
        $id = $this->input->post('id');
        header('Content-Type: application/json');
        echo $this->M_Resep->get_all_resep($id);
    }
}
