<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class C_Barang extends CI_Controller{
    
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library('session');
        $this->load->model('M_Barang');
        $this->load->model('M_Setting');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

    function index()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '6';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '6'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '6'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '6'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] = $this->M_Barang->getall();
        $this->load->view('barang/index',$data); 
        $this->load->view('template/footer');
    }

    function add()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '6';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['satuan'] = $this->db->get('tb_satuan')->result();
        $this->load->view('template/sidebar.php', $data);
        $this->load->view('barang/tambah',$data); 
        $this->load->view('template/footer');
    }


    function addkonversi($idbarang)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '6';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['barang'] =$this->db->get_where('tb_barang', ['id_barang' => $idbarang])->result();
        $data['satuanawal'] = $this->db->get('tb_satuan')->result();
        $data['satuanakhir'] = $this->db->get('tb_satuan')->result();
        $data['konversi'] =$this->M_Barang->getkonversi($idbarang);
        $this->load->view('template/sidebar.php', $data);
        $this->load->view('barang/tambahkonversi',$data); 
        $this->load->view('template/footer');
    }

    function cek_hargajual(){
        $tabel = 'tb_barang';
        $kode = $this->input->post('hargajual');
        $harga = explode("-", $kode);
        $hargabeli = preg_replace('/([^0-9]+)/','',$harga[1]);
        $haragjuall = preg_replace('/([^0-9]+)/','',$harga[0]);
        if(int($hargajuall)>int($hargabeli)){ 
            echo '2';
        }else{
            echo '1';
        }
         
    }



    public function tambah()
    {   
        $hasil_kode = $this->M_Barang->cek();

        if(count($hasil_kode)==0){ 
            $this->M_Barang->tambahdata();
            if(preg_replace('/([^0-9]+)/','',$this->input->post('beli')) > preg_replace('/([^0-9]+)/','',$this->input->post('jual'))){
                $this->session->set_flashdata('flash','
                <div class="alert alert-warning alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-check"></i> Success!</h5>
                Harga Beli Lebih Besar dari Harga Jual.
                </div>      
                ');
            } else {
                
                $this->session->set_flashdata('flash','
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-check"></i> Success!</h5>
                Data berhasil di Tambahkan.
                </div>      
                ');
            }
        }else{
            $this->session->set_flashdata('flash','
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Gagal!</h5>
            Cek Kembali Inputan Anda.
            </div>      
            ');
        }
        redirect('barang');
    }

    public function tambahkonversi()
    {   
        $this->M_Barang->tambahkonversi();

        $this->session->set_flashdata('SUCCESS', "Data Berhasil Di Tambahkan!!");
        redirect('barang-view/'.$this->input->post('id'));
    }

    function view($ida)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '6';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] =$this->M_Barang->getspek($ida);
        $data['konversi'] =$this->M_Barang->getkonversi($ida);
        $data['satuan'] = $this->db->get('tb_satuan')->result();
        $this->load->view('barang/detail',$data); 
        $this->load->view('template/footer');
    }

    function edit($ida)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '6';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] =$this->M_Barang->getspek($ida);
        $data['satuan'] = $this->db->get('tb_satuan')->result();
        $this->load->view('barang/edit',$data); 
        $this->load->view('template/footer');
    }


    function editkonversi($ida, $idbarang)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '6';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);
        $data['konversi'] =$this->M_Barang->getdetailkonversi($ida);
        $data['satuanawal'] = $this->db->get('tb_satuan')->result();
        $data['satuanakhir'] = $this->db->get('tb_satuan')->result();
        $data['konversiall'] =$this->M_Barang->getkonversi($idbarang);
        $this->load->view('barang/editkonversi',$data); 
        $this->load->view('template/footer');
    }
    
    function update()
    {   
        $this->M_Barang->edit();
        $this->session->set_flashdata('SUCCESS', "Data Berhasil Di Rubah!!");
        redirect('barang');
    }


    function updatekonversi()
    {   
        $this->M_Barang->updatekonversi();
        $this->session->set_flashdata('SUCCESS', "Data Berhasil Di Rubah!!");
        redirect('barang-view/'.$this->input->post('id'));
    }

    function hapus($id){
        $where = array('id_barang' => $id);

        $this->M_Setting->delete($where,'tb_barang');
        $this->session->set_flashdata('SUCCESS', "Data Berhasil di Hapus!!");
        redirect('barang');
    }

    function hapuskonversi($id, $idbarang){
        $where = array('id_konversi' => $id);

        $this->M_Setting->delete($where,'tb_konversi');
        $this->session->set_flashdata('SUCCESS', "Data Berhasil di Hapus!!");
        redirect('barang-view/'.$idbarang);
    }


    function stokbarang()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '11';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '11'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] = $this->M_Barang->getall();
        $this->load->view('barang/stok',$data); 
        $this->load->view('template/footer');
    }


    function mutasi($i)
     {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '13';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '13'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '13'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '13'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] =$this->M_Barang->getspek($i);
        $data['mutasi'] = $this->M_Barang->getmutasi($i);
        $this->load->view('barang/mutasi',$data); 
        $this->load->view('template/footer');
    }


    function stok()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '11';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '11'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] = $this->M_Barang->stok();
        $this->load->view('barang/stok',$data); 
        $this->load->view('template/footer');
    }
    function stokbsj()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '11';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '11'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] = $this->M_Barang->stokbsj();
        $this->load->view('barang/stok',$data); 
        $this->load->view('template/footer');
    }

    function stokbk()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '11';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '11'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '11'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] = $this->M_Barang->stokbk();
        $this->load->view('barang/stok',$data); 
        $this->load->view('template/footer');
    }

    function cek_kodebarang(){
        $tabel = 'tb_barang';
        $cek = 'kodebarang';
        $kode = $this->input->post('kodebarang');
        $hasil_kode = $this->M_Setting->cek($cek,$kode,$tabel);
        if(count($hasil_kode)!=0){ 
            echo '1';
        }else{
            echo '2';
        }
         
    }
}