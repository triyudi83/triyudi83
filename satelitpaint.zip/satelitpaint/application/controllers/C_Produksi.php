<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class C_Produksi extends CI_Controller{
    
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library('session');
        $this->load->library('Datatables', 'datatables');
        $this->load->model('M_Produksi');
        $this->load->model('M_Resep');
        $this->load->model('M_Barang');
        $this->load->model('M_Setting');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

    function index()
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '9';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '9'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '9'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '9'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $this->load->view('template/sidebar.php', $data);
        $data['barang'] = $this->M_Barang->stok();
        $data['produksi'] = $this->M_Produksi->getall();
        $data['id_produksi'] = $this->M_Produksi->cekkodeproduksi();
        $this->load->view('produksi/index',$data); 
        $this->load->view('template/footer');
    }

    public function cekresep()
    {   
        $cek = $this->M_Resep->getbarangresep($this->input->post('id_barangjadi'));
        if(count($cek) != NULL){
            redirect('produksi-add/'.$this->input->post('id_barangjadi'));
        } else {

            $this->session->set_flashdata('flash','
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-close"></i> Gagal!</h5>
            Resep Tidak Ada.
          </div>      
                ');
            redirect('produksi');
        }
    }

    function add($idbarang)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '9';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['barangbaku'] = $this->M_Barang->barangbkbsj($idbarang);
        $data['barang'] =$this->M_Barang->getspek($idbarang);
        $this->load->view('template/sidebar.php', $data);
        $this->load->view('produksi/tambah',$data); 
        $this->load->view('template/footer');
    }

     function tambah($id_produksi)
    {
        $modul = 'BP/no/tglblnthn';
        date_default_timezone_set('Asia/Jakarta');
        $tgl = date('dmY');
        $modul = str_replace("tglblnthn", $tgl, $modul);
        $data = $this->M_Produksi->cekproduksibln();
        $no = count($data) + 1;
        if ($no<10){
            $no = '000'.$no;
        } elseif ($no<100) {
            $no = '00'.$no;
        } elseif ($no<1000) {
            $no = '0'.$no;
        } else {
            $no = $no;
        }
        $kode2 = str_replace("no", $no, $modul);

        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '9';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['barangbaku'] = $this->M_Barang->barangbkbsj();
        $data['barang'] =$this->M_Barang->stok();
        // $id_produksi = $this->M_Produksi->cekkodeproduksi();
        // if($id_produksi != NULL){
        $data['id_produksi'] = $id_produksi;
        $data['kode'] = $kode2;
        $data['bahan'] = $this->M_Produksi->bahan($id_produksi);
        $data['resep'] = $this->db->get('tb_resep')->result();
        // } else {
        // }
        $this->load->view('template/sidebar.php', $data);
        $this->load->view('produksi/produksi-tambah',$data); 
        $this->load->view('template/footer');
    }

    public function simpan()
    {   
        $tabel = 'tb_produksi';
        $cek = 'id_produksi';
        $kode = $this->input->post('id_produksi');
        $hasil_kode = $this->M_Setting->cek($cek,$kode,$tabel);
        if(count($hasil_kode)!=0){ 
             $this->M_Produksi->editbarang();
            $data = $this->M_Produksi->getspek($this->input->post('id_produksi'));
        }else{
            $data = $this->M_Produksi->tambahdata();
        }

        echo json_encode($data);
    }

    public function simpanbarangbaku()
    {   
        $barangbaku = $this->M_Barang->getspek($this->input->post('barang_baku'));
        foreach ($barangbaku as $barangbaku){
            $stokawalbaku = $barangbaku->stok;
            if($stokawalbaku > $this->input->post('qtt')){
                $this->M_Barang->tambahmutasibahanbakuprod($this->input->post('barang_baku'),  $this->input->post('qtt'));
                $stokakhir = $stokawalbaku - $this->input->post('qtt');
                $this->M_Barang->updatebarangbaku($stokakhir, $this->input->post('barang_baku'));

                $user = array(
                    'id_produksi' => $this->input->post('id_produksi'),
                    'id_bahanbaku' => $this->input->post('barang_baku'),
                    'qtt' => $this->input->post('qtt'),
                    'id_resep' => $this->input->post('id_resep'),
                    'hargabahan' => $this->input->post('hargabahan')
                );

                $this->M_Produksi->simpanbarangbaku($user);
                $id_produksi=$this->input->post('id_produksi');

                $data = $this->M_Produksi->bahan($id_produksi);

            } else { 
                $data = 'error';
            }
                echo json_encode($data);
            
        }


         
    }

    public function dtl(){
            $id_produksi=$this->input->post('id_produksi');
            $data = $this->M_Produksi->bahan($id_produksi);
            echo json_encode($data);
    }

    public function biaya(){
            $id_produksi=$this->input->post('id_produksi');
            $data = $this->M_Produksi->biaya($id_produksi);
            echo json_encode($data);
    }

    function hapusdtl(){
        $where = array('id_dtlproduksi' => $this->input->post('kode'));

        $data = $this->M_Setting->delete($where,'tb_dtlproduksi');
            echo json_encode($data);
    }

     function hapusbiaya(){
        $where = array('id_biayaproduksi' => $this->input->post('kode'));

        $data = $this->M_Setting->delete($where,'tb_biayaproduksi');
            echo json_encode($data);
    }

     public function simpanbiaya()
    {   
        $data = $this->M_Produksi->simpanbiaya();

        echo json_encode($data);
    }

     public function getspek()
    {   
        $data = $this->M_Produksi->getspek($this->input->post('kode'));

        echo json_encode($data);
    }

    public function simpanproduksi()
    {   
        $this->M_Produksi->update();

         $barang = $this->M_Barang->getspek($this->input->post('id_baranghasil'));
        foreach ($barang as $barang){
            $stoksjawal = $barang->stoksj;
            $stokawal = $barang->stok;
            $hppawal = $barang->hpp;
        }
        
       
        if($this->input->post('jenisbarang') == 'barang setengah jadi'){
            $stoksjakhir = $stoksjawal + $this->input->post('qtt');
            $this->M_Barang->updatebarangsj($stoksjakhir);
        } else {
            $this->M_Barang->tambahmutasiproduksi();
            $biayabb = preg_replace('/([^0-9]+)/','',$this->input->post('biayabahanbaku'));
            $biayall =  preg_replace('/([^0-9]+)/','',$this->input->post('biayalainlain'));
            $biayaprod = $biayabb + $biayall;
            $stokakhir = $stokawal + $this->input->post('qtt');            
            $hpp = (($hppawal*$stokawal) + $biayaprod)/$stokakhir;
            $this->M_Barang->updatebarang($stokakhir, $this->input->post('id_baranghasil'), $hpp);

            
        }

        $this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Tambahkan.
          </div>      
                ');
        redirect('produksi-cetak/'.$this->input->post('id_produksi'));

    }

     function view($id_produksi)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '9';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);

        $data['produksi'] = $this->M_Produksi->getspek($id_produksi);
        $data['bahan'] = $this->M_Produksi->bahan($id_produksi);
        $data['ll'] = $this->M_Produksi->biaya($id_produksi);
        $this->load->view('produksi/produksi-view',$data); 
        $this->load->view('template/footer');
    }

    function cetak($id_produksi)
    {
        $this->load->view('template/header');
        $id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '9';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);

        $data['produksiall'] = $this->M_Produksi->getspek($id_produksi);
        $data['bahan'] = $this->M_Produksi->bahan($id_produksi);
        $data['ll'] = $this->M_Produksi->biaya($id_produksi);
        $this->load->view('produksi/cetak',$data); 
        // $this->load->view('template/footer');
    }
    
}