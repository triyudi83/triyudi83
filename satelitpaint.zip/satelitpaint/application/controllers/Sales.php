<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->model('M_Setting');
        $this->load->model('M_Sales');
        // $this->load->model('M_Berita');
        // $this->load->model('M_User');
        // $this->load->model('M_Donasi');
        // $this->load->model('M_Level');
        if(!$this->session->userdata('id_user')){
             redirect('C_Login');
        }
    }

    public function index(){
        $this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '0';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '2'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '2'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '2'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;

		$data['database'] = $this->M_Sales->index();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('sales/index',$data);
		$this->load->view('template/footer.php');
    }
    public function tambah(){
           
        $this->form_validation->set_rules('namasales','Nama Suplier','required');
        $this->form_validation->set_rules('id_provinsi','Provinsi','required');
        $this->form_validation->set_rules('id_kota','Kabupaten / Kota','required');
        $this->form_validation->set_rules('id_kecamatan','Kecamatan','required');
        $this->form_validation->set_rules('alamat','Alamat','required');
        $this->form_validation->set_rules('tlf','Telepon','required');
		if ($this->form_validation->run() == FALSE)
		{
            $this->load->view('template/header.php');
            $id = $this->session->userdata('tipeuser');
            $data['activeMenu'] = '0';
            $data['master'] = $this->M_Setting->getmenumaster($id);
            $data['setting'] = $this->M_Setting->getmenusetting($id);
            $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
            $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
            $data['stok'] = $this->M_Setting->getmenustok($id);
            $data['acc'] = $this->M_Setting->getmenuacc($id);
            $data['laporan'] = $this->M_Setting->getmenulaporan($id);
            $data['provinsi'] = $this->M_Setting->getprovinsi();
            $this->load->view('template/sidebar.php', $data);
            $this->load->view('sales/tambah',$data);
            $this->load->view('template/footer.php');
		}
		else
		{
			$this->M_Sales->save();
			$this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Tambahkan.
          </div>      
				');
			redirect ('/sales');
		}
    }
    public function delete($id){
		$this->M_Sales->delete($id);
        $this->session->set_flashdata('flash','
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fa fa-check"></i> Success!</h5>
        Data berhasil di Hapus.
      </div>      
				');
		redirect('/sales');
	}
    public function edit($id){
        $data['database'] = $this->M_Sales->getSalesById($id);
        if(empty($data['database'])){
            redirect('/sales');
        }
        else{
        $id_prov = $data['database']->id_prov;
        $id_kota = $data['database']->id_kota;

        $this->form_validation->set_rules('namasales','Nama Suplier','required');
        $this->form_validation->set_rules('id_provinsi','Provinsi','required');
        $this->form_validation->set_rules('id_kota','Kabupaten / Kota','required');
        $this->form_validation->set_rules('id_kecamatan','Kecamatan','required');
        $this->form_validation->set_rules('alamat','Alamat','required');
        $this->form_validation->set_rules('tlf','Telepon','required');
		if ($this->form_validation->run() == FALSE)
		{
            $this->load->view('template/header.php');
            $id = $this->session->userdata('tipeuser');
            $data['activeMenu'] = '0';
            $data['master'] = $this->M_Setting->getmenumaster($id);
            $data['setting'] = $this->M_Setting->getmenusetting($id);
            $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
            $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
            $data['stok'] = $this->M_Setting->getmenustok($id);
            $data['acc'] = $this->M_Setting->getmenuacc($id);
            $data['laporan'] = $this->M_Setting->getmenulaporan($id);
            $data['provinsi'] = $this->M_Setting->getprovinsi();
            $data['kota'] = $this->M_Setting->getAllkota($id_prov);
            $data['kecamatan'] = $this->M_Setting->getAllkecamatan($id_kota);
            $this->load->view('template/sidebar.php', $data);
            $this->load->view('sales/edit',$data);
            $this->load->view('template/footer.php');
		}
		else
		{
			$this->M_Sales->update();
			$this->session->set_flashdata('flash','
            <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Success!</h5>
            Data berhasil di Edit.
          </div>      
				');
			redirect ('sales');
		}
        }
    }
    public function view($id){
        $data['database'] = $this->M_Sales->getSalesById($id);
        if(empty($data['database'])){
            redirect('/sales');
        }
        else{
        $id_prov = $data['database']->id_prov;
        $id_kota = $data['database']->id_kota;
            $this->load->view('template/header.php');
            $id = $this->session->userdata('tipeuser');
            $data['activeMenu'] = '0';
            $data['master'] = $this->M_Setting->getmenumaster($id);
            $data['setting'] = $this->M_Setting->getmenusetting($id);
            $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
            $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
            $data['stok'] = $this->M_Setting->getmenustok($id);
            $data['acc'] = $this->M_Setting->getmenuacc($id);
            $data['laporan'] = $this->M_Setting->getmenulaporan($id);
            $data['provinsi'] = $this->M_Setting->getprovinsi();
            $data['kota'] = $this->M_Setting->getAllkota($id_prov);
            $data['kecamatan'] = $this->M_Setting->getAllkecamatan($id_kota);
            $this->load->view('template/sidebar.php', $data);
            $this->load->view('sales/view_sales',$data);
            $this->load->view('template/footer.php');
        }
    }

}
