<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Hutang extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->library('Datatables', 'datatables');
        $this->load->library('Serverside', 'serverside');
        $this->load->model('M_Setting');
        $this->load->model('M_Customer');
        $this->load->model('M_Barang');
        $this->load->model('M_Pembelian');
        $this->load->model('M_Hutang');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

	public function index()
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '16';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '16'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '16'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '16'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        
        $data['database'] = $this->M_Hutang->hutang();
        $data['sum'] = $this->M_Hutang->totalhutang();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('hutang/index',$data);
		$this->load->view('template/footer.php');
	}

    public function bayar($id){
        $this->M_Hutang->updatebayar($id);
        $data = $this->M_Hutang->detail($id);
        foreach ($data as $data) {
            $nota = $data['totalnota'];
            $limitawal = $data['limit'];
            $id_suplier = $data['id_suplier'];
            $limitskrg = $nota+$limitawal;
        }
        $this->M_Hutang->updatelimit($id_suplier, $limitskrg);
        redirect('hutang');
            
    }
}