<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Pembelian extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->library('Datatables', 'datatables');
        $this->load->library('Serverside', 'serverside');
        $this->load->model('M_Setting');
        $this->load->model('M_Suplier');
        $this->load->model('M_Barang');
        $this->load->model('M_Pembelian');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

	public function index()
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '14';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '14'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '14'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '14'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;

        $data['database'] = $this->M_Pembelian->index();
        $hari_ini = date("Y-m-d");
        $tgl_pertama = date('Y-m-01', strtotime($hari_ini));
        $tgl_terakhir = date('Y-m-t', strtotime($hari_ini));
        $data['sum'] = $this->M_Pembelian->sum($tgl_pertama,$tgl_terakhir);

		$this->load->view('template/sidebar.php', $data);
		$this->load->view('pembelian/pembelian',$data);
		$this->load->view('template/footer.php');
	}

	public function tambah()
	{
        $query = $this->db->query("SELECT MAX(id_pembelian) as max_id FROM tb_pembelian"); 
        $row = $query->row_array();
        $data['cek_id'] = $row['max_id']+1;
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['max_id'] = '0';
        $data['activeMenu'] = '14';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['database'] = $this->M_Suplier->index();
        $data['barang'] = $this->M_Barang->getall();
        $data['tb_suplier'] = $this->M_Suplier->index();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('pembelian/v_addpembelian');
		$this->load->view('template/footer.php');
	}
    
    public function add_cart(){
        $query = $this->db->query("SELECT MAX(id_pembelian) as max_id FROM tb_pembelian"); 
        $row = $query->row_array();
        $max_id = $row['max_id']+1;
        $id_suplier=$this->input->post('id_suplier');
        $jenispembayaran=$this->input->post('jenispembayaran');
        $limit_hutang=$this->input->post('limit_hutang');
        $jatuhtempo=date("Y-m-d", strtotime($this->input->post('jatuhtempo')));
        $id_pembelian=$this->input->post('id_pembelian');
        $id_barang=$this->input->post('id_barang');
        $qtt=preg_replace('/([^0-9]+)/','',$this->input->post('qtt'));
        $harga=preg_replace('/([^0-9]+)/','',$this->input->post('harga'));
        if($this->input->post('diskon')==null){
            $diskon = 0;
        }else{
            $diskon=preg_replace('/([^0-9]+)/','',$this->input->post('diskon'));
        }
        $subtotal = ($harga*$qtt)-$diskon;
        if($id_pembelian=='0'){
            $this->M_Pembelian->save_awal($max_id);
            $tb_dtlpembelian = array(
                'id_pembelian' => $max_id,
                'id_barang' => $id_barang,
                'id_suplier' => $id_suplier,
                'qtt' => $qtt,
                'harga' => $harga,
                'diskon' => $diskon,
                'subtotal' => $subtotal,
            );
            $this->M_Pembelian->detailPembelian($tb_dtlpembelian);    
        }else{
            $tb_dtlpembelian = array(
                'id_pembelian' => $id_pembelian,
                'id_barang' => $id_barang,
                'id_suplier' => $id_suplier,
                'qtt' => $qtt,
                'harga' => $harga,
                'diskon' => $diskon,
                'subtotal' => $subtotal,
            );
            $this->M_Pembelian->detailPembelian($tb_dtlpembelian);
        }
        echo json_encode($tb_dtlpembelian);
    }
    public function update_all(){
        $id_pembelian=$this->input->post('id_pembelian');
        $cek = $this->db->get_where('tb_pembelian',['id_pembelian' => $id_pembelian])->row_array();
        $cek_jenis = $cek['jenispembayaran'];
        $id_suplier = $cek['id_suplier'];
        $cek1 = $this->db->get_where('tb_suplier',['id_suplier' => $id_suplier])->row_array();
        $cek_limit = $cek1['limit'];
        $subtotalbawah=$this->input->post('subtotalbawah');
        if($this->input->post('diskon1')==null){
            $diskon1 = 0;
        }else{
            $diskon1=$this->input->post('diskon1');
        }
        $total=$this->input->post('total');
        $limit = $cek_limit-$total;
        if($cek_jenis=='kredit'){
            $this->form_validation->set_rules('total', 'Total', 'numeric|less_than_equal_to['.$cek_limit.']', 
                array('required'=> '%s wajib diisi.',
                        'less_than_equal_to'=> '%s melebihi limit hutang',    
                        'numeric'=> '%s harus berisi angka.',
                 ));
            $this->form_validation->set_rules('diskon1', 'Diskon', 'numeric|less_than_equal_to['.$subtotalbawah.']', 
            array('required'=> '%s wajib diisi.',
                    'less_than_equal_to'=> '%s melebihi total',    
                    'numeric'=> '%s harus berisi angka.',
             ));
            $this->form_validation->set_error_delimiters('', '');
            if ($this->form_validation->run() == FALSE){
                $result['error'] = array(
                    'total'=>form_error('total'),
                    'diskon1'=>form_error('diskon1')
                );
            }else{
                $this->db->where('id_suplier',$id_suplier);
                $this->db->update('tb_suplier', ['limit'=>$limit]);
                $this->db->where('id_pembelian',$id_pembelian);
                $this->db->update('tb_pembelian', ['status'=>'Belum Lunas']);
                $data= array(
                    'subtotalnota' => $subtotalbawah,
                    'diskonnota' => $diskon1,
                    'totalnota' => $total,
                );
                
                $this->M_Pembelian->pembelian_update($id_pembelian,$data);
                $this->M_Pembelian->updateTrigger($id_pembelian);
                $result['success']= 'pembelian-view/'.$id_pembelian;
            }
        }else{
            $this->form_validation->set_rules('diskon1', 'Diskon', 'numeric|less_than_equal_to['.$subtotalbawah.']', 
            array('required'=> '%s wajib diisi.',
                    'less_than_equal_to'=> '%s melebihi total',    
                    'numeric'=> '%s harus berisi angka.',
             ));
            $this->form_validation->set_error_delimiters('', '');
            if ($this->form_validation->run() == FALSE){
                $result['error'] = array(
                    'diskon1'=>form_error('diskon1')
                );
            }else{
                $data= array(
                    'subtotalnota' => $subtotalbawah,
                    'diskonnota' => $diskon1,
                    'totalnota' => $total,
                );
                
                $this->M_Pembelian->pembelian_update($id_pembelian,$data);
                $this->M_Pembelian->updateTrigger($id_pembelian);
                $result['success']= 'pembelian-view/'.$id_pembelian;
            }
        }
        echo json_encode($result);
        
    }
    public function back(){
        $data= array('kembali' => 'btn_kembali',);
        echo json_encode($data);
    }
    public function cart_update(){
        $id=$this->input->post('id_dtlpembelian');
        $id_pembelian=$this->input->post('id_pembelian');
        $id_barang=$this->input->post('id_barang');
        $qtt=$this->input->post('qtt');
        $harga=preg_replace('/([^0-9]+)/','',$this->input->post('harga'));
        $diskon=preg_replace('/([^0-9]+)/','',$this->input->post('diskon'));
        $subtotal = ($harga*$qtt)-$diskon;
        $data= array(
            'id_pembelian' => $id_pembelian,
            'id_barang' => $id_barang,
            'qtt' => $qtt,
            'harga' => $harga,
            'diskon' => $diskon,
            'subtotal' => $subtotal,
        );
        $this->M_Pembelian->detailPembelianUpdate($data,$id);
        echo json_encode($data);
    }
    public function json(){
        $id_pembelian=$this->input->post('id_pembelian');    
        header('Content-Type: application/json');
        echo $this->M_Pembelian->get_detailpembelian($id_pembelian);
    }
    public function update_detail(){
        $id=$this->input->post('id');
        $data=$this->M_Pembelian->allposts_count($id);
        echo json_encode($data);
            
    }
    public function delete_dtlpembelian(){
        $id = $this->input->post('id');
        $this->M_Pembelian->delete_dtlpembelian($id);
        echo json_encode('data berhasil dihapus');
    }
    
    public function delete($id){
       $this->M_Pembelian->delete($id);
       $data['redirect']= 'pembelian';
       redirect('pembelian');
	}

    public function batal($id){
       $this->M_Pembelian->delete($id);
       $data['redirect']= 'pembelian';
       echo json_encode($data);
	}

    public function view($id_pembelian)
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '14';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '14'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '14'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '14'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        
        $data['database'] = $this->M_Pembelian->cart($id_pembelian);   
        $data['pembelian'] = $this->M_Pembelian->viewpembelian($id_pembelian);   
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('pembelian/pembelian_view',$data);
		$this->load->view('template/footer.php');
	}

    public function suplier(){
        header('Content-Type: application/json');
        echo $this->M_Pembelian->get_all_suplier();
    }
    public function getbarang(){
        header('Content-Type: application/json');
        echo $this->M_Pembelian->get_all_barang();
    }
    public function cek()
    {
        $this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['max_id'] = '0';
        $data['activeMenu'] = '14';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $data['database'] = $this->M_Suplier->index();
        $data['barang'] = $this->M_Barang->getall();
        $data['tb_suplier'] = $this->M_Suplier->index();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('pembelian/v_hutang');
		$this->load->view('template/footer.php');
    }
}