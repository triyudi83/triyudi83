<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Satuan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->model('M_Setting');
        $this->load->model('M_Satuan');
        // $this->load->model('M_Berita');
        // $this->load->model('M_User');
        // $this->load->model('M_Donasi');
        // $this->load->model('M_Level');
        if(!$this->session->userdata('id_user')){
             redirect('C_Login');
        }
    } 

	public function index()
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '0';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
		$tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '5'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '5'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '5'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        
		$data['tb_satuan'] = $this->M_Satuan->index();
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('satuan/index',$data);
		$this->load->view('template/footer.php');
	}
	public function getdata(){
		$data['satuan'] = $this->M_Satuan->index();
		echo json_encode($data);
	}
	public function simpan_data(){
		$this->M_Satuan->save();
		$this->session->set_flashdata('flash','Data Barang Berhasil Ditambahkan');
		redirect ('satuan/tambah');
		
	}
	public function edit($id){
		$data['tb_satuan'] = $this->M_Satuan->getSatuanById($id);
		if(empty($data['tb_satuan'])){
            redirect('/satuan');
        }
        else{
		$this->form_validation->set_rules('satuan','Satuan','trim|required');
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('template/header.php');
			$id = $this->session->userdata('tipeuser');
			$data['activeMenu'] = '0';
			$data['master'] = $this->M_Setting->getmenumaster($id);
			$data['setting'] = $this->M_Setting->getmenusetting($id);
			$data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
			$data['produksi'] = $this->M_Setting->getmenuproduksi($id);
			$data['stok'] = $this->M_Setting->getmenustok($id);
			$data['acc'] = $this->M_Setting->getmenuacc($id);
			$data['laporan'] = $this->M_Setting->getmenulaporan($id);
			$this->load->view('template/sidebar.php', $data);
			$this->load->view('satuan/edit',$data);
			$this->load->view('template/footer.php');
		}
		else
		{
				$this->M_Satuan->update();
				$this->session->set_flashdata('flash','
				<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<h5><i class="icon fa fa-check"></i> Success!</h5>
				Data berhasil di Edit.
			  </div>      
				');
				redirect ('satuan');	
		}
	}
		
	}
	public function delete($id){
		$this->M_Satuan->delete($id);
		$this->session->set_flashdata('flash','
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		<h5><i class="icon fa fa-check"></i> Success!</h5>
		Data berhasil di Hapus.
	  </div>      
				');
		redirect ('satuan');	
	}
	public function tambah(){
		
		$this->form_validation->set_rules('satuan','Satuan','required',array('required' => 'Data Satuan tidak boleh kosong'));
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('template/header.php');
			$id = $this->session->userdata('tipeuser');
			$data['activeMenu'] = '0';
			$data['master'] = $this->M_Setting->getmenumaster($id);
			$data['setting'] = $this->M_Setting->getmenusetting($id);
			$data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
			$data['produksi'] = $this->M_Setting->getmenuproduksi($id);
			$data['stok'] = $this->M_Setting->getmenustok($id);
			$data['acc'] = $this->M_Setting->getmenuacc($id);
			$data['laporan'] = $this->M_Setting->getmenulaporan($id);
			$this->load->view('template/sidebar.php', $data);
			$this->load->view('satuan/tambah',$data);
			$this->load->view('template/footer.php');
		}
		else
		{
				$this->M_Satuan->save();
				$this->session->set_flashdata('flash','
				<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				<h5><i class="icon fa fa-check"></i> Success!</h5>
				Data berhasil di Tambahkan.
			  </div>      
				');
				redirect ('satuan');				
		}
	}

	public function view($id){
		$data['tb_satuan'] = $this->M_Satuan->getSatuanById($id);
		if(empty($data['tb_satuan'])){
            redirect('/satuan');
        }
        else{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
		$data['activeMenu'] = '0';
		$data['master'] = $this->M_Setting->getmenumaster($id);
		$data['setting'] = $this->M_Setting->getmenusetting($id);
		$data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
		$data['produksi'] = $this->M_Setting->getmenuproduksi($id);
		$data['stok'] = $this->M_Setting->getmenustok($id);
		$data['acc'] = $this->M_Setting->getmenuacc($id);
		$data['laporan'] = $this->M_Setting->getmenulaporan($id);
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('satuan/view_satuan',$data);
		$this->load->view('template/footer.php');
		}		
	}
}
