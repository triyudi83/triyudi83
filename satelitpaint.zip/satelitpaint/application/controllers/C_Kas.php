<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class C_Kas extends CI_Controller{
    
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library('session');
        $this->load->model('M_Kas');
        $this->load->model('M_Setting');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

    function index(){
        //menu kas keluar = 19
        $this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '19';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);

        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '19'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '19'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '19'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        $data['database'] = $this->M_Kas->index();
        $hari_ini = date("Y-m-d");
        $tgl_pertama = date('Y-m-01', strtotime($hari_ini));
        $tgl_terakhir = date('Y-m-t', strtotime($hari_ini));
        $data['sum'] = $this->M_Kas->sum($tgl_pertama,$tgl_terakhir);

		$this->load->view('template/sidebar.php', $data);
		$this->load->view('kas/v_index.php',$data);
		$this->load->view('template/footer.php');

    }
    function tambah(){
        $this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '0';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
		$this->load->view('template/sidebar.php', $data);
		$this->load->view('kas/v_addkas.php');
		$this->load->view('template/footer.php');
    }
    public function add(){
        $id = $this->session->userdata('id_user');
        $tgl = date("Y-m-d", strtotime($this->input->post('tgl')));
        $keterangan = $this->input->post('ket');
        $nominal = preg_replace('/([^0-9]+)/','',$this->input->post('rupiah'));
        $data = array(
            'tglkas' => $tgl,
            'ket'   => $keterangan,
            'nominal' => $nominal,
            'id_user' => $id
        );
        $this->M_Kas->simpan($data);
        $this->session->set_flashdata('flash','
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fa fa-check"></i> Success!</h5>
        Data berhasil di Simpan.
        </div>      
        ');
		redirect ('kaskeluar');
    }
    public function delete($id){
        $this->M_Kas->delete($id);
        $this->session->set_flashdata('flash','
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fa fa-check"></i> Success!</h5>
        Data berhasil di Hapus.
        </div>      
        ');
		redirect ('kaskeluar');
    }
    public function edit($id) 
    {
        $row = $this->M_Kas->get_by_id($id);
        if ($row) {
            $data = array(
                'id_kas' =>$row->id_kas,
                'tglkas' =>$row->tglkas,
                'ket' =>$row->ket,
                'nominal' =>$row->nominal
            );

            $this->load->view('template/header.php');
			$id = $this->session->userdata('tipeuser');
			$data['activeMenu'] = '19';
			$data['master'] = $this->M_Setting->getmenumaster($id);
			$data['setting'] = $this->M_Setting->getmenusetting($id);
			$data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
			$data['produksi'] = $this->M_Setting->getmenuproduksi($id);
			$data['stok'] = $this->M_Setting->getmenustok($id);
			$data['acc'] = $this->M_Setting->getmenuacc($id);
			$data['laporan'] = $this->M_Setting->getmenulaporan($id);
			$this->load->view('template/sidebar.php', $data);
			$this->load->view('kas/v_edit',$data);
			$this->load->view('template/footer.php');
           
        } else {
            $this->session->set_flashdata('flash', '
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Gagal!</h5>
            Data Tidak Ditemukan.
            </div>');
            redirect('kaskeluar');
        }
    }
    public function update_action(){
        $id = $this->input->post('id_kas');
        $keterangan = $this->input->post('ket');
        $nominal = preg_replace('/([^0-9]+)/','',$this->input->post('rupiah'));
        $data = array(
            'ket'   => $keterangan,
            'nominal' => $nominal,
            'id_user' => $id
        );
        $this->M_Kas->update($id,$data);
        $this->session->set_flashdata('flash','
        <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fa fa-check"></i> Success!</h5>
        Data berhasil di Edit.
        </div>      
        ');
		redirect ('kaskeluar');
    }
    public function view($id)
    {
        $row = $this->M_Kas->get_by_id($id);
        if ($row) {
            $data = array(
                'id_kas' =>$row->id_kas,
                'tglkas' =>$row->tglkas,
                'ket' =>$row->ket,
                'nominal' =>$row->nominal
            );

            $this->load->view('template/header.php');
			$id = $this->session->userdata('tipeuser');
			$data['activeMenu'] = '19';
			$data['master'] = $this->M_Setting->getmenumaster($id);
			$data['setting'] = $this->M_Setting->getmenusetting($id);
			$data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
			$data['produksi'] = $this->M_Setting->getmenuproduksi($id);
			$data['stok'] = $this->M_Setting->getmenustok($id);
			$data['acc'] = $this->M_Setting->getmenuacc($id);
			$data['laporan'] = $this->M_Setting->getmenulaporan($id);
			$this->load->view('template/sidebar.php', $data);
			$this->load->view('kas/v_kas',$data);
			$this->load->view('template/footer.php');
           
        } else {
            $this->session->set_flashdata('flash', '
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fa fa-check"></i> Gagal!</h5>
            Data Tidak Ditemukan.
            </div>');
            redirect('kaskeluar');
        }
    }

}