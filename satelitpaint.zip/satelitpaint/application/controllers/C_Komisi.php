<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Komisi extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->library(array('session','form_validation'));
        $this->load->library('Datatables', 'datatables');
        $this->load->library('Serverside', 'serverside');
        $this->load->model('M_Setting');
        $this->load->model('M_Customer');
        $this->load->model('M_Barang');
        $this->load->model('M_Penjualan');
        $this->load->model('M_Sales');
        $this->load->model('M_Komisi');
        if(!$this->session->userdata('id_user')){
            redirect('C_Login');
        }
    }

	public function index()
	{
		$this->load->view('template/header.php');
		$id = $this->session->userdata('tipeuser');
        $data['activeMenu'] = '18';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $tabel = 'tb_akses';
        $edit = array(
            'tipeuser' => $id,
            'edit' => '1',
            'id_menu' => '18'
        );
        $hasiledit = $this->M_Setting->cekakses($tabel, $edit);
        if(count($hasiledit)!=0){ 
            $tomboledit = 'aktif';
        } else {
            $tomboledit = 'tidak';
        }

        $hapus = array(
            'tipeuser' => $id,
            'delete' => '1',
            'id_menu' => '18'
        );
        $hasilhapus = $this->M_Setting->cekakses($tabel, $hapus);
        if(count($hasilhapus)!=0){ 
            $tombolhapus = 'aktif';
        } else{
            $tombolhapus = 'tidak';
        }

         $tambah = array(
            'tipeuser' => $id,
            'add' => '1',
            'id_menu' => '18'
        );
        $hasiltambah = $this->M_Setting->cekakses($tabel, $tambah);
        if(count($hasiltambah)!=0){ 
            $tomboltambah = 'aktif';
        } else{
            $tomboltambah = 'tidak';
        }
        $data['aksestambah'] = $tomboltambah;
        $data['akseshapus'] = $tombolhapus;
        $data['aksesedit'] = $tomboledit;
        
        $data['Komisi'] = $this->M_Komisi->index();

		$this->load->view('template/sidebar.php', $data);
		$this->load->view('komisi/index',$data);
		$this->load->view('template/footer.php');
	}

     public function tambah()
    {
       
        $this->load->view('template/header.php');
        $id = $this->session->userdata('tipeuser');
        $data['max_id'] = '0';
        $data['activeMenu'] = '18';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);


        $data['sales'] = $this->M_Sales->index();
        $this->load->view('komisi/komisi-tambah.php', $data);
        $this->load->view('template/footer.php');
    }

    public function get_penjualan()
    {   

        $tgl = $this->input->post('tgl');
        $id_sales = $this->input->post('id_sales');

        $tanggal = explode(' - ',$tgl);
        $tanggalawal = explode('/',$tanggal[0]);
        $tglawal = $tanggalawal[2].'-'.$tanggalawal[1].'-'.$tanggalawal[0];
        $tanggalakhir = explode('/',$tanggal[1]);
        $tglakhir = $tanggalakhir[2].'-'.$tanggalakhir[1].'-'.$tanggalakhir[0];

        $hasil = $this->M_Komisi->search($id_sales, $tglawal, $tglakhir);

        echo json_encode($hasil);
    }

     public function add()
    {   
        $tgl = $this->input->post('tgl');
        $tanggal = explode(' - ',$tgl);
        $tanggalawal = explode('/',$tanggal[0]);
        $tglawal = $tanggalawal[2].'-'.$tanggalawal[1].'-'.$tanggalawal[0];
        $tanggalakhir = explode('/',$tanggal[1]);
        $tglakhir = $tanggalakhir[2].'-'.$tanggalakhir[1].'-'.$tanggalakhir[0];

            $this->M_Komisi->tambahdata($tglawal, $tglakhir);
                
                $this->session->set_flashdata('flash','
                <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fa fa-check"></i> Success!</h5>
                Data berhasil di Tambahkan.
                </div>      
                ');
        redirect('komisi');
    }

    function hapus($id){
        $where = array('id_komisi' => $id);

        $this->M_Setting->delete($where,'tb_komisi');
        $this->session->set_flashdata('SUCCESS', "Data Berhasil di Hapus!!");
        redirect('komisi');
    }

    public function view($id){
        $this->load->view('template/header.php');
        $id = $this->session->userdata('tipeuser');
        $data['max_id'] = '0';
        $data['activeMenu'] = '18';
        $data['master'] = $this->M_Setting->getmenumaster($id);
        $data['setting'] = $this->M_Setting->getmenusetting($id);
        $data['transaksi'] = $this->M_Setting->getmenutransaksi($id);
        $data['produksi'] = $this->M_Setting->getmenuproduksi($id);
        $data['stok'] = $this->M_Setting->getmenustok($id);
        $data['acc'] = $this->M_Setting->getmenuacc($id);
        $data['laporan'] = $this->M_Setting->getmenulaporan($id);
        $this->load->view('template/sidebar.php', $data);


        $data['sales'] = $this->M_Sales->index();
        $this->load->view('komisi/komisi-view.php', $data);
        $this->load->view('template/footer.php');
    }
}