  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Development By &copy; 2021 <a href="https://hosterweb.co.id">HOSTERWEB INDONESIA</a>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark" style="display: none;">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->

<!-- <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script> -->
<script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>

<script src="<?php echo base_url() ?>assets/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  // $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url() ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="<?php echo base_url() ?>assets/bower_components/raphael/raphael.min.js"></script>
<script src="<?php echo base_url() ?>assets/bower_components/morris.js/morris.min.js"></script>
<!-- <script src="http://cdn.oesmith.co.uk/morris-0.4.1.min.js"></script> -->
<!-- Sparkline -->
<script src="<?php echo base_url() ?>assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
 <!-- jvectormap  -->
<script src="<?php echo base_url() ?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
 <!-- jQuery Knob Chart  -->
<script src="<?php echo base_url() ?>assets/bower_components/jquery-knob/dist/jquery.knob.min.js"></script>

<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url() ?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url() ?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="<?php echo base_url() ?>assets/dist/js/pages/dashboard.js"></script> -->
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/dist/js/demo.js"></script>

<script src="<?php echo base_url() ?>assets/dist/js/jquery.mask.min.js"></script>
<script src="<?php echo base_url() ?>assets/dist/js/terbilang.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url() ?>assets/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url() ?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url() ?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- page script -->


<!-- InputMask -->
<script src="<?php echo base_url() ?>assets/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url() ?>assets/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?php echo base_url() ?>assets/plugins/timepicker/bootstrap-timepicker.min.js"></script>

<!-- FLOT CHARTS -->
<script src="<?php echo base_url() ?>assets/bower_components/Flot/jquery.flot.js"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="<?php echo base_url() ?>assets/bower_components/Flot/jquery.flot.resize.js"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="<?php echo base_url() ?>assets/bower_components/Flot/jquery.flot.pie.js"></script>
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="<?php echo base_url() ?>assets/bower_components/Flot/jquery.flot.categories.js"></script>
<!-- Page script -->

<script src="<?php echo base_url() ?>assets/bower_components/chart.js/Chart.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url() ?>assets/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- CK Editor -->
<script src="<?php echo base_url() ?>assets/bower_components/ckeditor/ckeditor.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>


<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->

<script type="text/javascript" src="<?php echo base_url() ?>assets/Chart.js"></script>
<script src='<?php echo base_url() ?>assets/login/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js'></script>
<script src='<?php echo base_url() ?>assets/login/assets/libs/jszip/jszip.min.js'></script>
<script src='<?php echo base_url() ?>assets/login/assets/libs/datatables.net-buttons/js/buttons.html5.min.js'></script>

<!-- <script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('berita')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script> -->
<script src="<?= base_url() ?>assets/javascript/penjualan.js"></script>
<script src="<?= base_url() ?>assets/javascript/pembelian.js"></script>
<script src="<?= base_url() ?>assets/javascript/kaskeluar.js"></script>
<script>
    var ctx = document.getElementById("myChart").getContext('2d');
    var arrbulan = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
    var bulan = new Date().getMonth();
    var tahun = new Date().getFullYear();
    var myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ["Pendapatan", "Pengeluaran", "Hutang", "Laba Rugi"],
        datasets: [{
          label: 'Bulan '+arrbulan[bulan]+' '+tahun,
          data: [$('#grafikpendapatan').val(), $('#grafikpengeluaran').val(), $('#grafikhutang').val(), $('#grafiklaba').val()],
          backgroundColor: [
          'rgba(255,182,132,1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)'
          ],
          borderColor: [
          'rgba(255,99,132,1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero:true
            }
          }]
        }
      }
    });
  </script>
<script>
  $(function () {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    var areaChartCanvas = $('#areaChart').get(0).getContext('2d')
    // This will get the first returned node in the jQuery collection.
    var areaChart       = new Chart(areaChartCanvas)

    var areaChartData = {
      labels  : ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label               : 'Electronics',
          fillColor           : 'rgba(210, 214, 222, 1)',
          strokeColor         : 'rgba(210, 214, 222, 1)',
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label               : 'Digital Goods',
          fillColor           : 'rgba(60,141,188,0.9)',
          strokeColor         : 'rgba(60,141,188,0.8)',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    }

    var areaChartOptions = {
      //Boolean - If we should show the scale at all
      showScale               : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : false,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - Whether the line is curved between points
      bezierCurve             : true,
      //Number - Tension of the bezier curve between points
      bezierCurveTension      : 0.3,
      //Boolean - Whether to show a dot for each point
      pointDot                : false,
      //Number - Radius of each point dot in pixels
      pointDotRadius          : 4,
      //Number - Pixel width of point dot stroke
      pointDotStrokeWidth     : 1,
      //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
      pointHitDetectionRadius : 20,
      //Boolean - Whether to show a stroke for datasets
      datasetStroke           : true,
      //Number - Pixel width of dataset stroke
      datasetStrokeWidth      : 2,
      //Boolean - Whether to fill the dataset with a color
      datasetFill             : true,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio     : true,
      //Boolean - whether to make the chart responsive to window resizing
      responsive              : true
    }

    //Create the line chart
    areaChart.Line(areaChartData, areaChartOptions)

    //-------------
    //- LINE CHART -
    //--------------
    var lineChartCanvas          = $('#lineChart').get(0).getContext('2d')
    var lineChart                = new Chart(lineChartCanvas)
    var lineChartOptions         = areaChartOptions
    lineChartOptions.datasetFill = false
    lineChart.Line(areaChartData, lineChartOptions)

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieChart       = new Chart(pieChartCanvas)
    var PieData        = [
      {
        value    : 700,
        color    : '#f56954',
        highlight: '#f56954',
        label    : 'Chrome'
      },
      {
        value    : 500,
        color    : '#00a65a',
        highlight: '#00a65a',
        label    : 'IE'
      },
      {
        value    : 400,
        color    : '#f39c12',
        highlight: '#f39c12',
        label    : 'FireFox'
      },
      {
        value    : 600,
        color    : '#00c0ef',
        highlight: '#00c0ef',
        label    : 'Safari'
      },
      {
        value    : 300,
        color    : '#3c8dbc',
        highlight: '#3c8dbc',
        label    : 'Opera'
      },
      {
        value    : 100,
        color    : '#d2d6de',
        highlight: '#d2d6de',
        label    : 'Navigator'
      }
    ]
    var pieOptions     = {
      //Boolean - Whether we should show a stroke on each segment
      segmentShowStroke    : true,
      //String - The colour of each segment stroke
      segmentStrokeColor   : '#fff',
      //Number - The width of each segment stroke
      segmentStrokeWidth   : 2,
      //Number - The percentage of the chart that we cut out of the middle
      percentageInnerCutout: 50, // This is 0 for Pie charts
      //Number - Amount of animation steps
      animationSteps       : 100,
      //String - Animation easing effect
      animationEasing      : 'easeOutBounce',
      //Boolean - Whether we animate the rotation of the Doughnut
      animateRotate        : true,
      //Boolean - Whether we animate scaling the Doughnut from the centre
      animateScale         : false,
      //Boolean - whether to make the chart responsive to window resizing
      responsive           : true,
      // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
      maintainAspectRatio  : true,
      //String - A legend template
      legendTemplate       : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    pieChart.Doughnut(PieData, pieOptions)

    //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas                   = $('#barChart').get(0).getContext('2d')
    var barChart                         = new Chart(barChartCanvas)
    var barChartData                     = areaChartData
    barChartData.datasets[1].fillColor   = '#00a65a'
    barChartData.datasets[1].strokeColor = '#00a65a'
    barChartData.datasets[1].pointColor  = '#00a65a'
    var barChartOptions                  = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero        : true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines      : true,
      //String - Colour of the grid lines
      scaleGridLineColor      : 'rgba(0,0,0,.05)',
      //Number - Width of the grid lines
      scaleGridLineWidth      : 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines  : true,
      //Boolean - If there is a stroke on each bar
      barShowStroke           : true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth          : 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing         : 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing       : 1,
      //String - A legend template
      legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
      //Boolean - whether to make the chart responsive
      responsive              : true,
      maintainAspectRatio     : true
    }

    barChartOptions.datasetFill = false
    barChart.Bar(barChartData, barChartOptions)
  })
</script>
<style type="text/css">
  @media (min-width: 480px) {
    .row-xs-table {
        display: table;
        table-layout: fixed;
        width: 100%;
        height: 100%;
    }
    .col-xs-table {
        display: table-cell;
        float: none;
        height: 100%;
    }
}

@media (min-width: 768px) {
    .row-sm-table {
        display: table;
        table-layout: fixed;
        width: 100%;
        height: 100%;
    }
    .col-sm-table {
        display: table-cell;
        float: none;
        height: 100%;
    }
}

@media (min-width: 992px) {
    .row-md-table {
        display: table;
        table-layout: fixed;
        width: 100%;
        height: 100%;
    }
    .col-md-table {
        display: table-cell;
        float: none;
        height: 100%;
    }
}

@media (min-width: 1200px) {
    .row-lg-table {
        display: table;
        table-layout: fixed;
        width: 100%;
        height: 100%;
    }
    .col-lg-table {
        display: table-cell;
        float: none;
        height: 100%;
    }
}
</style>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker({
        locale: { format: 'DD/MM/YYYY' }})
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'DD/MM/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

  })
</script>

<script>
  $(document).ready(function(){ 
    //Initialize Select2 Elements
    $('.select2').select2()
    
    $('#example1').DataTable();
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    });

     $('.tanggalan').daterangepicker({
        timePicker: false,
        startDate: moment().startOf('hour'),
        endDate: moment().startOf('hour').add(32, 'hour'),
        locale: {
          format: 'DD.MM.YYYY'
        }
      });
     $('#datepicker').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('.tgl').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('#min').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('#max').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('#startDate').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('#endDate').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('#kasawal').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
     $('#kasakhir').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy"
      })
    //Date range picker with time picker
  })
</script>
<script>
  $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
    // Kita sembunyikan dulu untuk loadingnya
    $("#prov").change(function(){ // Ketika user mengganti atau memilih data provinsi
      var id_provinsi = $('#prov').val();
      if(id_provinsi != ''){
        $.ajax({
          type: "POST", // Method pengiriman data bisa dengan GET atau POST
          url: "<?php echo base_url("index.php/C_Setting/get_kota"); ?>", // Isi dengan url/path file php yang dituju
          data: {id_provinsi : $("#prov").val()}, // data yang akan dikirim ke file yang dituju
          dataType: "json",
          beforeSend: function(e) {
            if(e && e.overrideMimeType) {
              e.overrideMimeType("application/json;charset=UTF-8");
            }
          },
          success: function(response){ // Ketika proses pengiriman berhasil
            // set isi dari combobox kota
            // lalu munculkan kembali combobox kotanya
            
            $("#kota").html(response.list_kota).show();
            $('#kecamatan').html('<option value="">Pilih Kecamatan</option>');
          },
          error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
          }
        });
      }
      else{
        $('#kota').html('');
        $('#kecamatan').html('');
      }
    });
  });
  </script>

<script>
  $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
    // Kita sembunyikan dulu untuk loadingnya
    $("#kota").change(function(){ // Ketika user mengganti atau memilih data provinsi
      var kota = $('#kota').val();
      if(kota != ''){
        $.ajax({
          type: "POST", // Method pengiriman data bisa dengan GET atau POST
          url: "<?php echo base_url("index.php/C_Setting/get_kecamatan"); ?>", // Isi dengan url/path file php yang dituju
          data: {id_kota : $("#kota").val()}, // data yang akan dikirim ke file yang dituju
          dataType: "json",
          beforeSend: function(e) {
            if(e && e.overrideMimeType) {
              e.overrideMimeType("application/json;charset=UTF-8");
            }
          },
          success: function(response){ // Ketika proses pengiriman berhasil
            // set isi dari combobox kota
            // lalu munculkan kembali combobox kotanya
            $("#kecamatan").html(response.list_kec).show();
          },
          error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
          }
        });
      }else{
        $('#kecamatan').html('');
      }
    });
  });
  </script>

  <script type="text/javascript">
  function Angkasaja(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
    return true;
  }
</script>

<script type="text/javascript">
function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}
</script>
  
<script type="text/javascript">
    
    var rupiah = document.getElementById('rupiah');
    if(rupiah){
      rupiah.addEventListener('keyup', function(e){
        var value = $(this).val();
        // value = value.replace(/^(0*)/,"");
        // $(this).val(value);
        rupiah.value = formatRupiah(this.value, 'Rp. ');
      });
    }

    var qtt = document.getElementById('qtt');
    if(qtt){
      qtt.addEventListener('keyup', function(e){
        var value = $(this).val();
        // value = value.replace(/^(0*)/,"");
        // $(this).val(value);
        qtt.value = formatRupiah(this.value);
      });
    }

    var biayaprod = document.getElementById('biayaprod');
    if(biayaprod){
      biayaprod.addEventListener('keyup', function(e){
        var value = $(this).val();
        // value = value.replace(/^(0*)/,"");
        // $(this).val(value);
        biayaprod.value = formatRupiah(this.value, 'Rp. ');
      });
    }

    var diskon = document.getElementById('diskon');
    var diskon1 = document.getElementById('diskon1');
    if(diskon){
      diskon.addEventListener('keyup', function(e){
        var value = $(this).val();
        // value = value.replace(/^(0*)/,"");
        // $(this).val(value);
        diskon.value = formatRupiah(this.value, 'Rp. ');
      });
    }
    if(diskon1){
      diskon1.addEventListener('keyup', function(e){
        var value = $(this).val();
        // value = value.replace(/^(0*)/,"");
        // $(this).val(value);
        diskon1.value = formatRupiah(this.value, 'Rp. ');
      });
    }
    /* Fungsi formatRupiah */
    function formatRupiah(angka, prefix){
      var number_string = angka.replace(/[^,\d]/g, '').toString(),
      split       = number_string.split(','),
      sisa        = split[0].length % 3,
      rupiah        = split[0].substr(0, sisa),
      ribuan        = split[0].substr(sisa).match(/\d{3}/gi);
 
      // tambahkan titik jika yang di input sudah menjadi angka ribuan
      if(ribuan){
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
      }
 
      rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
      return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
  </script>

  <script type='text/javascript'>
    var error = 1; // nilai default untuk error 1
    function cek_username(){
        $("#pesanusername").hide();
        var username = $("#username").val();
            $.ajax({
              url: "<?php echo base_url("index.php/C_User/cek_username"); ?>", //arahkan pada proses_tambah di controller member
                data: 'username='+username,
                type: "POST",
                success: function(msg){
                    if(msg==1){
                        $("#pesanusername").css("color","#fc5d32");
                        $("#namapanggilan").css("border-color","#fc5d32");
                        $("#pesanusername").html("Username sudah digunakan !");
                        $("#makkarakter").html("");
                        $("#tambah").attr("disabled","disabled");
                        $("#namapanggilan").val("");
                        error = 1;
                    }else{
                        $("#pesanusername").css("color","#59c113");
                        $("#namapanggilan").css("border-color","#59c113");
                        $("#pesanusername").html("");
                        $("#tambah").attr("disabled",false);

                        error = 0;
                    }

                    $("#pesanusername").fadeIn(1000);
                }
            });               
    }

    function cek_nama(){
        $("#pesannama").hide();
        var namauser = $("#namauser").val();
            $.ajax({
              url: "<?php echo base_url("index.php/C_User/cek_namauser"); ?>", //arahkan pada proses_tambah di controller member
                data: 'namauser='+namauser,
                type: "POST",
                success: function(msg){
                    if(msg==1){
                        $("#pesannama").css("color","#fc5d32");
                        $("#namauser").css("border-color","#fc5d32");
                        $("#pesannama").html("Nama sudah ada !");
                        $("#makkarakter").html("");
                        $("#tambah").attr("disabled","disabled");

                        $("#namapanggilan").val("");
                        error = 1;
                    }else{
                        $("#pesannama").css("color","#59c113");
                        $("#namauser").css("border-color","#59c113");
                        $("#pesannama").html("");
                        $("#tambah").attr("disabled",false);
                        error = 0;
                    }

                    $("#pesannama").fadeIn(1000);
                }
            });               
    }

    function cek_kodebarang(){
        $("#pesankodebarang").hide();
        var kodebarang = $("#kodebarang").val();
            $.ajax({
              url: "<?php echo base_url("index.php/C_Barang/cek_kodebarang"); ?>", //arahkan pada proses_tambah di controller member
                data: 'kodebarang='+kodebarang,
                type: "POST",
                success: function(msg){
                    if(msg==1){
                        $("#pesankodebarang").css("color","#fc5d32");
                        $("#kodebarang").css("border-color","#fc5d32");
                        $("#pesankodebarang").html("Kode Barang sudah ada !");
                        $("#tambah").attr("disabled","disabled");

                        $("#kodebarang").val("");
                        error = 1;
                    }else{
                        $("#pesankodebarang").css("color","#59c113");
                        $("#kodebarang").css("border-color","#59c113");
                        $("#pesankodebarang").html("");
                        $("#tambah").attr("disabled",false);
                        error = 0;
                    }

                    $("#pesankodebarang").fadeIn(1000);
                }
            });               
    }

    // function PrintMeSubmitMe()
    // {
    //   var printContent = document.getElementById(cetakproduksi);
    //   // var WinPrint = window.open('', '', 'width=900,height=650');
    //   // WinPrint.document.write(printContent.innerHTML);
    //   // WinPrint.document.close();
    //   // WinPrint.focus();
    //   // WinPrint.print();
    //   // WinPrint.close();
      
    //   window.print();
    //   SubmitMe();
    // }

    function SubmitMe()
    {
      document.simpanall.submit();
    }
</script>
<script>
  $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
    // Kita sembunyikan dulu untuk loadingnya
    $("#barangjadi").change(function(){ // Ketika user mengganti atau memilih data provinsi
        $.ajax({
          type: "POST", // Method pengiriman data bisa dengan GET atau POST
          url: "<?php echo base_url("index.php/C_Resep/getIdBarang"); ?>", // Isi dengan url/path file php yang dituju
          data: {id : $("#barangjadi").val()}, // data yang akan dikirim ke file yang dituju
          dataType: "json",
          beforeSend: function(e) {
            if(e && e.overrideMimeType) {
              e.overrideMimeType("application/json;charset=UTF-8");
            }
          },
          success: function(response){ // Ketika proses pengiriman berhasil
            // set isi dari combobox kota
            // lalu munculkan kembali combobox kotanya
            document.getElementById("satuan").value = response[0].satuan;
            document.getElementById("id_satuan").value = response[0].id_satuan;
            document.getElementById("baranghasil").value = response[0].barang;
            document.getElementById("id_baranghasil").value = response[0].id_barang;

          },
          error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
          }
        });
    });
  });
  </script>
<script>
  $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
    // Kita sembunyikan dulu untuk loadingnya
    $("#barang_baku").change(function(){ // Ketika user mengganti atau memilih data provinsi
        $.ajax({
          type: "POST", // Method pengiriman data bisa dengan GET atau POST
          url: "<?php echo base_url("index.php/C_Resep/getIdBarang"); ?>", // Isi dengan url/path file php yang dituju
          data: {id : $("#barang_baku").val()}, // data yang akan dikirim ke file yang dituju
          dataType: "json",
          beforeSend: function(e) {
            if(e && e.overrideMimeType) {
              e.overrideMimeType("application/json;charset=UTF-8");
            }
          },
          success: function(response){ // Ketika proses pengiriman berhasil
            // set isi dari combobox kota
            // lalu munculkan kembali combobox kotanya
            document.getElementById("satuan_baku").value = response[0].satuan;
            document.getElementById("id_satuan_baku").value = response[0].id_satuan;
            document.getElementById("qttsatuan_baku").value = response[0].satuan;
            document.getElementById("qttid_satuan_baku").value = response[0].id_satuan;
            document.getElementById("stok_bahanbaku").value = response[0].stok;
            document.getElementById("hargabeli").value = 'Rp. '+formatRupiah(response[0].harga_beli) ;

          },
          error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
          }
        });
    });

   
   $("#formulasi").change(function(){
      // Ketika user mengganti atau memilih data provinsi
      $('#tabelbahanbaku').DataTable().destroy();
      _formulasi();
        
   });
    function _formulasi() {
      var prod = $('#id_produksi').val();
      $('#tabelbahanbaku').DataTable({
        "serverside": true,
        'ordering': true,
        'fixedColumns': true,
        "responsive": true,
        "autoWidth": false,
        'deferRender': true,
        'order': [0, 'asc'],
        "ajax": {
            "url": "<?= base_url('C_Resep/getallresep')?>",
            "type": "POST",
            data: {
                id: $('#formulasi').val()
            }
        },
        "columns": [
            {
                "data": "id_resep",
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                }
            },
            { 'data': 'barang' }, //Tampilkan Address
            { data: 'qtt', render: $.fn.dataTable.render.number('.', '.', 0) },
            { data: 'harga_beli', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp. ') },
            { data: 'input_qtt' },
            {
                'render': function (data, type, row) { //Tampilkan kolom Action
                    //var html = '<button type="button" class="btn btn-primary" onclick="_showFormulasi(this)" data="'+row.id_barang+'"data-id="' +row.id_resep+'"data-id_produksi="' + prod + '"data-harga_bahan="' + row.harga_beli + '"><i class="fa fa-fw fa-check"></i></i></button>'
                    var html = '<a href="javascript:void(0);" class="item_cek btn btn-info btn-xs" data="'+row.id_barang+'"data-id="' +row.id_resep+'"data-id_produksi="' + prod + '"data-harga_bahan="' + row.harga_beli + '"><i class="fa fa-fw fa-check"></i></i></a> '
                    return html;
                }
            }
        ],
        "columnDefs": [{
            targets: "_all",
            orderable: true
        }]
        
    });
}
$('#showformulasi').on('click','.item_cek',function(){
        var id=$(this).attr('data');
        var qtt = $('[name="qttprod"]').val();
        var id_resep = $(this).attr('data-id');
        var hargabahan = $(this).attr('data-harga_bahan');
        var id_produksi = $(this).attr('data-id_produksi');
        var table = $('#tabelbahanbaku').DataTable();
                  table.row( $(this).parents('tr') ).remove().draw();
        $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/C_Produksi/simpanbarangbaku')?>",
          dataType : "JSON",
              data : {
                barang_baku: id,
                hargabahan:hargabahan, 
                id_resep:id_resep, 
                qtt:qtt, 
                id_produksi: id_produksi, kodeproduksi: $('#kodeproduksi').val()},
              success: function(data){
                  var html = '';
                  var i;
                  var no = 1;
                  var totalbiaya = 0;
                  for(i=0; i<data.length; i++){
                    var newno = no++;
                    var number_string = data[i].hargabahan.toString(),
                        sisa  = number_string.length % 3,
                        rupiah  = number_string.substr(0, sisa),
                        ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                          
                      if (ribuan) {
                        separator = sisa ? '.' : '';
                        rupiah += separator + ribuan.join('.');
                      }
                      html += '<tr>'+
                              '<td>'+newno+'</td>'+
                              '<td>'+data[i].kodeformulasi+'</td>'+
                              '<td>'+data[i].barang+'</td>'+
                              '<td>'+data[i].qtt+'</td>'+
                              '<td>'+'Rp. '+formatRupiah(rupiah)+'</td>'+
                              // '<td style="text-align:center;">'+
                              //     '<a href="javascript:;" class="item_edit" data="'+data[i].id_dtlproduksi+'" ><button type="button" class="btn btn-primary"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>'+
                              // '</td>'+
                              '</tr>';
                  }
                  $('#showrekap').html(html);
              },
              error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
                alert('Stok Tidak Tersedia'); // Munculkan alert error
              }
          });
          return false;
      }); 
  
  });
  </script>

<script>

$("#buttonbahanbaku").click(function(){
  document.getElementById("libarangjadi").classList.remove("active");
  document.getElementById("libahanbaku").classList.remove("active");
  document.getElementById("libiayaproduksi").classList.add("active");
  document.getElementById("lihasilproduksi").classList.remove("active");
  $.ajax({
        type  : 'POST',
        url  : "<?php echo base_url('index.php/C_Produksi/dtl'); ?>",
        async : true,
        dataType : 'json',
        data : {
        id_produksi: $("#id_produksi").val()},
        success : function(data){
            var i;
            var no = 1;
            var totalbiaya = 0;
            for(i=0; i<data.length; i++){
              var newno = no++;
              var subtotal = parseInt(data[i].hargabahan)*parseInt(data[i].qtt);
              totalbiaya = totalbiaya+subtotal;
            }

             var number_string = totalbiaya.toString(),
                  sisa  = number_string.length % 3,
                  rupiah  = number_string.substr(0, sisa),
                  ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                    
                if (ribuan) {
                  separator = sisa ? '.' : '';
                  rupiah += separator + ribuan.join('.');
                }
                
            $('#biayabahanbaku').val('Rp. '+formatRupiah(rupiah));
        }

    });
})

$("#buttonbiayaproduksi").click(function(){
  document.getElementById("libarangjadi").classList.remove("active");
  document.getElementById("libahanbaku").classList.remove("active");
  document.getElementById("libiayaproduksi").classList.remove("active");
  document.getElementById("lihasilproduksi").classList.add("active");
})

$("#buttonhasilproduksi").click(function(){
  document.getElementById("libarangjadi").classList.remove("active");
  document.getElementById("libahanbaku").classList.add("active");
  document.getElementById("libiayaproduksi").classList.remove("active");
  document.getElementById("lihasilproduksi").classList.remove("active");
})

function startCalculate(){
    var intervalcal=setInterval("Calculate()",10);

  };

  function Calculate(){
      var a = document.getElementById('hargabeli').value.replace(/[^0-9]/g,'');
      var b = document.getElementById('qty').value;
      var c = document.getElementById('stok_bahanbaku').value;
      if (b>parseInt(c)){
        $("#qtycek").css("color","#fc5d32");
        $("#qty").css("border-color","#fc5d32");
        $("#qtycek").html("Qty Melebihi Stok");
        $("#qty").val("");
        var bilangan = 0;
      }else{

        $("#qtycek").css("color","");
        $("#qty").css("border-color","");
        $("#qtycek").html("");
        var bilangan = a*b;
      }
      var number_string = bilangan.toString(),
        sisa  = number_string.length % 3,
        rupiah  = number_string.substr(0, sisa),
        ribuan  = number_string.substr(sisa).match(/\d{3}/g);
          
      if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
      }

      document.getElementById('subtotal').value = 'Rp. '+formatRupiah(rupiah);
  };
  
  function stopCalc(){
    clearInterval(intervalcal);
    // clearInterval(intervala);
  };

  function barangjadiproduksi() {
    var id_produksi = $("#id_produksi").val();
    var barangjadi = $("#barangjadi").val();
    var kodeproduksi = $("#kodeproduksi").val();
    // var qtt = $("#qtt_barangjadi").val();
    // var jenisbarang = $('[name="jenisbarang"]').val();
      $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/C_Produksi/simpan'); ?>",
          dataType : "JSON",
          data : {
            id_produksi:id_produksi,
            barangjadi:barangjadi,
            kodeproduksi:kodeproduksi,
            // qtt:qtt,
            // jenisbarang:jenisbarang
          },
          beforeSend: function(e) {
            if(e && e.overrideMimeType) {
              e.overrideMimeType("application/json;charset=UTF-8");
            }
          },
          success: function(response){
                document.getElementById("libarangjadi").classList.remove("active");
                document.getElementById("libahanbaku").classList.add("active");
                document.getElementById("libiayaproduksi").classList.remove("active");
                document.getElementById("libiayaproduksi").classList.remove("active");
                document.getElementById("lihasilproduksi").classList.remove("active");
          },
          error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
          }
      });
      return false;
  }
</script>

<script type="text/javascript">
$(document).ready(function(){
  tampilbarangbaku();
  tampilbiayaprod();
  tampilbarangjadi();
  function tampilbarangbaku(){
    $.ajax({
        type  : 'POST',
        url  : "<?php echo base_url('index.php/C_Produksi/dtl'); ?>",
        async : true,
        dataType : 'json',
        data : {
        id_produksi: $("#id_produksi").val()},
        success : function(data){
            var html = '';
            var i;
            var no = 1;
            var totalbiaya = 0;
            for(i=0; i<data.length; i++){
              var newno = no++;
              var subtotal = parseInt(data[i].hargabahan)*parseInt(data[i].qtt);
              var number_string = data[i].hargabahan.toString(),
                  sisa  = number_string.length % 3,
                  rupiah  = number_string.substr(0, sisa),
                  ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                    
                if (ribuan) {
                  separator = sisa ? '.' : '';
                  rupiah += separator + ribuan.join('.');
                }
              totalbiaya = totalbiaya+subtotal;
              html += '<tr>'+
                      '<td>'+newno+'</td>'+
                      '<td>'+data[i].kodeformulasi+'</td>'+
                      '<td>'+data[i].barang+'</td>'+
                      '<td>'+data[i].qtt+'</td>'+
                      '<td>'+'Rp. '+formatRupiah(rupiah)+'</td>'+
                      // '<td style="text-align:center;">'+
                      //     '<a href="javascript:;" class="item_edit" data="'+data[i].id_dtlproduksi+'" ><button type="button" class="btn btn-primary"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>'+
                      // '</td>'+
                      '</tr>';
            }
            $('#showrekap').html(html);

             var number_string = totalbiaya.toString(),
                  sisa  = number_string.length % 3,
                  rupiah  = number_string.substr(0, sisa),
                  ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                    
                if (ribuan) {
                  separator = sisa ? '.' : '';
                  rupiah += separator + ribuan.join('.');
                }
                
            $('#biayabahanbaku').val('Rp. '+formatRupiah(rupiah));
        }

    });
  }

  function tampilbiayaprod(){
    $.ajax({
        type  : 'POST',
        url  : "<?php echo base_url('index.php/C_Produksi/biaya'); ?>",
        async : true,
        dataType : 'json',
        data : {
          id_produksi: $("#id_produksi").val()},
          success : function(data){
            var html = '';
            var i;
            var no = 1;
            var totalbiayalain = 0;
            for(i=0; i<data.length; i++){
              var newno = no++;
              var nominal = data[i].nominal;
              var number_string = nominal.toString(),
                  sisa  = number_string.length % 3,
                  rupiah  = number_string.substr(0, sisa),
                  ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                    
                if (ribuan) {
                  separator = sisa ? '.' : '';
                  rupiah += separator + ribuan.join('.');
                }

              totalbiayalain = totalbiayalain+parseInt(nominal);
                html += '<tr>'+
                        '<td>'+newno+'</td>'+
                        '<td>'+data[i].ket+'</td>'+
                        '<td>'+'Rp. '+formatRupiah(rupiah)+'</td>'+
                        '<td style="text-align:center;">'+
                            '<a href="javascript:;" class="biaya_hapus btn btn-danger" data="'+data[i].id_biayaproduksi+'" onclick="return confirm("Apakah Anda Yakin ?")" ><i class="fa fa-fw fa-trash-o"></i></a>'+
                        '</td>'+
                        '</tr>';
            }
            $('#showbiaya').html(html);
            var number_string = totalbiayalain.toString(),
                  sisa  = number_string.length % 3,
                  rupiah  = number_string.substr(0, sisa),
                  ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                    
                if (ribuan) {
                  separator = sisa ? '.' : '';
                  rupiah += separator + ribuan.join('.');
                }

            $('#biayalainlain').val('Rp. '+formatRupiah(rupiah));
        }

    });
  }

  function tampilbarangjadi(){
    $.ajax({
        type  : 'POST',
        url  : "<?php echo base_url('index.php/C_Produksi/getspek'); ?>",
        async : true,
        dataType : 'json',
        data : {
          id_produksi: $("#id_produksi").val()},
          success : function(data){
            var html = '';
            var i;
            var no = 1;
            var totalbiayalain = 0;
            for(i=0; i<data.length; i++){

              $('#barangjadi').val(data[i].id_barangjadi);
              $('#barangjadi').html(data[i].barang);
              
            }
            
        }

    });
  }

  $('#showbahanbaku').on('click','.item_hapus',function(){
            var id=$(this).attr('data');
            $('#ModalHapus').modal('show');
            $('[name="kode"]').val(id);
        });

  $('#btn_hapus').on('click',function(){
    var kode=$('#textkode').val();
    $.ajax({
      type : "POST",
      url  : "<?php echo base_url('index.php/C_Produksi/hapusdtl')?>",
      dataType : "JSON",
          data : {kode: kode},
          success: function(data){
                  $('#ModalHapus').modal('hide');
                  tampilbarangbaku();
          }
      });
      return false;
  });   
  $('.biaya_hapus').on('click',function(){
    var kode=$('#textkode').val();
    $.ajax({
      type : "POST",
      url  : "<?php echo base_url('index.php/C_Produksi/hapusbiaya')?>",
      dataType : "JSON",
          data : {kode: $(this).attr('data')},
          success: function(data){
                  // $('#ModalHapus').modal('hide');
                  tampilbarangbaku();
          }
      });
      return false;
  });  

  

  $('#showbiaya').on('click','.biaya_hapus',function(){
    $.ajax({
    type : "POST",
    url  : "<?php echo base_url('index.php/C_Produksi/hapusbiaya')?>",
    dataType : "JSON",
            data : {kode: $(this).attr('data')},
            success: function(data){
                    tampilbiayaprod();
            }
        });
        return false;
  });


$('#tambahbarang').on('click',function(){
  var id_produksi = $("#id_produksi").val();
  var barang_baku = $("#barang_baku").val();
  var qty = $("#qty").val();
  var hargabeli = $("#hargabeli").val();
    $.ajax({
        type : "POST",
        url  : "<?php echo base_url('index.php/C_Produksi/simpanbarangbaku'); ?>",
        dataType : "JSON",
        data : {
          id_produksi:id_produksi,
          barang_baku:barang_baku,
          qty:qty,
          hargabahan:hargabeli
        },
        beforeSend: function(e) {
          if(e && e.overrideMimeType) {
            e.overrideMimeType("application/json;charset=UTF-8");
          }
        },
        success: function(response){
              document.getElementById("libarangjadi").classList.remove("active");
              document.getElementById("libahanbaku").classList.add("active");
              document.getElementById("libiayaproduksi").classList.remove("active");
              document.getElementById("libiayaproduksi").classList.remove("active");
              document.getElementById("lihasilproduksi").classList.remove("active");
              tampilbarangbaku();
              document.getElementById("barang_baku").value='';
              document.getElementById("qty").value='';
              document.getElementById("hargabeli").value='';
              document.getElementById("subtotal").value='';
              document.getElementById("qttid_satuan_baku").value='';
              document.getElementById("qttsatuan_baku").value='';
              document.getElementById("id_satuan_baku").value='';
              document.getElementById("satuan_baku").value='';
              document.getElementById("stok_bahanbaku").value='';
        },
        error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
          alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
        }
    });
    return false;
  });

  $('#tambahbiaya').on('click', function(){
    var id_produksi = $("#id_produksi").val();
    var ketbiaya = $("#ketbiaya").val();
    var biayaprod = $("#biayaprod").val();
      $.ajax({
          type : "POST",
          url  : "<?php echo base_url('index.php/C_Produksi/simpanbiaya'); ?>",
          dataType : "JSON",
          data : {
            id_produksi:id_produksi,
            ketbiaya:ketbiaya,
            biayaprod:biayaprod
          },
          beforeSend: function(e) {
            if(e && e.overrideMimeType) {
              e.overrideMimeType("application/json;charset=UTF-8");
            }
          },
          success: function(response){
                document.getElementById("libarangjadi").classList.remove("active");
                document.getElementById("libahanbaku").classList.remove("active");
                document.getElementById("libiayaproduksi").classList.add("active");
                document.getElementById("lihasilproduksi").classList.remove("active");
                tampilbiayaprod();
                document.getElementById("ketbiaya").value = '';
                document.getElementById("biayaprod").value = '';
          },
          error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
          }
      });
      return false;
  });

  $("#komisisales").change(function(){ // Ketika user mengganti atau memilih data provinsi
      var id_sales = $('#komisisales').val();
      var reservation = $('#reservation').val();
      if(id_sales != ''){

        filterpenjualan();
      }
      else{
        $('#totalnota').html('');
      }
    });

  $("#reservation").change(function(){ // Ketika user mengganti atau memilih data provinsi
      var id_sales = $('#komisisales').val();
      var reservation = $('#reservation').val();
      if(id_sales != ''){

        filterpenjualan();
      }
      else{
        $('#totalnota').html('');
      }
    });

  function filterpenjualan(){
    var id_sales = $('#komisisales').val();
    var reservation = $('#reservation').val();
    $('#tgl').val($('#reservation').val());
    $.ajax({
      type: "POST", // Method pengiriman data bisa dengan GET atau POST
      url: "<?php echo base_url("index.php/C_komisi/get_penjualan"); ?>", // Isi dengan url/path file php yang dituju
      data: {id_sales : id_sales, tgl : reservation}, // data yang akan dikirim ke file yang dituju
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(data){ // Ketika proses pengiriman berhasil
        var html = '';
        var i;
        var no = 1;
        var totalnota = 0;
        for(i=0; i<data.length; i++){
          var newno = no++;
          var totala = data[i].total;
          var number_string = totala.toString(),
              sisa  = number_string.length % 3,
              rupiah  = number_string.substr(0, sisa),
              ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                
            if (ribuan) {
              separator = sisa ? '.' : '';
              rupiah += separator + ribuan.join('.');
            }

          totalnota = totalnota+parseInt(totala);
            html += '<tr>'+
                    '<td>'+newno+'</td>'+
                    '<td>'+data[i].kodenota+'</td>'+
                    '<td>'+data[i].namacustomer+'</td>'+
                    '<td>'+'Rp. '+formatRupiah(rupiah)+'</td>'+
                    '</tr>';
        }
        $('#tabelkomisi').html(html);
        var number_string = totalnota.toString(),
              sisa  = number_string.length % 3,
              rupiah  = number_string.substr(0, sisa),
              ribuan  = number_string.substr(sisa).match(/\d{3}/g);
                
            if (ribuan) {
              separator = sisa ? '.' : '';
              rupiah += separator + ribuan.join('.');
            }
        // $('#showlimit').visibility()
        $('#totalnota').val('Rp. '+formatRupiah(rupiah));
        // $('#totalnota').val(data);
        // $('#totalnota').val('Rp. '+formatRupiah(response));
      },
      error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
        alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
      }
    });
  }


});
</script>
</body>
</html>