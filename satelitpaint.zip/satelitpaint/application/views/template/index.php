
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <?php foreach ($jumlahbarangjadi as $bj) { ?>
                
                <h3><?php echo $bj->stok; ?></h3>
              <?php } ?>

              <p>Jumlah Barang Jadi</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">Selengkapnya ... <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">

              <?php foreach ($jumlahbarangbaku as $bk) { ?>
                
                <h3><?php echo $bk->stok; ?></h3>
              <?php } ?>

              <p>Jumlah Barang Baku</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">Selengkapnya ...<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $jumlahcustomer; ?></h3>

              <p>Jumlah Pelanggan</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">Selengkapnya ...<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $jumlahsuplier; ?></h3>

              <p>Jumlah Suplier</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="#" class="small-box-footer">Selengkapnya ... <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      
      <!-- /.row -->
      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Grafik Keuangan</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <!-- <div class="chart" id="bar-chart" style="height: 300px;"></div> -->
              <canvas id="myChart" class="chart" style="height: 300px;"></canvas>
              <?php 
              $jual = 0;
              foreach($jumlahpendapatan as $j){
                $jual = $jual + $j->total;
              } 

              $kk = 0;
              foreach($jumlahpengeluaran as $k){
                $kk = $kk + $k->total;
              } 

              $hutang = 0;
              foreach($jumlahhutang as $h){
                $hutang = $hutang + $h->total;
              } 

              ?>
              <input type="hidden" id="grafikpendapatan" value="<?php echo number_format($jual) ?>">
              <input type="hidden" id="grafikpengeluaran" value="<?php echo number_format($kk) ?>">
              <input type="hidden" id="grafikhutang" value="<?php echo number_format($hutang) ?>">
              <input type="hidden" id="grafiklaba" value="<?php echo number_format($jual) ?>">
            </div>
            <!-- /.box-body -->
          </div>
        </div>

        <!-- /.col -->
      </div>
      <!-- Main row -->
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper