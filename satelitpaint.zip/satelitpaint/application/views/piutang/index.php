
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Piutang
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('piutang'); ?>">Accounting</a></li>
        <li class="active">Data Piutang</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
        <div class="row">
          <div class="col-md-12">

            <!-- Horizontal Form -->
            <div class="box">
              <div class="box-header with-border">
                <h3 class="box-title">Total Piutang Saat Ini</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->

              <div class="form-horizontal">
                <div class="box-body" style="min-height: 120px;">
                  <div class="form-group">
                    <!-- <label for="inputEmail3" class="col-sm-3 control-label">Total</label> -->
                    <div class="col-sm-12">
                    <input class="form-control input-lg" type="text" id="total_pembelian" value="<?= 'Rp. '.number_format($sum->total,2);?>" style="font-weight: bold; text-align: center;" readonly>
                    </div>
                  </div>
                  
                </div>
                <!-- /.box-body -->
               
                <!-- /.box-footer -->
              </div>
            </div> 
          </div>  
      </div>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Penjualan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nota</th>
                  <th>Tgl Nota</th>
                  <th>Customer</th>
                  <th>Pembayaran</th>
                  <th>Jatuh Tempo</th>
                  <th>Total Harga</th>
                  <th>Status Pembayaran</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($database as $tabel) :
                    $now = strtotime(date('Y-m-d'));
                    $jatuhtempo = strtotime($tabel['tgl_jatuhtempo']);
                    $diff = $jatuhtempo - $now;
                    $jarak = round($diff / 86400);
                    if(($jarak >= 0) && ($jarak <=7) || $jarak < 0){
                      echo "<tr style='color: red'>";
                    }else{
                      echo "<tr>";
                    }
                  ?>
                  <td><?= $no++?></td>
                  <td><?= $tabel['kodenota']?></td>
                  <td><?= date('d-m-Y',strtotime($tabel['tgl_update']))?></td>
                  <td><?= $tabel['namacustomer']?></td>
                  <td><?= $tabel['jenispembayaran']?></td>
                  <td>
                    <?php
                      echo ($tabel['jenispembayaran'] == 'Cash' ? '-' : date('d-m-Y',strtotime($tabel['tgl_jatuhtempo'])))
                    ?>
                  </td>
                  <td><?= 'Rp. '.number_format($tabel['total']);?></td>
                  <td><?= $tabel['status']?></td>
                  <td>
                    <a href="<?php echo site_url('piutang-bayar/'.$tabel['id_penjualan']); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-dollar"></i></button></a>
                  </td>
                </tr>
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->