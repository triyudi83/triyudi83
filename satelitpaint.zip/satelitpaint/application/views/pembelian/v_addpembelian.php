
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Transaksi Pembelian
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('pembelian'); ?>">Data Pembelian</a></li>
        <li class="active">Transaksi Pembelian</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-md-4">
        <div class="box box-primary">
            
            <div class="box-body no-padding">

                    <form class="form-horizontal" id="formCreate" enctype="multipart/form-data" Method="POST">
                    <div class="box-body">
                        <div class="form-group">
                        <label for="inputEmail3" class="col-sm-4 control-label">Tanggal</label>

                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="tgl_transaksi" value="<?= date('d-m-Y')?>" readonly>
                            <input type="hidden" class="form-control pull-right" id="id_pembelian" name='id_pembelian' value="<?= $max_id; ?>">
                            <input type="hidden" class="form-control pull-right" id="id_dtlpembelian" name='id_dtlpembelian'>
                            <input type="hidden" class="form-control pull-right" id="keterangan" name='keterangan' value="supplier">
                        </div>
                        </div>
                        <div class="form-group">
                        <label for="inputPassword3" class="col-sm-4 control-label">Faktur</label>

                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="inputPassword3" name="faktur" value="<?php $d = new DateTime();echo "PB.".$d->format("ymdHis.v");?>" readonly>
                        </div>
                        </div>
                        <div class="form-group">
                        <label for="inputPassword3" class="col-sm-4 control-label">Suplier</label>
                        <div class="col-sm-8">
                          <div class="input-group input-group">
                            <input type="hidden" class="form-control" name="id_suplier" id="id_suplier" required />
                            <input type="text" class="form-control" name="namasuplier" id="namasuplier" required />
                            <span class="input-group-btn">
                              <button type="button" class="btn btn-info btn-flat btnSuplier"><i class="fa fa-fw fa-search"></i></button>
                            </span>
                          </div>
                        </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail" class="col-sm-4 control-label">Pembayaran</label>

                            <div class="col-sm-8">
                                <select class="form-control select2" name="jenispembayaran" id="jenispembayaran" required>
                                    <option selected="selected" value="">--Pilih--</option>
                                    <option value="cash">Cash</option>
                                    <option value="kredit">Kredit</option>
                                </select>
                            </div>
                            </div>
                            <div class="form-group" id="showlimit" style="display:none">
                            <label for="inputName" class="col-sm-4 control-label">Limit Hutang</label>

                            <div class="col-sm-8">
                            <input type="text" class="form-control" id="limit_hutang" name="limit_hutang" value="">
                            </div>
                        </div>
                            <div class="form-group" id="showtempo" style="display:none">
                            <label for="inputName" class="col-sm-4 control-label">Tanggal Jatuh Tempo</label>
                            <div class="col-sm-8">
                            <input type="text" class="form-control pull-right" id="datepicker" name='jatuhtempo'>
                            </div>
                        </div>
                        <div class="form-group">
                    <label for="inputName" class="col-sm-4 control-label">Pilih Barang</label>
                    <div class="col-sm-8">
                        <div class="input-group input-group">
                            <input type="hidden" class="form-control" name="id_barang" id="id_barang" required />
                            <input type="text" class="form-control" name="namabarang" id="namabarang" required/>
                            <span class="input-group-btn">
                              <button type="button" class="btn btn-info btn-flat keyboard">
                                <i class="fa fa-fw fa-search"></i>[F1]
                              </button>
                            </span>
                        </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-4 control-label">Qty</label>

                    <div class="col-sm-8">
                      <input type="text" class="form-control" name="qtt" id="qtt" placeholder="Qtt" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-4 control-label">Harga</label>

                    <div class="col-sm-8">
                      <input type="text" class="form-control" name="harga" id="rupiah" placeholder="Harga" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-4 control-label">Diskon</label>

                    <div class="col-sm-8">
                      <input type="text" class="form-control" name="diskon" id="diskon" placeholder="Diskon" />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-8">
                      <button class="btn btn-default" name="batalall" id="deleteall">Kembali</button>
                      <button class="btn btn-default" id="btnBatal" style="display:none">Batal</button>
                      <button type='submit' class="btn btn-info btnTambahPembelian" id="btnCart">Tambah</button>
                      <button class="btn btn-info" id="btnCartUpdate" style="display:none">Update</button>
                    </div>
                  </div>
                    </div>
                    <!-- /.box-body -->
                    <!-- /.box-footer -->
                    </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
          <!-- /.box -->
        </div>
        <div class="col-md-8">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Keranjang Belanja</h3>
            </div>
            <div class="box-body table-responsive">
              <table width ="100%" class="table table-bordered" id="totalTabel">
                <thead>
                  <th>No</th>
                  <th>Kode Barang</th>
                  <th>Barang</th>
                  <th>Qtt</th>
                  <th>Harga</th>
                  <th>Diskon</th>
                  <th>Sub Total</th>
                  <th>Action</th>
                </thead>
                <tbody>
                </tbody>
                <tfoot align="right">
                  <tr>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th colspan="2"></th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col (left) -->
        <div class="col-md-4">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Invoice</h3>
            </div>
            <div class="box-body">
              <form class="form-horizontal" id="formCart" enctype="multipart/form-data" Method="POST">
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-4 control-label">Total</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" id="subtotalbawah" name="subtotalbawah" readonly>
                     
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-4 control-label">Diskon</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" id="diskon1" name="diskon1" onkeyup="subtotalall()" required>
                      <span id='diskon1Error'></span>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-4 control-label">Total Akhir</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" id="total" name="total" readonly>
                      <span>(Total - Diskon)</span></br>
                      <span id='totalError'></span>
                    </div>
                  </div>
                  <div class="box-footer">
                      <div class="col-sm-7">
                        <button class="btn btn-default" name="batalall" type="button" onclick="deletePembelian()">Batal</button>
                        <button type='submit' class="btn btn-info" id="simpanall">Simpan</button>
                      </div>
                  </div>
              </form>
            <!-- /.box-body -->
          </div>

        </div>
        <!-- /.col (right) -->
      </div>
        <!-- /.col -->
      </div>
      <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close closeBarang">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Data Barang</h4>
              </div>
              <div class="modal-body table-responsive">
              <table id="TabelBarang" class="table table-bordered">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Barang</th>
                  <th>Barang</th>
                  <th>Stok</th>
                  <th>Satuan</th>
                  <th>Harga Beli</th>
                  <th>Aksi</th>
                </tr>
                </thead>
              </table>
              </div>
              <div class="modal-footer">
              <button type="button" class="btn btn-info pull-right closeBarang">Close</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      <div class="modal fade" id="modal-suplier" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close closemodal">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Data Suplier</h4>
              </div>
              <div class="modal-body table-responsive"> 
              <table id="suplierTable" class="table table-bordered" width="100%">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Suplier</th>
                  <th>Alamat</th>
                  <th>Telepon</th>
                  <th>Action</th>
                </tr>
                </thead>
              </table>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-info pull-right closemodal">Close</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script>
    $('#myFunction').keydown(function(event) {
      fungsikeyboard();
    });
    
  </script>