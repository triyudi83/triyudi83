<style>
  a.disabled {
  pointer-events: none;
  cursor: default;
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Transaksi Pembelian
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('pembelian'); ?>">Transaksi Pembelian</a></li>
        <li class="active">Lihat Transaksi Pembelian</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Identitas Suplier</h3>
        </div>
        <div class="box-body">
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 control-label">No. Nota</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" value="<?= $pembelian->nota?>" readonly>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 control-label">Suplier</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" value="<?= $pembelian->namasuplier?>" readonly>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 control-label">Tanggal</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" value="<?=date('d-m-Y',strtotime($pembelian->tgl_update))?>" readonly>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 control-label">Alamat</label>
            <div class="col-sm-8">
              <textarea class="form-control" rows="3" id="alamat" name="alamat" readonly><?= $pembelian->alamat ?></textarea>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 control-label">Jenis Pembayaran</label>
            <div class="col-sm-8">
              <select class="form-control select2" disabled>
                  <option value="">Semua Transaksi</option>
                  <option value="cash" <?= ($pembelian->jenispembayaran == 'cash') ? 'selected' : ''?>>Cash</option>
                  <option value="kredit" <?= ($pembelian->jenispembayaran == 'kredit') ? 'selected' : ''?>>Kredit</option>
              </select>
            </div>
          </div>
          <div class="form-group row">
            <label for="inputEmail3" class="col-sm-2 control-label">Jatuh Tempo</label>
            <div class="col-sm-8">
            <input type="text" class="form-control" value="<?= 
            ($pembelian->jenispembayaran == 'cash') ? '-' : date('d-m-Y',strtotime($pembelian->tgl_jatuhtempo))?>" readonly>
            </div>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Detail Pembelian</h3>
            </div>
            <div class="box-body table-responsive">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Barang</th>
                  <th>Barang</th>
                  <th>Qtt</th>
                  <th>Harga</th>
                  <th>Diskon</th>
                  <th>Sub Total</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  $total = 0;
                  foreach ($database as $tabel) :
                    $total = $total+$tabel['subtotal'];
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= $tabel['kodebarang']?></td>
                  <td><?= $tabel['barang']?></td>
                  <td><?= $tabel['qtt']?></td>
                  <td><?= 'Rp. '.number_format($tabel['harga'])?></td>
                  <td><?= 'Rp. '.number_format($tabel['diskon'])?></td>
                  <td><?= 'Rp. '.number_format($tabel['subtotal'])?></td>
                </tr>
                <?php endforeach;?>
                </tbody>
                <tfoot align="right">
                  <tr>
                      <th colspan="6">Sub total :</th>
                      <th colspan='1'><?= 'Rp. '.number_format($pembelian->subtotalnota); ?></th>
                  </tr>
                  <tr>
                      <th colspan="6">Diskon :</th>
                      <th colspan='1'><?= 'Rp. '.number_format($pembelian->diskonnota); ?></th>
                  </tr>
                  <tr>
                      <th colspan="6">Total :</th>
                      <th colspan='1'><?= 'Rp. '.number_format($pembelian->totalnota); ?></th>
                  </tr>
                  </tfoot>
              </table>

            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col (left) -->
       
        <!-- /.col (right) -->
      </div>
    </section>
    <!-- /.content -->
    <div id="base-url" data-url="<?= base_url(); ?>"></div>
  </div>
  
  <!-- /.content-wrapper -->