
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Pembelian
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('pembelian'); ?>">Data Pembelian</a></li>
        <li class="active">Lihat Data</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Pembelian</h3>
            </div>
            <!-- /.box-header -->
            <?php if($aksesedit == 'aktif') : ?>
            <div class="box-header">
              <a href="<?php echo site_url('pembelian-add'); ?>"><button type="button" class="btn btn-warning" >Tambah Data</button></a>
            </div>
            <?php endif;?>
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nota</th>
                  <th>Tgl Nota</th>
                  <th>Suplier</th>
                  <th>Pembayaran</th>
                  <th>Jatuh Tempo</th>
                  <th>Total Harga</th>
                  <th>Status Pembayaran</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($database as $tabel) :
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= $tabel['nota']?></td>
                  <td><?= date('d-m-Y',strtotime($tabel['tgl_update']))?></td>
                  <td><?= $tabel['namasuplier']?></td>
                  <td><?= $tabel['jenispembayaran']?></td>
                  <td>
                    <?php
                      echo ($tabel['jenispembayaran'] == 'cash' ? '-' : date('d-m-Y',strtotime($tabel['tgl_jatuhtempo'])))
                    ?>
                  </td>
                  <td><?= 'Rp. '.number_format($tabel['totalnota']);?></td>
                  <td><?= $tabel['status']?></td>
                  <td>
                    <a href="<?php echo site_url('pembelian-view/'.$tabel['id_pembelian']); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-search"></i></button></a>
                     <?= 
                      ($tabel['jenispembayaran'] == 'cash' ? '' : '<a href="delete-hutang/"'.$tabel['id_pembelian']'); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-search"></i></button></a>')
                     ?>
                  </td>
                </tr>
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->