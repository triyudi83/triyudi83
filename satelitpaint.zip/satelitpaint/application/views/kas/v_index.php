
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Accounting
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('kaskeluar'); ?>">Data Kas</a></li>
        <li class="active">Data Kas Keluar</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-md-8">
            <!-- Horizontal Form -->
            <div class="box">
              <div class="box-header with-border">
                <h3 class="box-title">Detail Transaksi</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
                <div class="box-body form-horizontal" style="min-height: 120px;">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-4 control-label">Tanggal Awal</label>
                      <div class="col-sm-8">
                      <input title="tanggal transaksi" class="form-control" type="text" id="kasawal" >
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputPassword3" class="col-sm-4 control-label">Tanggal Akhir</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="kasakhir">
                      </div>
                    </div>
                    
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="inputPassword3" class="col-sm-0 control-label"></label>
                      <div class="col-sm-12">
                        <button type="submit" class="btn btn-success exportkaskeluar" style="width:100%" >
                        <span class="glyphicon glyphicon-download-alt"></span> Export Excel
                        </button>
                      </div>
                      <div class="col-sm-12" id="ekasKeluar" style="display:none">
                      </div>
                    </div>
                  </div>
                </div>
            </div> 
          </div>
          <div class="col-md-4">
            <!-- Horizontal Form -->
            <div class="box">
              <div class="box-header with-border">
                <h3 class="box-title">Total Kas Keluar Bulan Ini</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form class="form-horizontal">
                <div class="box-body" style="min-height: 120px;">
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Total</label>
                    <div class="col-sm-9">
                    <input class="form-control input-lg" type="text" id="total_pembelian" readonly value="<?= 'Rp. '.number_format($sum->nominal,2);?>" style="font-weight: bold;">
                    </div>
                  </div>
                  
                </div>
                <!-- /.box-body -->
               
                <!-- /.box-footer -->
              </form>
            </div> 
          </div>  
      </div>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Kas Keluar</h3>
            </div>
            <!-- /.box-header -->
            <?php //if($aksesedit == 'aktif') : ?>
            <div class="box-header">
                <!-- Check all button -->
                <a href="<?= site_url('kaskeluar-add')?>">
                <button type="button" class="btn btn-warning">Tambah Data
                </button>
                </a>
            </div>
            <?php //endif; ?>
            <div class="box-body  table-responsive">
              
              <table id="kaskeluar" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Keterangan</th>
                  <th>Nominal</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($database as $tabel) :
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= date('d-m-Y',strtotime($tabel->tglkas))?></td>
                  <td><?= $tabel->ket?></td>
                  <td><?= 'Rp. '.number_format($tabel->nominal);?></td>
                </tr>
                <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->