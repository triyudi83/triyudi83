<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Barang
        <small>Lihat</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Data Master</a></li>
        <li><a href="<?php echo site_url('barang'); ?>">Data Barang</a></li>>
        <li class="active">Konversi Barang</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Konversi Barang</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" method="POST" action="<?php echo site_url('C_Barang/updatekonversi')?>">
              <div class="box-body">
                <?php foreach ($konversi as $key) { ?>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Kode Barang</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="kodeBarang" name="kodeBarang" value="<?= $key->kodebarang ?>" readonly>
                    <input type="hidden" class="form-control" id="id" name="id" value="<?= $key->id_barang ?>">
                    <input type="hidden" class="form-control" id="idkonversi" name="idkonversi" value="<?= $key->id_konversi ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Nama Barang</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="nama_Barang" name="namabarang" value="<?= $key->barang ?>" readonly>
                    <input type="hidden" class="form-control" id="id" name="id" value="<?= $key->id_barang ?>">
                    <input type="hidden" class="form-control" id="idkonversi" name="idkonversi" value="<?= $key->id_konversi ?>">
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Qtt Awal</label>
                  <div class="col-sm-9">
                    <input type="number" class="form-control" id="qttawal" name="qttawal" value="<?= $key->qttawal ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Satuan</label>
                  <div class="col-sm-9">
                    <select class="form-control select2" id="satuanawal" name="satuanawal" style="width: 100%;" readonly>
                      <?php foreach ($satuanawal as $satuanawal) { ?>
                      <option value="<?php echo $satuanawal->id_satuan ?>" <?php if($key->satuanawal == $satuanawal->id_satuan){ echo "selected"; } ?> ><?php echo $satuanawal->satuan ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Qtt Konversi</label>
                  <div class="col-sm-9">
                    <input type="number" class="form-control" id="qttakhir" name="qttakhir" value="<?= $key->qttakhir ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Satuan</label>
                  <div class="col-sm-9">
                    <select class="form-control select2" id="satuanakhir" name="satuanakhir" style="width: 100%;" readonly>
                      <?php foreach ($satuanakhir as $satuanakhir) { ?>
                      <option value="<?php echo $satuanakhir->id_satuan ?>" <?php if($key->satuanakhir == $satuanakhir->id_satuan){ echo "selected"; } ?> ><?php echo $satuanakhir->satuan ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>

              <?php } ?>
              <!-- /.box-body -->
              <div class="box-footer">
                  <div class="col-sm-10">
                    <a href="<?php echo site_url('barang'); ?>" class="btn btn-default">Kembali</a>
                    <button type="submit" class="btn btn-info">Simpan Data</button>
                  </div>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->

        </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->


    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tabel Konversi Barang</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start --><div class="mailbox-controls">
                <!-- Check all button -->
                <a href="<?php echo site_url('konversi-add/'.$key->id_barang); ?>">
                <button type="button" class="btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i> Tambah Konversi
                </button>
                </a>
            </div>
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Qtt Awal</th>
                  <th>Satuan Awal</th>
                  <th>Qtt Konversi</th>
                  <th>Satuan Konversi</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($konversiall as $konversi){
                ?>
                <tr>
                  <td><?php echo $no++?></td>
                  <td><?php echo $konversi->qttawal; ?></td>
                  <td><?php echo $konversi->awal?></td>
                  <td><?php echo $konversi->qttakhir ?></td>
                  <td><?php echo $konversi->akhir?></td>
                  <td>
                    <div class="btn-group">
                      <a href="<?php echo site_url('konversi-edit/'.$konversi->id_konversi.'/'.$konversi->id_barang); ?>"><button type="button" class="btn btn-info"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>
                      <a href="<?php echo site_url('C_Barang/hapuskonversi/'.$konversi->id_konversi.'/'.$konversi->id_barang); ?>" onclick="return confirm('Apakah Anda Yakin ?')"><button type="button" class="btn btn-danger"><i class="fa fa-fw fa-trash-o"></i></button></a>

                    </div>
                  </td>
                </tr>
                <?php } ?>
              </table>
            </div>
          </div>
          <!-- /.box -->
          
        </div>
      <!-- /.row -->
    </section>
  </div>