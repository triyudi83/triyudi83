<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Mutasi Barang
        <small>Lihat</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Data Master</a></li>
        <li><a href="<?php echo site_url('barang'); ?>">Data Barang</a></li>>
        <li class="active">Lihat Data Mutasi Barang</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Detail Barang</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal" method="POST" action="<?php echo site_url('C_Barang/update')?>">
              <div class="box-body">
                <?php foreach ($barang as $key) { ?>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Kode Barang</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="kodeBarang" name="kodebarang" value="<?= $key->kodebarang ?>" readonly>
                    <input type="hidden" class="form-control" id="id" name="id" value="<?= $key->id_barang ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Nama Barang</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="nama_Barang" name="namabarang" value="<?= $key->barang ?>" readonly>
                    <input type="hidden" class="form-control" id="id" name="id" value="<?= $key->id_barang ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Stok</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="Satuan" name="Satuan" value="<?= $key->stok.' '.$key->satuan ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Jenis Barang</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="Satuan" name="Satuan" value=" <?php if($key->jenisbarang == 'jual'){ echo 'Barang Jual'; } elseif ($key->jenisbarang == 'bsj' ) { echo 'Barang Setengah Jadi'; } else { echo 'Bahan Baku'; } ?> " readonly>
                  </div>
                </div>
              </div>
            <?php } ?>
              <!-- /.box-body -->
              <div class="box-footer">
                  <div class="col-sm-10">
                    <a href="<?php echo site_url('barang'); ?>" class="btn btn-default">Kembali</a>
                  </div>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->

        </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->


    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">List Mutasi Barang</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal Transaksi</th>
                  <th>Barang</th>
                  <th>Qtt</th>
                  <th>Satuan</th>
                  <th>Jenis Mutasi</th>
                  <th>Keterangan</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($mutasi as $mutasi){
                ?>
                <tr>
                  <td><?php echo $no++?></td>
                  <td><?php echo date('d-m-Y', strtotime($mutasi->tgl_update)); ?></td>
                  <td><?php echo $mutasi->barang?></td>
                  <td><?php echo $mutasi->qtt ?></td>
                  <td><?php echo $mutasi->satuan?></td>
                  <td><?php echo $mutasi->jenismutasi?></td>
                  <td><?php echo $mutasi->ket?></td>
                </tr>
                <?php } ?>
              </table>
            </div>
          </div>
          <!-- /.box -->
          
        </div>
      <!-- /.row -->
    </section>
  </div>