
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Suplier
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('suplier'); ?>">Data Master</a></li>
        <li class="active">Data Suplier</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Suplier</h3>
            </div>
            <!-- /.box-header -->
            <?php if($aksesedit == 'aktif') : ?>
            <div class="box-header">
              <a href="<?php echo site_url('suplier-add'); ?>"><button type="button" class="btn btn-warning" >Tambah Data</button></a>
            </div>
            <?php endif;?>
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Suplier</th>
                  <th>Alamat</th>
                  <th>Telepon</th>
                  <th>Limit</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($tb_suplier as $tabel) :
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= $tabel['namasuplier']?></td>
                  <td><?= $tabel['alamat'].','.$tabel['name_prov'].', '.$tabel['name_kota'].', '.$tabel['kecamatan'] ; ?></td>
                  <td><?= $tabel['tlp'].'/'.$tabel['hp']?></td>
                  <td><?php echo 'Rp. '.number_format($tabel['limit']); ?></td>
                  <td>
                    <a href="<?php echo site_url('suplier-view/'.$tabel['id_suplier']); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-search"></i></button></a>
                      <?php if($aksesedit == 'aktif'){?>
                      <a href="<?php echo site_url('suplier-edit/'.$tabel['id_suplier']); ?>"><button type="button" class="btn btn-info"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>
                    <?php } if($akseshapus == 'aktif'){ ?>
                      <a href="<?php echo site_url('suplier/delete/'.$tabel['id_suplier']); ?>" onclick="return confirm('Apakah Anda Yakin ?')"><button type="button" class="btn btn-danger"><i class="fa fa-fw fa-trash-o"></i></button></a>
                    <?php } ?>
                  </td>
                </tr>
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->