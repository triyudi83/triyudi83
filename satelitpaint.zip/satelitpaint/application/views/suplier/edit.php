
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Suplier
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('suplier'); ?>">Data Suplier</a></li>
        <li class="active">Edit Data Suplier</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Data Suplier</h3>
            </div>
            <!-- /.box-header -->
            <form class="form-horizontal" action="" method='POST' enctype="multipart/form-data">
            <div class="box-body">
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Nama Suplier</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="namasuplier" id="namasuplier" value="<?= $tb_suplier->namasuplier;?>">
                        <input type="hidden" class="form-control" name="id_suplier" value="<?= $tb_suplier->id_suplier;?>">
                       
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Provinsi</label>
                    <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%;" id="prov" name="id_provinsi">
                            <option value="">--Pilih--</option>
                            <?php foreach ($provinsi as $prov) : ?>
                                <?php if ($prov->id_provinsi == $tb_suplier->id_prov) : ?>
                                    <option value="<?= $prov->id_provinsi?>" selected><?= $prov->name_prov?></option>
                                <?php else : ?>
                                    <option value="<?= $prov->id_provinsi?>"><?= $prov->name_prov?></option>
                                <?php endif; ?>
                            <?php endforeach;?>
                        </select>
                       
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Kota/Kabupaten</label>
                    <div class="col-sm-9">
                      <select name="id_kota" id="kota" class="form-control select2" >
                        <?php foreach ($kota as $list_kota) : ?>
                                <?php if ($list_kota->id_kota == $tb_suplier->id_kota) : ?>
                                    <option value="<?= $list_kota->id_kota?>" selected><?= $list_kota->name_kota?></option>
                                <?php else : ?>
                                    <option value="<?= $list_kota->id_kota?>"><?= $list_kota->name_kota?></option>
                                <?php endif; ?>
                            <?php endforeach;?>
                      </select>
                      
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Kecamatan</label>
                    <div class="col-sm-9">
                      <select name="id_kecamatan" id="kecamatan" class="form-control select2" >
                          <?php foreach ($kecamatan as $list_kec) : ?>
                                <?php if ($list_kec->id_kecamatan == $tb_suplier->id_kecamatan) : ?>
                                    <option value="<?= $list_kec->id_kecamatan?>" selected><?= $list_kec->kecamatan?></option>
                                <?php else : ?>
                                    <option value="<?= $list_kec->id_kecamatan?>"><?= $list_kec->kecamatan?></option>
                                <?php endif; ?>
                            <?php endforeach;?>
                      </select>
                     
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Alamat</label>
                    <div class="col-sm-9">
                      <textarea name="alamat" id="" cols="30" rows="3" class="form-control"><?= $tb_suplier->alamat?></textarea>
                      
                    </div>
                </div>
                <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 control-label">Telepon </label>
                    <div class="col-xs-4 ">
                      <input type="text" class="form-control col-xs-4" id="tlp_Customer" value="<?= $tb_suplier->tlp?>" name="tlp" placeholder="Telepon"  maxlength="12" minlength="8" onkeypress="return Angkasaja(event)">
                    </div>
                    <label for="inputEmail3" class="col-sm-1 control-label">Hp </label>
                    <div class="col-xs-4 ">
                      <input type="text" class="form-control col-xs-4" id="tlp_Customer" name="hp" placeholder="HP"  maxlength="12" minlength="8" onkeypress="return Angkasaja(event)" value="<?= $tb_suplier->hp?>">
                    </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Limit</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="rupiah" name="limit" value=" Rp. <?php echo number_format($tb_suplier->limit,0,",","."); ?>"">
                  </div>
                </div>
                
            <!-- /.box-body -->
          </div>
              <div class="box-footer">
                    <div class="col-sm-10">
                     <a href="<?php echo site_url('suplier'); ?>" class="btn btn-default">Batal</a>
                    <button type="submit" class="btn btn-info">Simpan Data</button>
                    </div>
                </div>
            </form>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->