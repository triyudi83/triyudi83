
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data sales
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('sales'); ?>">Data Sales</a></li>
        <li class="active">Lihat Data Sales</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Lihat Data Sales</h3>
            </div>
            <!-- /.box-header -->
            <form class="form-horizontal" action="" method='POST' enctype="multipart/form-data">
            <div class="box-body">
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Nama sales</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="namasales" id="namasales" value="<?= $database->namasales;?>" readonly>
                        <input type="hidden" class="form-control" name="id_sales" value="<?= $database->id_sales;?>" readonly>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Provinsi</label>
                    <div class="col-sm-9">
                        <select class="form-control select2" style="width: 100%;" id="prov" name="id_provinsi" disabled>
                            <option value="">Pilih Provinsi</option>
                            <?php foreach ($provinsi as $prov) : ?>
                                <?php if ($prov->id_provinsi == $database->id_prov) : ?>
                                    <option value="<?= $prov->id_provinsi?>" selected><?= $prov->name_prov?></option>
                                <?php else : ?>
                                    <option value="<?= $prov->id_provinsi?>"><?= $prov->name_prov?></option>
                                <?php endif; ?>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Kota/Kabupaten</label>
                    <div class="col-sm-9">
                      <select name="id_kota" id="kota" class="form-control select2" disabled>
                      
                        <?php foreach ($kota as $list_kota) : ?>
                                <?php if ($list_kota->id_kota == $database->id_kota) : ?>
                                    <option value="<?= $list_kota->id_kota?>" selected><?= $list_kota->name_kota?></option>
                                <?php else : ?>
                                    <option value="<?= $list_kota->id_kota?>"><?= $list_kota->name_kota?></option>
                                <?php endif; ?>
                            <?php endforeach;?>
                      </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Kecamatan</label>
                    <div class="col-sm-9">
                      <select name="id_kecamatan" id="kecamatan" class="form-control select2" disabled>
                        
                          <?php foreach ($kecamatan as $list_kec) : ?>
                                <?php if ($list_kec->id_kecamatan == $database->id_kecamatan) : ?>
                                    <option value="<?= $list_kec->id_kecamatan?>" selected><?= $list_kec->kecamatan?></option>
                                <?php else : ?>
                                    <option value="<?= $list_kec->id_kecamatan?>"><?= $list_kec->kecamatan?></option>
                                <?php endif; ?>
                            <?php endforeach;?>
                      </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Alamat</label>
                    <div class="col-sm-9">
                      <textarea name="alamat" id="" cols="30" rows="3" class="form-control" readonly><?= $database->alamat?></textarea>
                     
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">No. Telepon</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="tlf" id="tlf" value="<?= $database->tlf?>" readonly>
                       
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Area Kerja</label>
                    <div class="col-sm-9">
                      <textarea name="areakerja" id="" cols="30" rows="3" class="form-control" readonly><?= $database->areakerja?></textarea>
                    </div>
                </div>
            <!-- /.box-body -->
          </div>
                <div class="box-footer">
                    <div class="col-sm-10">
                    <a href="<?php echo site_url('sales'); ?>" class="btn btn-default">Batal</a>
                    </div>
                </div>
            </form>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->