
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Sales
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('sales'); ?>">Data Sales</a></li>
        <li class="active">Tambah Data Sales</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah Data sales</h3>
            </div>
            <!-- /.box-header -->
            <form class="form-horizontal" action="" method='POST' enctype="multipart/form-data">
            <div class="box-body">
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Nama sales</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="namasales" id="namasales" required placeholder="Nama Sales">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Provinsi</label>
                    <div class="col-sm-9">
                        <select class="form-control select2"  required id="prov" name="id_provinsi">
                            <option selected="selected" value="">--Pilih--</option>
                            <?php foreach ($provinsi as $prov) : ?>
                                <option value="<?= $prov->id_provinsi?>"><?= $prov->name_prov?></option>
                            <?php endforeach;?>
                        </select>
                        
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Kota/Kabupaten</label>
                    <div class="col-sm-9">
                      <select name="id_kota" id="kota" class="form-control select2" required>
                      </select>
                     
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Kecamatan</label>
                    <div class="col-sm-9">
                      <select name="id_kecamatan" id="kecamatan" class="form-control select2" required>
                      </select>
                     
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Alamat</label>
                    <div class="col-sm-9">
                      <textarea name="alamat" id="" cols="30" rows="3" class="form-control" required></textarea>
                      
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">No. Telepon</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control col-xs-4" id="tlp_Customer" name="tlf" placeholder="Telepon"  maxlength="12" minlength="8" onkeypress="return Angkasaja(event)">
                        
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Area Kerja</label>
                    <div class="col-sm-9">
                      <textarea name="areakerja" id="" cols="30" rows="3" class="form-control" required></textarea>
                      
                    </div>
                </div>
            <!-- /.box-body -->
                </div>
                <div class="box-footer">
                    <div class="col-sm-10">
                     <a href="<?php echo site_url('sales'); ?>" class="btn btn-default">Batal</a>
                    <button type="submit" class="btn btn-info">Simpan</button>
                    </div>
                </div>
            </form>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->