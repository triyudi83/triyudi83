
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Sales
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('sales'); ?>">Data Master</a></li>
        <li class="active">Data Sales</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Sales</h3>
            </div>
            <!-- /.box-header -->
            <?php if($aksesedit == 'aktif') : ?>
            <div class="box-header">
                <!-- Check all button -->
                <a href="<?= site_url('sales-add')?>">
                <button type="button" class="btn btn-warning">Tambah Data
                </button>
                </a>
            </div>
            <?php endif;?>
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Sales</th>
                  <th>Alamat</th>
                  <th>Telepon</th>
                  <th>Area Kerja</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($database as $tabel) :
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= $tabel['namasales']?></td>
                  <td><?= $tabel['alamat'].','.$tabel['name_prov'].', '.$tabel['name_kota'].', '.$tabel['kecamatan'] ; ?></td>
                  <td><?= $tabel['tlf']?></td>
                  <td><?= $tabel['areakerja']?></td>
                  <td>
                    <a href="<?php echo site_url('sales-view/'.$tabel['id_sales']); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-search"></i></button></a>
                    <?php if($aksesedit == 'aktif'){?>
                      <a href="<?php echo site_url('sales-edit/'.$tabel['id_sales']); ?>"><button type="button" class="btn btn-info"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>
                    <?php } if($akseshapus == 'aktif'){ ?>
                      <a href="<?php echo site_url('sales/delete/'.$tabel['id_sales']); ?>" onclick="return confirm('Apakah Anda Yakin ?')"><button type="button" class="btn btn-danger"><i class="fa fa-fw fa-trash-o"></i></button></a>
                    <?php } ?>
                  </td>
                </tr> 
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->