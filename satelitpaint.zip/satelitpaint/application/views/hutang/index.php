
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Accounting
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('pembelian'); ?>">Data Accounting</a></li>
        <li class="active">Lihat Data</li>
      </ol>
    </section>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-md-8">
            <!-- Horizontal Form -->
            <div class="box">
              <div class="box-header with-border">
                <h3 class="box-title">Filter</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form class="form-horizontal">
                <div class="box-body" style="min-height: 120px;">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-4 control-label">Tanggal Awal</label>
                      <div class="col-sm-8">
                      <input title="tanggal transaksi" class="form-control" type="text" id="min" >
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputPassword3" class="col-sm-4 control-label">Tanggal Akhir</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" id="max">
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="inputPassword3" class="col-sm-0 control-label"></label>
                      <div class="col-sm-12">
                      <select class="form-control select2" id="searchTransaksi">
                          <option value="kredit">Kredit</option>
                      </select>
                      </div>
                    </div>
                    <div class="form-group" style="display:none">
                      <label for="inputPassword3" class="col-sm-0 control-label"></label>
                      <div class="col-sm-12">
                        <button type="submit" class="btn btn-success" style="width:100%">
                        <i class="fa fa-search"></i> Cari
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- /.box-body -->
               
                <!-- /.box-footer -->
              </form>
            </div> 
          </div>
          <div class="col-md-4">
            <!-- Horizontal Form -->
            <div class="box">
              <div class="box-header with-border">
                <h3 class="box-title">Total Hutang</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form class="form-horizontal">
                <div class="box-body" style="min-height: 120px;">
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-3 control-label">Total</label>
                    <div class="col-sm-9">
                    <input class="form-control input-lg" type="text" id="total_pembelian" value="<?= 'Rp. '.number_format($sum->totalnota,2);?>" style="font-weight: bold;" readonly>
                    </div>
                  </div>
                  
                </div>
                <!-- /.box-body -->
               
                <!-- /.box-footer -->
              </form>
            </div> 
          </div>  
      </div>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">
                Data Laporan Hutang
              </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nota</th>
                  <th>Tgl Nota</th>
                  <th>Suplier</th>
                  <th>Pembayaran</th>
                  <th>Jatuh Tempo</th>
                  <th>Total Harga</th>
                  <th>Status Pembayaran</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($database as $tabel) :
                    //echo ($tabel['status'] == 'Lunas' ? '<tr>' : ' <tr style="color: red">')
                  $now = strtotime(date('Y-m-d'));
                  $jatuhtempo = strtotime($tabel['tgl_jatuhtempo']);
                  $diff = $jatuhtempo - $now;
                  $jarak = round($diff / 86400);
                  if(($jarak >= 0) && ($jarak <=7) || $jarak < 0){
                    echo "<tr style='color: red'>";
                  }else{
                    echo "<tr>";
                  }
                ?>
                  <td><?= $no++?></td>
                  <td><?= $tabel['nota']?></td>
                  <td><?= date('d-m-Y',strtotime($tabel['tgl_update']))?></td>
                  <td><?= $tabel['namasuplier']?></td>
                  <td><?= $tabel['jenispembayaran']?></td>
                  <td>
                    <?php
                      echo ($tabel['jenispembayaran'] == 'cash' ? '-' : date('d-m-Y',strtotime($tabel['tgl_jatuhtempo'])))
                    ?>
                  </td>
                  <td><?= 'Rp. '.number_format($tabel['totalnota']);?></td>
                  <td><?= $tabel['status']?></td>
                  <td>
                     <a href="hutang-bayar/<?= $tabel['id_pembelian']?>" title="Bayar Hutang"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-dollar"></i></button></a>
                    </td>
                </tr>
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->