<?php 
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surat Jalan</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
        }
        table {
        border-collapse: collapse;
        }
        .judul{
        font-weight: bold;
        font-size: 12px;
        }
        td{
        font-weight: bold;
        font-size: 10px;
        }
        @page { 
          margin-top: 1.2cm;
          margin-bottom: 1.2cm;
          margin-left: 2cm;
          margin-right: 2cm;
        }
    </style>
</head>
<body>
    <table width="100%" align="center">
        <tr>
          <th width="60%" align="left" class="judul">UD SATELIT</th>
          <th align="left" colspan="2" class="judul">SURAT JALAN</th>
        </tr>
        <tr>
          <td width="60%" align="left">Jl. Kuwukan No. 72 - Lontar. Surabaya</td>
          <td align="left" width="12%">No </td>
          <td align="left">: <?= $penjualan->kodenota?></td>
        </tr>
        <tr>
          <td width="60%" align="left">Tep/Fax : (031)-7404275</td>
          <td align="left">Tanggal </td>
          <td align="left">: <?= date('d-m-Y',strtotime($penjualan->tgl_update))?></td>
        </tr>
        <tr>
          <td width="60%" align="left">HP 085130404679</td>
          <td align="left">Sales</td>
          <td align="left">: <?= $penjualan->namasales?></td>
        </tr>
        <tr>
          <td width="60%" align="left">http://www.satelitpaint.com</td>
          <td align="left">Pelanggan</td>
          <td align="left">: <?= $penjualan->namacustomer?></td>
        </tr>
        <tr>
          <td width="60%" align="left"></td>
          <td align="left">Alamat</td>
          <td align="left">: <?= $penjualan->alamat?></td>
        </tr>
        <tr>
          <td width="60%" align="left"></td>
          <td align="left">Kota</td>
          <td align="left">:</td>
        </tr>
      </table>
      <BR>
      <table width="100%" align="center" border="1">
        <thead>
          <tr>
            <td align="center">No</td>
            <td align="center">Kode Item</td>
            <td align="center">Nama Item</td>
            <td align="center">Jumlah</td>
            <td align="center">Satuan</td>
          </tr>
        </thead>
        <tbody>
            <?php 
                $no = 1;
                $total = 0;
                foreach ($database as $tabel) :
                $total = $total+$tabel['subtotal'];
            ?>
            <tr>
                <td align="center"><?= $no++?></td>
                <td ><?= $tabel['kodebarang']?></td>
                <td><?= $tabel['barang']?></td>
                <td align="center"><?= $tabel['qtt']?></td>
                <td><?= $tabel['satuan']?></td>
            </tr>
            <?php endforeach;?>
        </tbody>
      </table>
      <br>
      <table width="100%" align="center">
        
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                Mengetahui,<br><br><br><br><br>
            </td>
            <td colspan="2" align="center">
                Penerima<br><br><br><br><br>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center"><hr size="3px" width="30%"></td>
            <td colspan="2" align="center"><hr size="3px" width="30%"></td>
        </tr>
      </table>
</body>
</html>