<style>
  a.disabled {
  pointer-events: none;
  cursor: default;
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Penjualan
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('penjualan'); ?>">Data Penjualan</a></li>
        <li class="active">Tambah Data Penjualan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <!-- /.col -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active" id="activ"><a href="#activity" data-toggle="tab" id="pembelian">Tambah Penjualan</a></li>
              <li id="timelinee"><a href="#timeline" data-toggle="tab"  id='keranjangbelanja' class="disabled">Keranjang Belanja</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                <div class="post">
                <form class="form-horizontal">
                    <div class="form-group">
                      <label for="inputName" class="col-sm-2 control-label">Nama Customer</label>

                      <div class="col-sm-10">
                        <select class="form-control select2" name="id_customer" id="id_customer">
                              <option selected="selected" value="">--Pilih--</option>
                              <?php foreach ($database as $customer) : ?>
                                  <option value="<?= $customer->id_customer?>"><?= $customer->namacustomer?></option>
                              <?php endforeach;?>
                          </select>
                          <span style="color: red;" id='id_customerError'></span>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="inputEmail" class="col-sm-2 control-label">Jenis Pembayaran</label>

                      <div class="col-sm-10">
                        <select class="form-control select2" name="jenispembayarancustomer" id="jenispembayarancustomer">
                              <option selected="selected" value="">--Pilih--</option>
                              <option value="cash">Cash</option>
                              <option value="kredit">Kredit</option>
                          </select>
                          <span style="color: red;" id='jenispembayarancustomerError'></span>
                      </div>
                    </div>
                    <div class="form-group" id="showlimit" style="display:none">
                    <label for="inputName" class="col-sm-2 control-label">Limit Hutang</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="limit_hutang" name="limit_hutang" value="">
                    </div>
                  </div>
                    <div class="form-group" id="showtempo" style="display:none">
                    <label for="inputName" class="col-sm-2 control-label">Tanggal Jatuh Tempo</label>

                    <div class="col-sm-10">
                    <input type="text" class="form-control pull-right" id="datepicker" name='jatuhtempo'>
                    <input type="hidden" class="form-control pull-right" id="max_id" name='id_penjualan' value="<?= $max_id; ?>">
                    <input type="hiden" class="form-control pull-right" id="sales_id" name='sales_id'>
                    </div>
                  </div>
                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <button class="btn btn-default btnBatalJual">Batal</button>
                        <button type="submit" class="btn btn-info btn-submit btnJual">Lanjut</button>
                      </div>
                    </div>
                </div>
                </form>
                <!-- /.post -->
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                <form class="form-horizontal">
                  <div class="form-group">
                    <input type="hidden" class="form-control pull-right" id="id_dtlpenjualan" name='id_dtlpenjualan'>
                    <label for="inputName" class="col-sm-2 control-label">Pilih Barang</label>
                    <div class="col-sm-10">
                    <select class="form-control select2"  required name="id_barang" id="id_barang" style="width: 100%" required> 
                              <option selected="selected" value="">--Pilih--</option>
                              <?php foreach ($barang as $brg) : ?>
                                  <option value="<?= $brg->id_barang?>"><?= $brg->barang?></option>
                              <?php endforeach;?>
                          </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Qty</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="qtt" id="qtt" placeholder="Qtt" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Harga</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="harga" id="rupiah" placeholder="Harga" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Diskon</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="diskon" id="diskon" placeholder="Diskon" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button class="btn btn-default" id="btnBack">Kembali</button>
                      <button class="btn btn-default btnBatal" style="display:none">Batal</button>
                      <button class="btn btn-info btnPenjualan" type='submit'>Tambah</button>
                      <button class="btn btn-info btnPenjualanUpdate" style="display:none">Update</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <div class="row" id="invoice" style="display:none">
        <div class="col-md-8">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Keranjang Belanja</h3>
            </div>
            <div class="box-body table-responsive">
              <table width ="100%" class="table table-bordered" id="table-example4" data-url="<?= base_url('C_Penjualan/json'); ?>">
                <thead>
                  <th>No</th>
                  <th>Barang</th>
                  <th>Qtt</th>
                  <th>Harga</th>
                  <th>Diskon</th>
                  <th>Sub Total</th>
                  <th>Action</th>
                </thead>
                <tbody>
                </tbody>
                <tfoot align="right">
                  <tr>
                      <th colspan="5"></th>
                      <th colspan='2'></th>
                      
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col (left) -->
        <div class="col-md-4">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Invoice</h3>
            </div>
            <div class="box-body">
              <div class="form-horizontal">
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-4 control-label">Total</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" id="subtotalbawah" name="subtotalbawah"  readonly>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-4 control-label">Diskon</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" id="diskon1" name="diskon1" value="0" onkeyup="subtotalall()">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-4 control-label">Total Akhir</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" id="total" name="total" readonly>
                      <span>(Total - Diskon)</span>
                    </div>
                    
                  </div>

                <div class="box-footer">
                    <div class="col-sm-7">
                      <button class="btn btn-default" name="batalall" id="deleteall">Batal</button>
                      <button class="btn btn-info" name="simpanall" id="simpanall">Simpan</button>
                    </div>
                </div>
              </div>
            <!-- /.box-body -->
          </div>

        </div>
        <!-- /.col (right) -->
      </div>
    </section>
    <!-- /.content -->
    <div id="base-url" data-url="<?= base_url(); ?>"></div>
  </div>

  <!-- /.content-wrapper -->
