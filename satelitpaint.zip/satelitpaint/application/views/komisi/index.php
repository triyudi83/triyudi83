
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Komisi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('komisi'); ?>">Data Komisi</a></li>
        <li class="active">Lihat Data</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Komisi</h3>
            </div>
            <!-- /.box-header -->
            <?php if($aksesedit == 'aktif') : ?>
            <div class="box-header">
              <a href="<?php echo site_url('komisi-add'); ?>"><button type="button" class="btn btn-warning" >Tambah Data</button></a>
            </div>
            <?php endif;?>
            <div class="box-body  table-responsive">
              
              <table id="Komisi" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Tgl Komisi</th>
                  <th>Sales</th>
                  <th>Tgl Periode Awal Penjualan</th>
                  <th>Tgl Periode Akhir Penjualan</th>
                  <th>Total Nota</th>
                  <th>Komisi</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($Komisi as $tabel) :
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= date('d-m-Y',strtotime($tabel['tgl_komisi']))?></td>
                  <td><?= $tabel['namasales']?></td>
                  <td><?= date('d-m-Y',strtotime($tabel['tgl_periodeawal']))?></td>
                  <td><?= date('d-m-Y',strtotime($tabel['tgl_periodeakhir']))?></td>
                  <td><?= 'Rp. '.number_format($tabel['totalnota'])?></td>
                  <td><?= 'Rp. '.number_format($tabel['komisi'])?></td>
                  <td><div class="btn-group">
                    <a href="<?php echo site_url('komisi-view/'.$tabel['id_komisi']); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-search"></i></button></a>
                      <?php if($aksesedit == 'aktif'){?>
                      <a href="<?php echo site_url('komisi-edit/'.$tabel['id_komisi']); ?>"><button type="button" class="btn btn-info"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>
                    <?php } if($akseshapus == 'aktif'){ ?>
                      <a href="<?php echo site_url('komisi-delete/'.$tabel['id_komisi']); ?>" onclick="return confirm('Apakah Anda Yakin ?')"><button type="button" class="btn btn-danger"><i class="fa fa-fw fa-trash-o"></i></button></a>
                    <?php } ?>
                    </div>
                  </td>
                </tr>
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->