
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Komisi Penjualan
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('komisi'); ?>">Komisi</a></li>
        <li class="active">Komisi Penjualan</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-md-4">
        <div class="box box-primary">
            
            <div class="box-body no-padding">

                    <form class="form-horizontal" action="<?php echo site_url('C_Komisi/add')?>"  enctype="multipart/form-data" Method="POST">
                    <div class="box-body">
                        <div class="form-group">
                        <label for="inputEmail3" class="col-sm-3 control-label">Tanggal</label>

                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="tgl_transaksi" id="tgl_transaksi" value="<?= date('d-m-Y')?>" readonly>
                        </div>
                        </div>
                        <div class="form-group">
                        <label for="inputPassword3" class="col-sm-3 control-label">Sales</label>
                        <div class="col-sm-8">                            
                            <select class="form-control select2" id="komisisales" name="komisisales" style="width: 100%;">
                              <option value="">--Pilih--</option>
                              <?php foreach ($sales as $sales) { ?>
                              <option value="<?= $sales['id_sales'] ?>"><?= $sales['namasales'] ?></option>
                              <?php } ?>
                            </select>
                        </div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="col-sm-3 control-label">Total Nota</label>

                            <div class="col-sm-8">
                            <input type="text" class="form-control" id="totalnota" name="totalnota" readonly>
                            <input type="text" class="form-control" id="tgl" name="tgl" readonly>
                            </div>
                        </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-3 control-label">Komisi</label>

                    <div class="col-sm-8">
                      <input type="text" class="form-control" name="komisi" id="rupiah" placeholder="Komisi" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-8">
                      <button class="btn btn-default" onclick="deletePenjualan()" type="button">Kembali</button>
                      <button class="btn btn-info" type='submit'>Tambah</button>
                    </div>
                  </div>
                    </div>
                    <!-- /.box-body -->
                    <!-- /.box-footer -->
                    </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
          <!-- /.box -->
        </div>
        <div class="col-md-8">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Nota Penjualan</h3>
            </div>
            <div class="box-header with-border">
              <div class="form-group">
                <label>Range Tanggal:</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" id="reservation" name="reservation">
                </div>
                <!-- /.input group -->
              </div>
            </div>
              
            <div class="box-body table-responsive">
              <table width ="100%" class="table table-bordered" >
                <thead>
                  <th>No</th>
                  <th>Kode Penjualan</th>
                  <th>Customer</th>
                  <th>Total Nota</th>
                </thead>
                <tbody>
                </tbody>
                <tfoot align="right" id="tabelkomisi">
                  <div >
                  </div>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
        <!-- /.col (left) -->
        <!-- /.col -->
      </div>

      <div class="modal fade" id="modal-default" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close closeBarang">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Data Barang</h4>
              </div>
              <div class="modal-body table-responsive">
              <table id="TabelBarang" class="table table-bordered">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Barang</th>
                  <th>Barang</th>
                  <th>Stok</th>
                  <th>Satuan</th>
                  <th>Harga</th>
                  <th>Aksi</th>
                </tr>
                </thead>
              </table>
              </div>
              <div class="modal-footer">
              <button type="button" class="btn btn-info pull-right closeBarang">Close</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      <div class="modal fade" id="modal-customer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close closemodal">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Data Customer</h4>
              </div>
              <div class="modal-body table-responsive"> 
              <table id="tabelCustomer" class="table table-bordered" width="100%">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Customer</th>
                  <th>Alamat</th>
                  <th>Telepon</th>
                  <th>Action</th>
                </tr>
                </thead>
              </table>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-info pull-right closemodal">Close</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script src="<?php echo base_url() ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script>
    $('#myFunction').keydown(function(event) {
      fungsikeyboard();
    });
    
  </script>