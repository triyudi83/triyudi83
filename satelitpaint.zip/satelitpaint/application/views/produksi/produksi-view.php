

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Produksi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('sales'); ?>">Produksi</a></li>
        <li class="active">Produksi View</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active" id="libarangjadi"><a data-toggle="tab" href="#home">Hasil Produksi</a></li>
              <li id="libahanbaku"><a data-toggle="tab" href="#menu1">Bahan Baku</a></li>
              <li id="libiayaproduksi"><a data-toggle="tab" href="#menu2">Biaya Produksi</a></li>

            </ul>
            <div class="tab-content">
              <!-- Data Barang Jadi -->
              <div id="home" class="tab-pane fade in active">

                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/png-transparent-package-delivery-mail-box-parcel-box-thumbnail.png" alt="User Image">
                      <span class="username"><a href="#">Hasil Produksi</a></span>
                    </div>
                  </div>

                  <div class="form-horizontal">
                    <div class="box-body">
                      <?php foreach ($produksi as $key) { 
                        $hpp = ($key->biayabahan+$key->biayaproduksi)/$key->qttproduksi; 
                        $biaya = $key->biayabahan+$key->biayaproduksi; ?>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Tanggal Produksi </label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo date('d-m-Y', strtotime($key->tgl_update)); ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Barang Jadi </label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo $key->barang; ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Hasil Produksi </label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo $key->hasilproduksi; ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Qtt </label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo $key->qttproduksi; ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Biaya Bahan Produksi </label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo 'Rp. '.number_format($key->biayabahan); ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Biaya Produksi Lain-lain</label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo 'Rp. '.number_format($key->biayaproduksi); ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Total Biaya Produksi </label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo 'Rp. '.number_format($biaya); ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">HPP Produksi</label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo 'Rp. '.number_format($hpp); ?>" readonly>
                          </div>
                      </div>
                      <input type="hidden" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo $key->id_produksi; ?>" readonly>
                      
                      <?php } ?>
                      <div class="box-footer">
                        <div class="col-sm-10">
                          <a href="<?php echo site_url('produksi'); ?>" class="btn btn-default">Kembali</a>
                          <a href="#menu1" data-toggle="tab"> <button class="btn btn-info" id="buttonhasilproduksi">Selanjutnya</button></a>
                        </div>
                      </div>
            <!-- /.box-body -->
                    </div>
                </div>
              </div>
              <!-- End Data Barang Jadi -->
              <div id="menu1" class="tab-pane fade">
                <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/kerangjang.png" alt="User Image">
                      <span class="username"><a href="#">Rekap Bahan Baku</a></span>
                    </div>
                  </div>
                  <div class="box-body">
                    
                    <table width ="100%" class="table" id="example1">
                      <thead>
                      <tr>
                        <th>No</th>
                        <th>Barang</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Sub Total </th>
                      </tr>
                      </thead>
                      <tbody>
                        <?php 
                        $no = 1;
                        foreach ($bahan as $bahan) { 
                          $subtotal = $bahan->hargabahan*$bahan->qtt; ?>
                          <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $bahan->barang; ?></td>
                            <td><?php echo 'Rp. '.number_format($bahan->hargabahan); ?></td>
                            <td><?php echo number_format($bahan->qtt); ?></td>
                            <td><?php echo 'Rp. '.number_format($subtotal); ?></td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>

                  <button class="btn btn-primary" id="buttonbahanbaku" data-toggle="tab" href="#menu2">Selanjutnya</button>
                </div>
              </div>
              <div id="menu2" class="tab-pane fade">
                <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/download.png" alt="User Image">
                      <span class="username"><a href="#">Rekap Biaya Produksi</a></span>
                    </div>
                  </div>
                  <div class="box-body">
                    
                    <table class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>No</th>
                        <th>Keterangan</th>
                        <th>Nominal</th>
                      </tr>
                      </thead>
                      <tbody>

                        <?php 
                        $i = 1;
                          foreach ($ll as $biaya) { ?>
                               <tr>
                                  <td><?= $i++; ?></td>
                                  <td><?= $biaya->ket; ?></td>
                                  <td><?= 'Rp. '.number_format($biaya->nominal); ?></td>
                                </tr><?php 
                            }?>
                      </tbody>
                    </table>
                  </div>
                </div>

                          <a href="<?php echo site_url('produksi'); ?>" class="btn btn-default">Ke Menu Awal</a>
                      <a href="<?php echo site_url('produksi-cetak/'.$key->id_produksi); ?>"><button type="button" class="btn btn-primary">Cetak</button></a>
              </div>
              <!-- menu 3 -->
                </div>
              </div>
              <!-- end menu 3 -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>