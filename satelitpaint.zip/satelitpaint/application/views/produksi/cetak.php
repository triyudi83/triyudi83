<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Satelit Paint</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/ower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body onload="window.print();">
  <div class="content-wrapper">
  <!-- Main content -->
    <section class="invoice">
      <?php foreach ($produksiall as $all) {
        $kode= $all->kodeproduksi;
      } ?>
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-globe"></i> Satelit Paint.
            <small class="pull-right">Tanggal : <?php echo date('d-m-Y', strtotime($all->tgl_update)) ?> </small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          Produksi
          <address>
            <strong><?php echo $all->barang; ?></strong><br>
            Qtt <?php echo $all->qttproduksi.' '.$all->satuan ?><br>
          <b>Kode Produksi:</b> <?php echo $all->kodeproduksi; ?><br>
          <b>Tanggal Produksi :</b> <?php echo date('d-m-Y', strtotime($all->tgl_update)) ?><br>
          
          </address>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th colspan="5"><h4>Bahan Baku</h4></th>
            </tr>
            <tr>
              <th>No</th>
              <th>Kode Formulasi</th>
              <th>Barang</th>
              <th>Harga</th>
              <th>Qty</th>
              <th>Sub Total </th>
            </tr>
            </thead>
            <tbody>
            <?php 
              $no = 1;
              foreach ($bahan as $bahan) { 
                $subtotal = $bahan->hargabahan*$bahan->qtt; ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $bahan->kodeformulasi; ?></td>
                  <td><?php echo $bahan->barang; ?></td>
                  <td><?php echo 'Rp. '.number_format($bahan->hargabahan); ?></td>
                  <td><?php echo number_format($bahan->qtt); ?></td>
                  <td><?php echo 'Rp. '.number_format($subtotal); ?></td>
                </tr>
              <?php } ?>
            
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th colspan="5"><h4>Biaya Produksi Lainnya</h4></th>
            </tr>
              <tr>
                <th>No</th>
                <th>Keterangan</th>
                <th>Nominal</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $i = 1;
                foreach ($ll as $biaya) { ?>
                     <tr>
                        <td><?= $i++; ?></td>
                        <td><?= $biaya->ket; ?></td>
                        <td><?= 'Rp. '.number_format($biaya->nominal); ?></td>
                      </tr><?php 
                  }?>
            
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <div class="row">
        <!-- /.col -->
        <div class="col-xs-6">
          <p class="lead">Total Biaya Produksi</p>

          <div class="table-responsive">
            <table class="table">
              <tr>
                <th style="width:50%">Biaya Bahan Baku:</th>
                <td><?php echo 'Rp. '.number_format($all->biayabahan); ?></td>
              </tr>
              <tr>
                <th style="width:50%">Biaya Lainnya:</th>
                <td><?php echo 'Rp. '.number_format($all->biayaproduksi); ?></td>
              </tr>
              <tr>
                <th>Total Biaya Produksi :</th>
                <td><?php echo 'Rp. '.number_format($all->biayaproduksi+$all->biayabahan); ?></td>
              </tr>
              <tr>
                <th>Harga Pokok Produksi:</th>
                <td><?php echo 'Rp. '.number_format(($all->biayaproduksi+$all->biayabahan)/$all->qttproduksi); ?></td>
              
              </tr>
            </table>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
  </div>
  <!-- /.content-wrapper -->
<!-- ./wrapper -->
</body>
</html>
