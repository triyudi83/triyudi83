

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Produksi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('sales'); ?>">Produksi</a></li>
        <li class="active">Produksi</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active" id="libarangjadi"><a data-toggle="tab" href="#home">Data Barang Jual</a></li>
              <li id="libahanbaku"><a data-toggle="tab" href="#menu1">Bahan Baku</a></li>
              <li id="libiayaproduksi"><a data-toggle="tab" href="#menu2">Biaya Produksi</a></li>
              <li id="lihasilproduksi"><a data-toggle="tab" href="#hasilproduksi">Hasil Produksi</a></li>

            </ul>
            <div class="tab-content">
              <!-- Data Barang Jadi -->
              <div id="home" class="tab-pane fade in active">

                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/png-transparent-package-delivery-mail-box-parcel-box-thumbnail.png" alt="User Image">
                      <span class="username"><a href="#">Rencana Produksi</a></span>
                    </div>
                  </div>

                  <form class="form-horizontal" method="POST" id="formsimpanbarangjadi">
                    <div class="box-body">
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Kode Produksi </label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control col-xs-4" id="kodeproduksi" name="kodeproduksi" value= "<?php echo $kode; ?>" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Barang Jual </label>
                          <div class="col-sm-9">
                           <select class="form-control select2" required name="barangjadi" id="barangjadi">
                              <option selected="selected" value="">--Pilih--</option>
                              <?php foreach ($barang as $barang){ ?>
                                  <option value="<?php echo $barang->id_barang; ?>"><?php echo $barang->barang; ?></option>
                              <?php } ?>
                            </select>
                          </div>
                      </div>
                      <input type="hidden" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo $id_produksi; ?>" readonly>
                      

                    </form>
                <div class="box-footer">
                    <div class="col-sm-10">
                      <a href="<?php echo site_url('produksi'); ?>" class="btn btn-default">Batal</a>
                      <a href="#menu1" data-toggle="tab"> <button class="btn btn-info" onclick="barangjadiproduksi()" >Selanjutnya</button></a>
                        <!-- <a href="#menu1" data-toggle="tab"><button id='barangjadiproduksi' class="btn btn-info">Lanjut</button></a> -->
                    </div>
                </div>
            <!-- /.box-body -->
                </div>
              </div>
              <!-- End Data Barang Jadi -->
              <div id="menu1" class="tab-pane fade">
              <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/resep.png" alt="User Image">
                      <span class="username"><a href="#">Formulasi</a></span>
                    </div>
                  </div>
                  <div class="box-body">      
                  <div class="form-horizontal">                             
                      <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Formulasi</label>
                        <div class="col-sm-9">
                          <select class="form-control select2" id="formulasi" name="formulasi" style="width: 90%;">
                            <option value="">--Pilih--</option>
                            <?php foreach ($resep as $resep) { ?>
                            <option value="<?php echo $resep->id_resep ?>"><?php echo $resep->kodeformulasi ?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>        
                  </div>
                  <!-- </form> -->
                  </div>
                </div>
                <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/png-transparent-package-delivery-mail-box-parcel-box-thumbnail.png" alt="User Image">
                      <span class="username"><a href="#">Bahan Baku</a></span>
                    </div>
                  </div>
                  <div class="box-body">
                    
                    <table width ="100%" class="table" id="tabelbahanbaku">
                      <thead>
                      <tr>
                        <th>No</th>
                        <th>Barang</th>
                        <th>Qtt Formulasi</th>
                        <th>Harga</th>
                        <th>Qtt</th>
                        <th width="120">Action</th>
                      </tr>
                      </thead>
                      <tbody id="showformulasi">
                      </tbody>
                    </table>
                  </div>
                </div>

                <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/kerangjang.png" alt="User Image">
                      <span class="username"><a href="#">Rekap Bahan Baku</a></span>
                    </div>
                  </div>
                  <div class="box-body">
                    
                    <table width ="100%" class="table" id="example1">
                      <thead>
                      <tr>
                        <th>No</th>
                        <th>Kode Formulasi</th>
                        <th>Barang</th>
                        <th>Qtt</th>
                        <th>Harga</th>
                      </tr>
                      </thead>
                      <tbody id=showrekap>
                      </tbody>
                    </table>
                  </div>
                </div>

                          <button class="btn btn-primary" id="buttonbahanbaku" data-toggle="tab" href="#menu2">Selanjutnya</button>
              </div>
              <div id="menu2" class="tab-pane fade">
                <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/download.png" alt="User Image">
                      <span class="username"><a href="#">Biaya Lain Lain</a></span>
                    </div>
                  </div>
                  <div class="box-body">
                    
                    <div class="form-horizontal">
                      <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Keterangan</label>
                        <div class="col-sm-8">
                          <!-- <span id="stokmin"></span> -->
                          <input type="text" class="form-control" id="ketbiaya" name="ketbiaya">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Nominal</label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" id="biayaprod" name="biayaprod">
                        </div>
                      </div>

                    <div class="box-footer">
                        <div class="col-sm-10">
                          <button class="btn btn-info" id="tambahbiaya" name="tambahbiaya">Tambah Biaya Lainnya</button>
                          <a data-toggle="tab" href="#hasilproduksi"><button class="btn btn-primary" id="buttonbiayaproduksi" data-toggle="tab" href="#hasilproduksi">Selanjutnya</button></a>
                        </div>
                    </div>
                  </div>
                  </div>
                </div>

                <div class="box">
                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/download.png" alt="User Image">
                      <span class="username"><a href="#">Rekap Biaya Produksi</a></span>
                    </div>
                  </div>
                  <div class="box-body">
                    
                    <table id="example1" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>No</th>
                        <th>Keterangan</th>
                        <th>Nominal</th>
                        <th width="120">Action</th>
                      </tr>
                      </thead>
                      <tbody id=showbiaya>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <!-- menu 3 -->
              <div id="hasilproduksi" class="tab-pane fade">

                  <div class="box-header">
                    <div class="user-block">
                      <img class="img-circle" src="<?php echo base_url() ?>assets/images/png-transparent-package-delivery-mail-box-parcel-box-thumbnail.png" alt="User Image">
                      <span class="username"><a href="#">Hasil Produksi Barang Jual</a></span>
                    </div>
                  </div>

                  <form class="form-horizontal" method="POST" action="<?php echo site_url('C_Produksi/simpanproduksi')?>" id="simpanall">
                    <div class="box-body">
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Barang Jual </label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control col-xs-4" id="baranghasil" name="baranghasil" readonly>
                           
                            <input type="hidden" class="form-control col-xs-4" id="id_baranghasil" name="id_baranghasil" readonly>
                          </div>
                      </div>
                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Qtt</label>
                          <div class="col-sm-3">
                            <input type="text" class="form-control col-xs-4" id="qtt_barangjadi" name="qtt" placeholder="Qtt" onkeypress="return Angkasaja(event)" required>   
                          </div>
                          <div class="col-sm-1">
                            <input type="text" class="form-control col-xs-4" id="satuan" name="satuan" readonly>                        
                            <input type="hidden" class="form-control col-xs-4" id="id_satuan" name="id_satuan" readonly>
                              <input type="hidden" class="form-control col-xs-4" id="id_produksi" name="id_produksi" value= "<?php echo $id_produksi; ?>" readonly>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Total Biaya Bahan Baku</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control col-xs-4" id="biayabahanbaku" name="biayabahanbaku" readonly>   
                          </div>
                      </div>

                      <div class="form-group row">
                          <label class="col-sm-2 control-label">Total Biaya Lain Lain</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control col-xs-4" id="biayalainlain" name="biayalainlain" readonly>   
                          </div>
                      </div>
                    </form>
                <div class="box-footer">
                    <div class="col-sm-10">
                      <a href="<?php echo site_url('produksi'); ?>" class="btn btn-default">Batal</a>
                      <button type="submit" class="btn btn-info" id='simpanproduksi' onclick="SubmitMe()" >Simpan</button>
                        <!-- <a href="#menu1" data-toggle="tab"><button id='barangjadiproduksi' class="btn btn-info">Lanjut</button></a> -->
                    </div>
                </div>
            <!-- /.box-body -->
                </div>
              </div>
              <!-- end menu 3 -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!--MODAL HAPUS-->
        <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form class="form-horizontal">
                    <div class="modal-body">
                                           
                            <input type="hidden" name="kode" id="textkode" value="">
                            <p>Apakah Anda yakin mau menghapus barang ini?</p>
                                         
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                        <button class="btn_hapus btn btn-danger" id="btn_hapus">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <!--END MODAL HAPUS-->