
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Formulasi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('formulasi'); ?>">Data Formulasi</a></li>
        <li class="active">Data Formulasi</li>
      </ol>
    </section>
    <div class="box-body">
          <?=$this->session->flashdata('flash')?>
    </div>
    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Data Formulasi</h3>
            </div>
            <!-- /.box-header -->
            <?php if($aksesedit == 'aktif') : ?>
            <div class="box-header">
                <!-- Check all button -->
                <a href="<?= site_url('formulasi-add')?>">
                <button type="button" class="btn btn-warning">Tambah Data
                </button>
                </a>
            </div>
            <?php endif;?>
            <div class="box-body  table-responsive">
              
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Formulasi</th>
                  <th>Nama Bahan</th>
                  <th>Satuan</th>
                  <th>Qtt</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no = 1;
                  foreach ($database as $tabel) :
                ?>
                <tr>
                  <td><?= $no++?></td>
                  <td><?= $tabel['kodeformulasi']?></td>
                  <td><?= $tabel['barang']?></td>
                  <td><?= $tabel['satuan']?></td>
                  <td><?= $tabel['qtt']?></td>
                  <td>
                    <a href="<?php echo site_url('formulasi-view/'.$tabel['id_resep']); ?>"><button type="button" class="btn btn-success"><i class="fa fa-fw fa-search"></i></button></a>
                    <?php if($aksesedit == 'aktif'){?>
                      <a href="<?php echo site_url('formulasi-edit/'.$tabel['id_resep']); ?>"><button type="button" class="btn btn-info"><i class="fa fa-fw fa-pencil-square-o"></i></button></a>
                    <?php } if($akseshapus == 'aktif'){ ?>
                      <a href="<?php echo site_url('C_Resep/delete/'.$tabel['id_resep']); ?>" onclick="return confirm('Apakah Anda Yakin ?')"><button type="button" class="btn btn-danger"><i class="fa fa-fw fa-trash-o"></i></button></a>
                    <?php } ?>
                  </td>
                </tr> 
                <?php endforeach;?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->