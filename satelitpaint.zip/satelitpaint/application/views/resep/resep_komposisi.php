
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Formulasi
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('formulasi'); ?>">Data Formulasi</a></li>
        <li class="active">Data Formulasi</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12"> 
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Lihat Data Formulasi</h3>
            </div>
            <!-- /.box-header -->
            <?php if(empty($database)) : ?>
              <div class="alert alert-warning alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-warning"></i> Data Formulasi!</h4>
                Tidak Ada.
              </div>
            <?php endif;?>
            <form class="form-horizontal" action="" method='POST' enctype="multipart/form-data">
            <div class="box-body">
            <div class="form-group row">
                    <label class="col-sm-2 control-label">Formulasi Barang</label>
                    <div class="col-sm-9">
                        <select class="form-control select2"  required name="id_barang" id="barangjadi" disabled>
                            <option selected="selected" value="">--Pilih--</option>
                            <?php foreach ($barang as $brg) : ?>
                                <?php if($brg['id_barang'] == $database->id_barangjadi) : ?>
                                <option value="<?= $brg['id_barang']?>" selected><?= $brg['barang']?></option>
                                <?php else : ?>
                                  <option value="<?= $brg['id_barang']?>"><?= $brg['barang']?></option>
                                <?php endif;?>
                            <?php endforeach;?>
                        </select>
                        
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Qtt Barang Jadi</label>
                    <div class="col-sm-2">
                     <input type="text" class="form-control col-xs-4" name="qtt_barangjadi" onkeypress="return Angkasaja(event)" value="<?= $database->qtt ?>" readonly>
                     </div>
                    <div class="col-sm-1">
                      <input type="text" name="satuan" id="satuan" class="form-control col-xs-4" required readonly value="<?= $database->satuan?>">
                      <input type="hidden" name="id_satuan" id="id_satuan" class="form-control col-xs-4" value="<?= $database->id_satuan?>">
                      <input type="hidden" name="id_resep" class="form-control col-xs-4" value="<?= $database->id_resep?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Bahan Baku</label>
                    <div class="col-sm-9">
                        <select class="form-control select2"  required name="id_barangbaku" id="barang_baku">
                            <option selected="selected" value="">--Pilih--</option>
                            <?php foreach ($baku as $brg_baku) : ?>
                                <option value="<?= $brg_baku['id_barang']?>"><?= $brg_baku['barang']?></option>
                            <?php endforeach;?>
                        </select>
                        
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Qtt Bahan Baku</label>
                    <div class="col-sm-2">
                      <input type="text" class="form-control col-xs-4" name="qtt_barangbaku" onkeypress="return Angkasaja(event)" required>
                    </div>
                    <div class="col-sm-1">
                      <input type="text" name="satuan_baku" id="satuan_baku" class="form-control col-xs-4" required readonly/>
                      <input type="hidden" name="id_satuan_baku" id="id_satuan_baku" class="form-control col-xs-4"/>
                    </div>
                </div>
            <!-- /.box-body -->
          </div>
                <div class="box-footer">
                    <div class="col-sm-10">
                    <a href="<?php echo site_url('formulasi'); ?>" class="btn btn-default">Batal</a>
                    <button type="submit" class="btn btn-info">Simpan</button>
                    </div>
                </div>
            </form>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  