
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Satuan Barang
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Welcome'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo site_url('barang'); ?>">Data Barang</a></li>
        <li class="active">Tambah Data Satuan Barang</li>
      </ol>
    </section>

    <!-- Main content -->
 <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah Data Satuan Barang</h3>
            </div>
            <!-- /.box-header -->
            <form class="form-horizontal" action="" method='POST' enctype="multipart/form-data">
            <div class="box-body">           
                <div class="form-group row">
                    <label class="col-sm-2 control-label">Satuan Barang</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="satuan" id="satuan" required>
                    </div>
                </div>
            <!-- /.box-body -->
            </div>
                <div class="box-footer">
                    <div class="col-sm-10">
                    <a href="<?php echo site_url('satuan'); ?>" class="btn btn-default">Batal</a>
                    <button type="submit" class="btn btn-info">Simpan</button>
                    </div>
                </div>
            </form>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->