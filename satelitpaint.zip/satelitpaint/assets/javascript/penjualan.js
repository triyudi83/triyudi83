var now = moment();
var caridatapenjualan = function (settings, data, dataIndex) {
    var min = $('#startDate').val()
    var max = $('#endDate').val()
    var createdAt = data[2] || 0; // Our date column in the table
    //createdAt=createdAt.split(" ");
    var startDate = moment(min, "DD/MM/YYYY");
    var endDate = moment(max, "DD/MM/YYYY");
    var diffDate = moment(createdAt, "DD/MM/YYYY");
    if (min === "" && max === "") {
        return true;
    }
    if (diffDate.isSameOrAfter(startDate) && max === "") {
        return true;
    }
    if (diffDate.isSameOrBefore(endDate) && min === "") {
        return true;
    }
    if (diffDate.isSameOrAfter(startDate) && diffDate.isSameOrBefore(endDate)) {
        return true;
    }
    return false;
}
// Event listener to the two range filtering inputs to redraw on input

$("#penjualan").DataTable({
    buttons: [
        {
            text: 'Export Excel',
            className: 'btn btn-success',
            extend: 'excelHtml5',
            title: 'Laporan Penjualan'
        }
    ]
}).buttons().container().appendTo('#buttons-penjualan');

var penjualan = $('#penjualan').DataTable();

$('#startDate, #endDate').on('change', function () {
    $.fn.dataTable.ext.search.push(caridatapenjualan);
    penjualan.draw();
});

$("#transaksiPenjualan").change(function () {
    var status = $("#transaksiPenjualan").val();
    penjualan.column(4).search(status).draw();
})

$("#laporan_penjualan").change(function () {
    var status = $("#laporan_penjualan").val();
    penjualan.column(7).search(status).draw();
})

$(".export-penjualan").click(function () {
    penjualan.button('.buttons-excel').trigger();
});

$('#tabelPenjualan').DataTable();
function tabelPenjualan() {
    $('#tabelPenjualan').DataTable({
        "footerCallback": function (row, data, start, end, display) {
            var api = this.api(), data;
            var intVal = function (i) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '') * 1 :
                    typeof i === 'number' ?
                        i : 0;
            };
            var total = api.column(6).data().reduce(function (a, b) {
                return intVal(a) + intVal(b);
            }, 0);

            var numFormat = $.fn.dataTable.render.number('\.', '.', 0, 'Rp. ').display;
            document.getElementById("subtotalbawah").value = numFormat(total);
            $(api.column(5).footer()).html('Total :');
            $(api.column(6).footer()).html(numFormat(total));
        },
        'ordering': true,
        'fixedColumns': true,
        "responsive": true,
        "autoWidth": false,
        'deferRender': true,
        'order': [0, 'asc'],
        "ajax": {
            "url": "C_Penjualan/json",
            "type": "POST",
            data: {
                id_penjualan: $('[name="id_penjualan"]').val()
            }

        },
        "columns": [
            {
                "data": "id_dtlpenjualan",
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                }
            },
            { 'data': 'kodebarang' }, //Tampilkan Address
            { 'data': 'barang' }, //Tampilkan Address
            { data: 'qtt', render: $.fn.dataTable.render.number('.', '.', 0) },
            { data: 'harga', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp. ') },
            { data: 'diskon', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp.') },
            { data: 'subtotal', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp. ') },

            {
                'render': function (data, type, row) { //Tampilkan kolom Action
                    var html = '<button type="button" class="btn btn-danger" onclick="deleteDataPenjualan(this)" data-id="' + row.id_dtlpenjualan + '"><i class="fa fa-fw fa-trash-o"></i></button></a>'
                    return html;
                }
            }
        ],
        "columnDefs": [{
            targets: "_all",
            orderable: true
        }]
    });
}
function tabelCustomer() {
    $('#tabelCustomer').DataTable({
        'processing': true,
        'serverSide': true,
        'ordering': true,
        'fixedColumns': true,
        "responsive": true,
        "autoWidth": false,
        'order': [[1, 'asc']],
        "ajax": {
            "url": "C_Penjualan/customer",
            "type": "POST"
        },
        "columns": [
            {
                "data": "id_customer",
                render: function (data, type, row, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                }
            },
            { "data": "namacustomer" },
            {
                render: function (data, type, row, meta) {
                    return row.alamat + ' ' + row.kecamatan + ' ' + row.name_kota + ' ' + row.name_prov;
                },
            },
            { "data": "tlp" },
            {
                'render': function (data, type, row) { //Tampilkan kolom Action
                    var html = '<button type="button" class="btn btn-info" onclick="pilihdataCustomer(this)" data-id="' + row.id_customer + '"><i class="fa fa-fw fa-search"></i></button>'
                    return html;
                }
            }
        ],
        "columnDefs": [{
            targets: "_all",
            orderable: true
        }]
    });
}
$(".btnCustomer").click(function () {
    tabelCustomer();
    $('#modal-customer').modal({
        backdrop: 'static',
        keyboard: false,
    });
    $('#modal-customer').modal('show')
});

function pilihdataCustomer(arg) {
    var id = $(arg).attr('data-id');
    $.ajax({
        type: "POST",
        url: "C_Penjualan/getIdcustomer",
        data: { id: id },
        dataType: "json",
        beforeSend: function (e) {
            if (e && e.overrideMimeType) {
                e.overrideMimeType("application/json;charset=UTF-8");
            }
        },
        success: function (response) {
            var output = parseInt(response.sisalimit).toLocaleString();
            document.getElementById("id_customer").value = response.id_customer;
            document.getElementById("namacustomer").value = response.namacustomer;
            document.getElementById("id_sales").value = response.id_sales;
            $('#modal-customer').modal('hide');
            $('#tabelCustomer').DataTable().destroy();
            if ($("#jenispembayarancustomer").val() == 'kredit') {
                $("#showlimit").show();
                $("#showtempo").show();
                document.getElementById("limit_hutang").value = 'Rp ' + output;
            } else {
                $("#showlimit").hide();
                $("#showtempo").hide();
                document.getElementById("limit_hutang").value = '';
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
        }
    });
}

$("#jenispembayarancustomer").change(function () {
    if ($("#jenispembayarancustomer").val() == 'kredit') {
        $("#showlimit").show();
        $("#showtempo").show();
        $.ajax({
            type: "POST",
            url: "C_Penjualan/getIdcustomer",
            data: { id: $("#id_customer").val() },
            dataType: "json",
            beforeSend: function (e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function (response) {
                var output = parseInt(response.sisalimit).toLocaleString();
                document.getElementById("limit_hutang").value = 'Rp ' + output;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
            }
        });
    } else {
        $("#showlimit").hide();
        $("#showtempo").hide();
        document.getElementById("limit_hutang").value = '';
    }
});

$('.closemodal').click(function () {
    $('#modal-customer').modal('hide');
    $('#tabelCustomer').DataTable().destroy();
});

$("#formPenjualan").submit(function (event) {
    event.preventDefault();
    $('#tabelPenjualan').DataTable().destroy();
    var tgl_transaksi = $("#tgl_transaksi").val();
    var id_penjualan = $("#id_penjualan").val();
    var id_sales = $("#id_sales").val();
    var faktur = $("#faktur").val();
    var id_customer = $("#id_customer").val();
    var jenispembayarancustomer = $("#jenispembayarancustomer").val();
    var limit_hutang = $("#limit_hutang").val();
    var jatuhtempo = $("#datepicker").val();
    var id_barang = $("#id_barang").val();
    var namabarang = $("#namabarang").val();
    var qtt = $("#qtt").val().replace(/[^0-9]/g, '');
    var harga = $("#rupiah").val().replace(/[^0-9]/g, '');
    var diskon = $("#diskon").val().replace(/[^0-9]/g, '');
    $.ajax({
        type: "POST",
        url: "C_Penjualan/simpan",
        dataType: "JSON",
        data: {
            tgl_transaksi: tgl_transaksi,
            id_penjualan: id_penjualan,
            id_sales: id_sales,
            faktur: faktur,
            id_customer: id_customer,
            jenispembayarancustomer: jenispembayarancustomer,
            limit_hutang: limit_hutang,
            jatuhtempo: jatuhtempo,
            id_barang: id_barang,
            namabarang: namabarang,
            qtt: qtt,
            harga: harga,
            diskon: diskon
        },
        success: function (data) {
            if ($.isEmptyObject(data.error)) {
                $('#qttError').html('');
                $("#id_penjualan").val(data.id_penjualan).change();
                $("#qtt").val("").change();
                $("#rupiah").val("").change();
                $("#diskon").val("").change();
                $("#namabarang").val("").change();
                $("#id_barang").val("").change();
                tabelPenjualan();
            } else {
                $('#qttError').addClass('d-none');
                $.each(data.error, function (key, value) {
                    var ErrorID = '#' + key + 'Error';
                    $(ErrorID).removeClass("d-none");
                    $(ErrorID).addClass("text-danger");
                    $(ErrorID).text(value);
                });
            }
            //document.getElementById("id_pembelian").value = data.id_pembelian;


        }
    });
    return false;
});

function deleteDataPenjualan(arg) {
    var id = $(arg).attr('data-id');
    if (confirm('Apakah Anda Yakin?'))
        $.ajax({
            type: "POST",
            url: "C_Penjualan/delete_dtlpenjualan",
            dataType: "JSON",
            data: {
                id: id
            },
            success: function (data) {
                $('#tabelPenjualan').DataTable().ajax.reload();
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }
        });
    return false;
}

$("#formTotal").submit(function (event) {
    event.preventDefault();
    var id_penjualan = $('[name="id_penjualan"]').val();
    var subtotalbawah = $('[name="subtotalbawah"]').val().replace(/[^0-9]/g, '');
    var diskon1 = $('[name="diskon1"]').val().replace(/[^0-9]/g, '');
    var total = $('[name="total"]').val().replace(/[^0-9]/g, '');
    $.ajax({
        type: "POST",
        url: "C_Penjualan/update_all",
        dataType: "JSON",
        data: {
            id_penjualan: id_penjualan,
            subtotalbawah: subtotalbawah,
            diskon1: diskon1,
            total: total
        },
        success: function (data) {
            if ($.isEmptyObject(data.error)) {
                $('#totalError').html('');
                $('#diskon1Error').html('');
                window.location.href = data.success;
                //alert(data.success)
            } else {
                $('#totalError').html('');
                $('#diskon1Error').html('');
                $.each(data.error, function (key, value) {
                    var ErrorID = '#' + key + 'Error';
                    $(ErrorID).removeClass("d-none");
                    $(ErrorID).addClass("text-danger");
                    $(ErrorID).text(value);
                });
            }
        }
    });
    return false;
});

function deletePenjualan() {
    var id_penjualan = $('[name="id_penjualan"]').val();
    $.ajax({
        type: "POST",
        url: "C_Penjualan/batal/" + id_penjualan,
        dataType: "JSON",
        data: {
            id_penjualan: id_penjualan,
        },
        success: function (data) {
            window.location.href = data.redirect;
        }
    });
    return false;
}
$("#deletePenjualan").click(function () {
    deletePenjualan();
});
// $(".btnBatal").click(function () {
//     $("#id_barang").val('').change();
//     document.getElementById("qtt").value = '';
//     document.getElementById("rupiah").value = '';
//     document.getElementById("diskon").value = '';
//     $(".btnBatal").hide();
//     $("#btnBack").show();
//     $(".btnPenjualan").show();
//     $(".btnPenjualanUpdate").hide();
// });
// $(".btnJual").click(function () {
//     var id_customer = $("#id_customer").val();
//     var jenispembayarancustomer = $("#jenispembayarancustomer").val();
//     var id_penjualan = $("#max_id").val();
//     var limit_hutang = $("#limit_hutang").val();
//     var jatuhtempo = $('[name="jatuhtempo"]').val();
//     var id_sales = $('[name="id_sales"]').val();
//     $.ajax({
//         type: "POST",
//         url: "C_Penjualan/simpan",
//         dataType: "JSON",
//         data: {
//             id_customer: id_customer,
//             jenispembayarancustomer: jenispembayarancustomer,
//             limit_hutang: limit_hutang,
//             jatuhtempo: jatuhtempo,
//             id_penjualan: id_penjualan,
//             id_sales: id_sales
//         },
//         success: function (data) {
//             if (data.error) {
//                 $('#id_customerError').addClass('d-none');
//                 $('#jenispembayarancustomerError').addClass('d-none');
//                 $.each(data.error, function (key, value) {
//                     var ErrorID = '#' + key + 'Error';
//                     $(ErrorID).removeClass("d-none");
//                     $(ErrorID).html(value)
//                 })
//             } else {
//                 $('#id_customerError').html('');
//                 $('#jenispembayarancustomerError').html('');
//                 document.getElementById("max_id").value = data.id_penjualan;
//                 document.getElementById("keranjangbelanja").classList.remove("disabled");
//                 document.getElementById("activity").classList.remove("active");
//                 document.getElementById("pembelian").classList.add("disabled");
//                 document.getElementById("activ").classList.remove("active");
//                 document.getElementById("timeline").classList.add("active");
//                 document.getElementById("timelinee").classList.add("active");
//                 localStorage.setItem("id_penjualan", data.id_penjualan);
//                 $("#invoice").show();
//                 penjualan();
//             }
//         }
//     });
//     return false;
// })

// $(".btnBatalJual").click(function () {
//     var id_penjualan = $('[name="id_penjualan"]').val();
//     $.ajax({
//         type: "POST",
//         url: 'C_Penjualan/batal/' + id_penjualan,
//         dataType: "JSON",
//         data: {
//             id_penjualan: id_penjualan,
//         },
//         success: function (data) {
//             window.location.href = data.redirect;

//         }
//     });
//     return false;
// })

// $(".btnPenjualan").click(function () {
//     var id_barang = $('[name="id_barang"]').val();
//     var id_penjualan = $('[name="id_penjualan"]').val();
//     var qtt = $('[name="qtt"]').val();
//     var harga = $('[name="harga"]').val();
//     var diskon = $('[name="diskon"]').val();
//     $.ajax({
//         type: "POST",
//         url: "C_Penjualan/add_cart",
//         dataType: "JSON",
//         data: {
//             id_barang: id_barang,
//             id_penjualan: id_penjualan,
//             qtt: qtt,
//             harga: harga,
//             diskon: diskon
//         },
//         success: function (data) {
//             $("#id_barang").val('').change();
//             document.getElementById("qtt").value = '';
//             document.getElementById("rupiah").value = '';
//             document.getElementById("diskon").value = '';
//             $('#table-example4').DataTable().ajax.reload();
//         }
//     });
//     return false;
// })

// $("#jenispembayarancustomer").change(function () {
//     $.ajax({
//         type: "POST",
//         url: "C_Penjualan/getIdcustomer",
//         data: { id: $("#id_customer").val() },
//         dataType: "json",
//         beforeSend: function (e) {
//             if (e && e.overrideMimeType) {
//                 e.overrideMimeType("application/json;charset=UTF-8");
//             }
//         },
//         success: function (response) {
//             if ($("#jenispembayarancustomer").val() == 'kredit') {
//                 $("#showlimit").show();
//                 $("#showtempo").show();
//                 var output = parseInt(response.limit).toLocaleString();
//                 document.getElementById("limit_hutang").value = 'Rp ' + output;
//                 document.getElementById("id_sales").value = response.id_sales;
//             } else {
//                 $("#showlimit").hide();
//                 $("#showtempo").hide();
//                 document.getElementById("id_sales").value = response.id_sales;
//                 document.getElementById("datepicker").value = '';
//             }
//         },
//         error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
//             alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
//         }
//     });
// });

// $("#id_customer").change(function () {
//     $.ajax({
//         type: "POST",
//         url: "C_Penjualan/getIdcustomer",
//         data: { id: $("#id_customer").val() },
//         dataType: "json",
//         beforeSend: function (e) {
//             if (e && e.overrideMimeType) {
//                 e.overrideMimeType("application/json;charset=UTF-8");
//             }
//         },
//         success: function (response) {
//             if ($("#jenispembayarancustomer").val() == 'kredit') {
//                 $("#showlimit").show();
//                 $("#showtempo").show();
//                 var output = parseInt(response.limit).toLocaleString();
//                 document.getElementById("limit_hutang").value = 'Rp ' + output;
//                 document.getElementById("id_sales").value = response.id_sales;
//             } else {
//                 $("#showlimit").hide();
//                 $("#showtempo").hide();
//                 document.getElementById("id_sales").value = response.id_sales;
//                 document.getElementById("limit_hutang").value = '';
//                 document.getElementById("datepicker").value = '';
//             }
//         },
//         error: function (xhr, ajaxOptions, thrownError) { // Ketika ada error
//             alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError); // Munculkan alert error
//         }
//     });
// });

// function EditDataPenjualan(arg) {
//     var id = $(arg).attr('data-id');
//     $.ajax({
//         type: "POST",
//         url: "C_Penjualan/update_detail",
//         dataType: "JSON",
//         data: {
//             id: id,

//         },
//         success: function (data) {
//             var harga = parseFloat(data[0].harga).toLocaleString();
//             var diskon = parseFloat(data[0].diskon).toLocaleString();
//             diskon = diskon.replace(/,/g, '.');
//             harga = harga.replace(/,/g, '.');
//             $("#id_barang").val(data[0].id_barang).change();
//             document.getElementById("qtt").value = data[0].qtt;
//             document.getElementById("rupiah").value = 'Rp. ' + harga;
//             document.getElementById("diskon").value = 'Rp. ' + diskon;
//             document.getElementById("id_dtlpenjualan").value = id;
//             $('#table-example4').DataTable().ajax.reload();
//             $(".btnPenjualan").hide();
//             $("#btnBack").hide();
//             $(".btnPenjualanUpdate").show();
//             $(".btnBatal").show();
//             document.body.scrollTop = 0;
//             document.documentElement.scrollTop = 0;
//         }
//     });
//     return false;
// }


// $(".btnPenjualanUpdate").click(function () {
//     var id_barang = $('[name="id_barang"]').val();
//     var id_penjualan = $('[name="id_penjualan"]').val();
//     var qtt = $('[name="qtt"]').val();
//     var harga = $('[name="harga"]').val();
//     var diskon = $('[name="diskon"]').val();
//     var id_dtlpenjualan = $('[name="id_dtlpenjualan"]').val();
//     $.ajax({
//         type: "POST",
//         url: "C_Penjualan/cart_update",
//         dataType: "JSON",
//         data: {
//             id_barang: id_barang,
//             id_penjualan: id_penjualan,
//             qtt: qtt,
//             harga: harga,
//             diskon: diskon,
//             id_dtlpenjualan: id_dtlpenjualan
//         },
//         success: function (data) {
//             $('#table-example4').DataTable().ajax.reload();
//             $("#id_barang").val('').change();
//             document.getElementById("qtt").value = '';
//             document.getElementById("rupiah").value = '';
//             document.getElementById("diskon").value = '';
//             $(".btnPenjualan").show();
//             $("#btnBack").show();
//             $(".btnPenjualanUpdate").hide();
//             $(".btnBatal").hide();
//         }
//     });
//     return false;
// });

// function penjualan() {
//     var baseUrl = $('#base-url').data('url'); //Mengambil data value base_url dri elemen html
//     var table = $('#table-example4');
//     $('#table-example4').DataTable({
//         "footerCallback": function (row, data, start, end, display) {
//             var api = this.api(), data;
//             // converting to interger to find total
//             var intVal = function (i) {
//                 return typeof i === 'string' ?
//                     i.replace(/[\$,]/g, '') * 1 :
//                     typeof i === 'number' ?
//                         i : 0;
//             };
//             var total = api.column(5).data().reduce(function (a, b) {
//                 return intVal(a) + intVal(b);
//             }, 0);
//             var pageTotal = api
//                 .column(5, { page: 'current' })
//                 .data()
//                 .reduce(function (a, b) {
//                     return intVal(a) + intVal(b);
//                 }, 0);
//             var numFormat = $.fn.dataTable.render.number('\,', '.', 0, 'Rp. ').display;
//             var savetotal = localStorage.setItem("total", total);
//             var harga = parseFloat(total).toLocaleString();
//             harga = harga.replace(/,/g, '.');
//             document.getElementById("subtotalbawah").value = 'Rp. ' + harga;

//             // Update footer by showing the total with the reference of the column index
//             $(api.column(4).footer()).html('Total');
//             $(api.column(6).footer()).html(numFormat(total));
//         },

//         'processing': true,
//         'serverSide': true,
//         'ordering': true, //set true agar bisa sorting
//         'order': [[1, 'asc']], //default sortingnya berdasarkan field ke 0 (pertama)
//         'ajax': {
//             url: table.data('url'), //URL untuk ambil JSON
//             type: 'post',
//             data: {
//                 id_penjualan: $('[name="id_penjualan"]').val()
//             }
//         },
//         'deferRender': true,
//         'aLengthMenu': [[100], [100]], //Combobox Limit
//         'columns': [
//             {
//                 'render': function (data, type, row, meta) {
//                     return meta.row + 1;
//                 }
//             }, //Tampilkan Name
//             { 'data': 'barang' }, //Tampilkan Address
//             { data: 'qtt', render: $.fn.dataTable.render.number(',', '.', 0) },
//             { data: 'harga', render: $.fn.dataTable.render.number(',', '.', 0, 'Rp. ') },
//             { data: 'diskon', render: $.fn.dataTable.render.number(',', '.', 0, 'Rp.') },
//             { data: 'subtotal', render: $.fn.dataTable.render.number(',', '.', 0, 'Rp. ') },

//             {
//                 'render': function (data, type, row) { //Tampilkan kolom Action
//                     var html = '<button type="button" class="btn btn-info" onclick="EditDataPenjualan(this)" data-id="' + row.id_dtlpenjualan + '"><i class="fa fa-fw fa-pencil-square-o"></i></button>' + ' ' +
//                         '<button type="button" class="btn btn-danger" onclick="deleteDataPenjualan(this)" data-id="' + row.id_dtlpenjualan + '"><i class="fa fa-fw fa-trash-o"></i></button></a>'
//                     return html;
//                 }
//             }
//         ]
//     });
// }
