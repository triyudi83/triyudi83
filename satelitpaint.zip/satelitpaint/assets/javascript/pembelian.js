var now = moment();
var caridatapembelian = function (settings, data, dataIndex) {
    var min = $('#min').val()
    var max = $('#max').val()
    var createdAt = data[2] || 0; // Our date column in the table
    //createdAt=createdAt.split(" ");
    var startDate = moment(min, "DD/MM/YYYY");
    var endDate = moment(max, "DD/MM/YYYY");
    var diffDate = moment(createdAt, "DD/MM/YYYY");

    if (min === "" && max === "") {
        return true;
    }
    if (diffDate.isSameOrAfter(startDate) && max === "") {
        return true;
    }
    if (diffDate.isSameOrBefore(endDate) && min === "") {
        return true;
    }
    if (diffDate.isSameOrAfter(startDate) && diffDate.isSameOrBefore(endDate)) {
        return true;
    }
    return false;
}
$("#example").DataTable({
    buttons: [
        {
            text: 'Export Excel',
            className: 'btn btn-success',
            extend: 'excelHtml5',
            title: 'Laporan Pembelian'
        }
    ]
}).buttons().container().appendTo('#buttons');

var table = $('#example').DataTable();

$('#min, #max').on('change', function () {
    $.fn.dataTable.ext.search.push(caridatapembelian);
    table.draw();
});

$("#searchTransaksi").change(function () {
    var status = $("#searchTransaksi").val();
    console.log(status)
    table.column(4).search(status).draw();
})
$("#status_pembayaran").change(function () {
    var status = $("#status_pembayaran").val();
    console.log(status)
    table.column(7).search(status).draw();
})

$(".export").click(function () {
    table.button('.buttons-excel').trigger();
});

$('#totalTabel').DataTable();
function totalTabel() {
    $('#totalTabel').DataTable({
        "footerCallback": function (row, data, start, end, display) {
            var api = this.api(), data;
            var intVal = function (i) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '') * 1 :
                    typeof i === 'number' ?
                        i : 0;
            };
            var total = api.column(6).data().reduce(function (a, b) {
                return intVal(a) + intVal(b);
            }, 0);

            var numFormat = $.fn.dataTable.render.number('\.', '.', 0, 'Rp. ').display;
            document.getElementById("subtotalbawah").value = numFormat(total);
            $(api.column(5).footer()).html('Total :');
            $(api.column(6).footer()).html(numFormat(total));
        },
        'ordering': true,
        'fixedColumns': true,
        "responsive": true,
        "autoWidth": false,
        'deferRender': true,
        'order': [0, 'asc'],
        "ajax": {
            "url": "C_Pembelian/json",
            "type": "POST",
            data: {
                id_pembelian: $('[name="id_pembelian"]').val()
            }

        },
        "columns": [
            {
                "data": "id_dtlpembelian",
                render: function (data, type, row, meta) {
                    return meta.row + 1;
                }
            },
            { 'data': 'kodebarang' }, //Tampilkan Address
            { 'data': 'barang' }, //Tampilkan Address
            { data: 'qtt', render: $.fn.dataTable.render.number('.', '.', 0) },
            { data: 'harga', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp. ') },
            { data: 'diskon', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp.') },
            { data: 'subtotal', render: $.fn.dataTable.render.number('.', '.', 0, 'Rp. ') },

            {
                'render': function (data, type, row) { //Tampilkan kolom Action
                    var html = '<button type="button" class="btn btn-danger" onclick="deleteDatatable(this)" data-id="' + row.id_dtlpembelian + '"><i class="fa fa-fw fa-trash-o"></i></button>'
                    return html;
                }
            }
        ],
        "columnDefs": [{
            targets: "_all",
            orderable: true
        }]
    });
}
function dataSuplier() {
    $('#suplierTable').DataTable({
        'processing': true,
        'serverSide': true,
        'ordering': true,
        'fixedColumns': true,
        "responsive": true,
        "autoWidth": false,
        'order': [[1, 'asc']],
        "ajax": {
            "url": "C_Pembelian/suplier",
            "type": "POST"
        },
        "columns": [
            {
                "data": "id_suplier",
                render: function (data, type, row, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                }
            },
            { "data": "namasuplier" },
            {
                render: function (data, type, row, meta) {
                    return row.alamat + ' ' + row.kecamatan + ' ' + row.name_kota + ' ' + row.name_prov;
                },
            },
            { "data": "hp" },
            {
                'render': function (data, type, row) { //Tampilkan kolom Action
                    var html = '<button type="button" class="btn btn-info" onclick="pilihdataSuplier(this)" data-id="' + row.id_suplier + '"><i class="fa fa-fw fa-search"></i></button>'
                    return html;
                }
            }
        ],
        "columnDefs": [{
            targets: "_all",
            orderable: true
        }]
    });
}
function TabelBarang() {

    if ($("#keterangan").val() == 'customer') {
        $('#TabelBarang').DataTable({
            'processing': true,
            'serverSide': true,
            'ordering': true,
            'fixedColumns': true,
            "responsive": true,
            "autoWidth": false,
            'order': [3, 'desc'],
            "ajax": {
                "url": "C_Pembelian/getbarang",
                "type": "POST"
            },
            "columns": [
                {
                    "data": "id_barang",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                }, //Tampilkan Name
                { 'data': 'kodebarang' }, //Tampilkan Address
                { 'data': 'barang' }, //Tampilkan Address
                { 'data': 'stok' }, //Tampilkan Address
                { 'data': 'satuan' }, //Tampilkan Address
                { 'data': 'harga_jual' }, //Tampilkan Address
                {
                    'render': function (data, type, row) { //Tampilkan kolom Action
                        if (row.stok < 1) {
                            var html = '<button type="button" class="btn btn-danger" data-id="' + row.id_barang + '" title="Stok Barang Kosong"><i class="fa fa-fw fa-search"></i></button>'
                        } else {
                            var html = '<button type="button" class="btn btn-info" onclick="pilihdataBarang(this)" data-id="' + row.id_barang + '"><i class="fa fa-fw fa-search"></i></button>'
                        }
                        //var html = '<button type="button" class="btn btn-info" onclick="pilihdataBarang(this)" data-id="' + row.id_barang + '"><i class="fa fa-fw fa-search"></i></button>'
                        return html;
                    }
                }
            ],
            "columnDefs": [{
                targets: "_all",
                orderable: true
            }]
        });
    }
    else {
        $('#TabelBarang').DataTable({
            'processing': true,
            'serverSide': true,
            'ordering': true,
            'fixedColumns': true,
            "responsive": true,
            "autoWidth": false,
            'order': [[1, 'asc']],
            "ajax": {
                "url": "C_Pembelian/getbarang",
                "type": "POST"
            },
            "columns": [
                {
                    "data": "id_barang",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                }, //Tampilkan Name
                { 'data': 'kodebarang' }, //Tampilkan Address
                { 'data': 'barang' }, //Tampilkan Address
                { 'data': 'stok' }, //Tampilkan Address
                { 'data': 'satuan' }, //Tampilkan Address
                { 'data': 'harga_beli' }, //Tampilkan Address
                {
                    'render': function (data, type, row) { //Tampilkan kolom Action
                        // if (row.stok < 1) {
                        //     var html = '<button type="button" class="btn btn-info disabled" data-id="' + row.id_barang + '"><i class="fa fa-fw fa-search"></i></button>'
                        // } else {
                        //     var html = '<button type="button" class="btn btn-info" onclick="pilihdataBarang(this)" data-id="' + row.id_barang + '"><i class="fa fa-fw fa-search"></i></button>'
                        // }
                        var html = '<button type="button" class="btn btn-info" onclick="pilihdataBarang(this)" data-id="' + row.id_barang + '"><i class="fa fa-fw fa-search"></i></button>'
                        return html;
                    }
                }
            ],
            "columnDefs": [{
                targets: "_all",
                orderable: true
            }]
        })
    }


}
function fungsikeyboard() {
    if (event.keyCode == 112) {
        event.preventDefault()
        TabelBarang();
        $('#modal-default').modal({
            backdrop: 'static',
            keyboard: false,
        });
        $('#modal-default').modal('show')
    }
}
$(".keyboard").click(function () {
    TabelBarang();
    $('#modal-default').modal({
        backdrop: 'static',
        keyboard: false,
    });
    $('#modal-default').modal('show')
});
$(".btnSuplier").click(function () {
    dataSuplier();
    $('#modal-suplier').modal({
        backdrop: 'static',
        keyboard: false,
    });
    $('#modal-suplier').modal('show')
});

function pilihdataSuplier(arg) {
    var id = $(arg).attr('data-id');
    $.ajax({
        type: "POST",
        url: "suplier/getIdsuplier",
        data: { id: id },
        dataType: "json",
        beforeSend: function (e) {
            if (e && e.overrideMimeType) {
                e.overrideMimeType("application/json;charset=UTF-8");
            }
        },
        success: function (response) {
            var output = parseInt(response.limit).toLocaleString();
            document.getElementById("id_suplier").value = response.id_suplier;
            document.getElementById("namasuplier").value = response.namasuplier;
            $('#modal-suplier').modal('hide');
            $('#suplierTable').DataTable().destroy();
            if ($("#jenispembayaran").val() == 'kredit') {
                $("#showlimit").show();
                $("#showtempo").show();
                document.getElementById("limit_hutang").value = 'Rp ' + output;
            } else {
                $("#showlimit").hide();
                $("#showtempo").hide();
                document.getElementById("limit_hutang").value = '';
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
        }
    });
}

function pilihdataBarang(arg) {
    var id = $(arg).attr('data-id');
    if ($("#keterangan").val() == 'customer') {
        $.ajax({
            type: "POST",
            url: "C_Resep/getIdBarang",
            data: { id: id },
            dataType: "json",
            beforeSend: function (e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function (response) {
                var harga = parseFloat(response[0].harga_jual).toLocaleString();
                harga = harga.replace(/,/g, '.');
                document.getElementById("id_barang").value = response[0].id_barang;
                document.getElementById("namabarang").value = response[0].barang;
                document.getElementById("rupiah").value = 'Rp. ' + harga;
                $('#modal-default').modal('hide');
                $('#TabelBarang').DataTable().destroy();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
            }
        });

    } else {
        $.ajax({
            type: "POST",
            url: "C_Resep/getIdBarang",
            data: { id: id },
            dataType: "json",
            beforeSend: function (e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function (response) {
                var harga = parseFloat(response[0].harga_beli).toLocaleString();
                harga = harga.replace(/,/g, '.');
                document.getElementById("id_barang").value = response[0].id_barang;
                document.getElementById("namabarang").value = response[0].barang;
                document.getElementById("rupiah").value = 'Rp. ' + harga;
                $('#modal-default').modal('hide');
                $('#TabelBarang').DataTable().destroy();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
            }
        });

    }
}

$("#jenispembayaran").change(function () {
    if ($("#jenispembayaran").val() == 'kredit') {
        $("#showlimit").show();
        $("#showtempo").show();
        $.ajax({
            type: "POST",
            url: "suplier/getIdsuplier",
            data: { id: $("#id_suplier").val() },
            dataType: "json",
            beforeSend: function (e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function (response) {
                var output = parseInt(response.limit).toLocaleString();
                document.getElementById("limit_hutang").value = 'Rp ' + output;
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
            }
        });
    } else {
        $("#showlimit").hide();
        $("#showtempo").hide();
        document.getElementById("limit_hutang").value = '';
    }
});

$('.closemodal').click(function () {
    $('#modal-suplier').modal('hide');
    $('#suplierTable').DataTable().destroy();
});
$('.closeBarang').click(function () {
    $('#modal-default').modal('hide');
    $('#TabelBarang').DataTable().destroy();
});

$("#formCreate").submit(function (event) {
    event.preventDefault();
    $('#totalTabel').DataTable().destroy();
    $.ajax({
        type: "POST",
        url: "C_Pembelian/add_cart",
        dataType: "JSON",
        data: new FormData(this),
        processData: false,
        contentType: false,
        success: function (data) {
            //document.getElementById("id_pembelian").value = data.id_pembelian;
            $("#id_pembelian").val(data.id_pembelian).change();
            $("#qtt").val("").change();
            $("#rupiah").val("").change();
            $("#diskon").val("").change();
            $("#namabarang").val("").change();
            $("#id_barang").val("").change();
            totalTabel();

        }
    });
    return false;
});

$("#formCart").submit(function (event) {
    event.preventDefault();
    var id_pembelian = $('[name="id_pembelian"]').val();
    var subtotalbawah = $('[name="subtotalbawah"]').val().replace(/[^0-9]/g, '');
    var diskon1 = $('[name="diskon1"]').val().replace(/[^0-9]/g, '');
    var total = $('[name="total"]').val().replace(/[^0-9]/g, '');
    $.ajax({
        type: "POST",
        url: "C_Pembelian/update_all",
        dataType: "JSON",
        data: {
            id_pembelian: id_pembelian,
            subtotalbawah: subtotalbawah,
            diskon1: diskon1,
            total: total
        },
        success: function (data) {
            //window.location.href = data.redirect;
            if ($.isEmptyObject(data.error)) {
                $('#totalError').html('');
                $('#diskon1Error').html('');
                window.location.href = data.success;
                //alert(data.success)
            } else {
                $('#totalError').html('');
                $('#diskon1Error').html('');
                $.each(data.error, function (key, value) {
                    var ErrorID = '#' + key + 'Error';
                    $(ErrorID).removeClass("d-none");
                    $(ErrorID).addClass("text-danger");
                    $(ErrorID).text(value);
                });
            }

        }
    });
    return false;
});

function deleteDatatable(arg) {
    var id = $(arg).attr('data-id');
    if (confirm('Apakah Anda Yakin?'))
        $.ajax({
            type: "POST",
            url: "C_Pembelian/delete_dtlpembelian",
            dataType: "JSON",
            data: {
                id: id
            },
            success: function (data) {
                $('#totalTabel').DataTable().ajax.reload();
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }
        });
    return false;
}
function deletePembelian() {
    var id_pembelian = $('[name="id_pembelian"]').val();
    $.ajax({
        type: "POST",
        url: "C_Pembelian/batal/" + id_pembelian,
        dataType: "JSON",
        data: {
            id_pembelian: id_pembelian,
        },
        success: function (data) {
            window.location.href = data.redirect;
        }
    });
    return false;
}
$("#deleteall").click(function () {
    deletePembelian()
});
function subtotalall() {
    var subtotalbawah = document.getElementById('subtotalbawah').value.replace(/[^0-9]/g, '');
    var diskon = document.getElementById('diskon1').value.replace(/[^0-9]/g, '');
    var tall = subtotalbawah - diskon;
    var numbertotal = tall.toString(),
        sisa = numbertotal.length % 3,
        rupiah = numbertotal.substr(0, sisa),
        ribuan = numbertotal.substr(sisa).match(/\d{3}/g);

    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    var total = document.getElementById('total').value = formatRupiah(rupiah, 'Rp ');

}
