var now = moment();
var carikas = function (settings, data, dataIndex) {
    var min = $('#kasawal').val()
    var max = $('#kasakhir').val()
    var createdAt = data[1] || 0; // Our date column in the table
    //createdAt=createdAt.split(" ");
    var startDate = moment(min, "DD/MM/YYYY");
    var endDate = moment(max, "DD/MM/YYYY");
    var diffDate = moment(createdAt, "DD/MM/YYYY");

    if (min === "" && max === "") {
        return true;
    }
    if (diffDate.isSameOrAfter(startDate) && max === "") {
        return true;
    }
    if (diffDate.isSameOrBefore(endDate) && min === "") {
        return true;
    }
    if (diffDate.isSameOrAfter(startDate) && diffDate.isSameOrBefore(endDate)) {
        return true;
    }
    return false;
}
$("#kaskeluar").DataTable({
    buttons: [
        {
            text: 'Export Excel',
            className: 'btn btn-success',
            extend: 'excelHtml5',
            title: 'Laporan Kas Keluar'
        }
    ]
}).buttons().container().appendTo('#ekasKeluar');

var kaskeluar = $('#kaskeluar').DataTable();

$('#kasawal, #kasakhir').on('change', function () {
    $.fn.dataTable.ext.search.push(carikas);
    kaskeluar.draw();
});


$(".exportkaskeluar").click(function () {
    kaskeluar.button('.buttons-excel').trigger();
});